"""Local MON registry; SQLite transactions, versioned files, ONLYOFFICE integration."""
import base64, csv, hashlib, hmac, http.cookies, io, json, os, secrets, shutil, sqlite3, subprocess, sys, tempfile, threading, time, urllib.request, urllib.parse, zipfile
from contextlib import contextmanager
from datetime import datetime, timedelta
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from decimal import Decimal
from core import *
import documents
import updater
import mon_source

ROOT=Path(__file__).resolve().parent
DATA=Path(os.environ.get('MON_DATA',str(ROOT/'.local/demo'))).resolve()
DATA.mkdir(parents=True,exist_ok=True)
DEMO=os.environ.get('MON_DEMO','1')=='1'
PILOT=os.environ.get('MON_PILOT','0')=='1'
PILOT_DAY=os.environ.get('MON_PILOT_DATE','')
CONFIG=Path(os.environ.get('MON_CONFIG_DIR',str(ROOT/'.local'))).resolve()
CONFIG.mkdir(parents=True,exist_ok=True)
PORT=int(os.environ.get('MON_PORT','18741'))
PUBLIC=os.environ.get('MON_PUBLIC_URL',f'http://localhost:{PORT}').rstrip('/')
INTERNAL=os.environ.get('MON_INTERNAL_URL',f'http://host.docker.internal:{PORT}').rstrip('/')
OFFICE=os.environ.get('MON_OFFICE_URL','http://localhost:18742').rstrip('/')
OFFICE_INTERNAL=os.environ.get('MON_OFFICE_INTERNAL_URL','http://localhost:18742').rstrip('/')
DB=DATA/'registry.sqlite3'
LOCK=threading.RLock()
SERVER=None
SOURCE_DOCUMENT_JOBS={}
SOURCE_DOCUMENT_SLOTS=threading.BoundedSemaphore(1 if PILOT else 2)
PILOT_PROCESS=None
PILOT_LOCK=threading.RLock()
PILOT_PORT=18744
def secret(name):
    p=CONFIG/name;p.parent.mkdir(exist_ok=True)
    if not p.exists():p.write_text(secrets.token_urlsafe(48),encoding='utf-8')
    return p.read_text(encoding='utf-8').strip()
APP_SECRET=secret('app-secret')
OFFICE_SECRET=secret('office-secret')
# Receiver deliberately has no default external credential: 503 until configured.
RATE_TOKEN=os.environ.get('MON_RATE_TOKEN','')
def now():
    if PILOT:return datetime.fromisoformat(PILOT_DAY+'T11:00:00').replace(tzinfo=KYIV)
    return datetime(2026,11,19,11,0,tzinfo=KYIV) if DEMO else datetime.now(KYIV)
def utc():return datetime.now().astimezone().isoformat()
def encode(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'))
def uid():return secrets.token_hex(16)

@contextmanager
def db():
    with LOCK:
        c=sqlite3.connect(DB,timeout=30);c.row_factory=sqlite3.Row
        c.execute('PRAGMA foreign_keys=ON');c.execute('PRAGMA journal_mode=WAL')
        try:
            c.execute('BEGIN IMMEDIATE');yield c;c.commit()
        except Exception:c.rollback();raise
        finally:c.close()

def cleanup_source_temp():
    temp_root=(DATA/'source-temp').resolve()
    if temp_root.parent==DATA.resolve() and temp_root.is_dir() and not (DATA/'source-temp').is_symlink():
        for folder in temp_root.iterdir():
            # A normal OCR child lives at most 220 seconds. A separate manage
            # command must not remove the running registry's temporary files.
            if re.fullmatch(r'job-[A-Za-z0-9_-]{8,64}',folder.name) and folder.is_dir() and not folder.is_symlink() and folder.resolve().parent==temp_root and time.time()-folder.stat().st_mtime>=3600:
                shutil.rmtree(folder)


def init():
    with db() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,username TEXT UNIQUE NOT NULL,name TEXT NOT NULL,password TEXT NOT NULL,enabled INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS logins(token TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires REAL NOT NULL,csrf TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS deals(id TEXT PRIMARY KEY,source_key TEXT,object_key TEXT,data TEXT NOT NULL,rev INTEGER NOT NULL DEFAULT 1,invoice_number TEXT,invoice_date TEXT,sequence INTEGER,UNIQUE(invoice_date,sequence));
        CREATE INDEX IF NOT EXISTS source_index ON deals(source_key);
        CREATE INDEX IF NOT EXISTS object_index ON deals(object_key);
        CREATE TABLE IF NOT EXISTS rates(source_id TEXT PRIMARY KEY,rate_date TEXT NOT NULL,mon_rate TEXT NOT NULL,published_at TEXT NOT NULL,received_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS numbering(day TEXT PRIMARY KEY,next_number INTEGER NOT NULL,confirmed_by TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS generations(id TEXT PRIMARY KEY,deal_id TEXT NOT NULL,fingerprint TEXT NOT NULL,snapshot TEXT NOT NULL,calculation TEXT NOT NULL,created_at TEXT NOT NULL,UNIQUE(deal_id,fingerprint));
        CREATE TABLE IF NOT EXISTS versions(id TEXT PRIMARY KEY,deal_id TEXT NOT NULL,kind TEXT NOT NULL,generation_id TEXT NOT NULL,parent TEXT,author TEXT NOT NULL,created_at TEXT NOT NULL,path TEXT NOT NULL,sha TEXT NOT NULL,origin TEXT NOT NULL,valid INTEGER NOT NULL,errors TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS heads(deal_id TEXT,kind TEXT,version_id TEXT,PRIMARY KEY(deal_id,kind));
        CREATE TABLE IF NOT EXISTS editor_sessions(id TEXT PRIMARY KEY,deal_id TEXT NOT NULL,kind TEXT NOT NULL,user_id TEXT NOT NULL,base_version TEXT NOT NULL,saved_head TEXT NOT NULL,doc_key TEXT NOT NULL,expires REAL NOT NULL,closed INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS attachments(id TEXT PRIMARY KEY,deal_id TEXT NOT NULL,name TEXT NOT NULL,path TEXT NOT NULL,sha TEXT NOT NULL,author TEXT NOT NULL,created_at TEXT NOT NULL,extraction TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,deal_id TEXT,action TEXT NOT NULL,author TEXT NOT NULL,created_at TEXT NOT NULL,detail TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS import_issues(id TEXT PRIMARY KEY,payload TEXT NOT NULL,reason TEXT NOT NULL,resolved INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS calculated_rates(id TEXT PRIMARY KEY,rate_date TEXT NOT NULL,mon_rate TEXT NOT NULL,source_at TEXT NOT NULL,checked_at TEXT NOT NULL,data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS calculated_checks(rate_date TEXT PRIMARY KEY,checked_at TEXT NOT NULL,state TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS pilot_rates(rate_date TEXT PRIMARY KEY,mon_rate TEXT NOT NULL,source_label TEXT NOT NULL,selected_at TEXT NOT NULL);
        ''')
    if PILOT:
        seed=json.loads((CONFIG/'pilot-seed.json').read_text(encoding='utf-8'))
        with db() as c:
            for user in seed['users']:
                c.execute('INSERT INTO users VALUES(?,?,?,?,1) ON CONFLICT(username) DO UPDATE SET name=excluded.name,password=excluded.password,enabled=1',(user['id'],user['username'],user['name'],user['password']))
            c.execute('INSERT OR IGNORE INTO numbering VALUES(?,?,?)',(PILOT_DAY,1,'pilot'))
            c.execute('INSERT OR REPLACE INTO pilot_rates VALUES(?,?,?,?)',(PILOT_DAY,seed['mon_rate'],seed['rate_label'],seed['selected_at']))
    cleanup_source_temp()

def hash_password(password):
    if len(password)<12:raise RuleError('Пароль має містити щонайменше 12 символів')
    salt=secrets.token_hex(16)
    return salt+':'+hashlib.scrypt(password.encode(),salt=salt.encode(),n=16384,r=8,p=1).hex()
def check_password(password,stored):
    salt,expected=stored.split(':')
    actual=hashlib.scrypt(password.encode(),salt=salt.encode(),n=16384,r=8,p=1).hex()
    return hmac.compare_digest(actual,expected)
def add_user(username,name,password):
    if not username or len(username)>80 or not name:raise RuleError('Заповніть логін та ім’я')
    with db() as c:
        c.execute('INSERT INTO users VALUES(?,?,?,?,1)',(uid(),username,name,hash_password(password)))

def audit(c,deal_id,action,author,detail=''):
    # Field names / opaque IDs only, never field values or document URLs.
    c.execute('INSERT INTO audit(deal_id,action,author,created_at,detail) VALUES(?,?,?,?,?)',(deal_id,action,author,utc(),detail))

def sign(payload,secret_value=APP_SECRET):
    def b64(x):return base64.urlsafe_b64encode(x).rstrip(b'=').decode()
    head=b64(b'{"alg":"HS256","typ":"JWT"}');body=b64(encode(payload).encode());s=head+'.'+body
    return s+'.'+b64(hmac.new(secret_value.encode(),s.encode(),hashlib.sha256).digest())
def verify(token,secret_value=APP_SECRET):
    try:
        a,b,s=token.split('.')
        expected=sign(json.loads(base64.urlsafe_b64decode(b+'='*(-len(b)%4))),secret_value)
        if not hmac.compare_digest(token,expected):raise ValueError()
        p=json.loads(base64.urlsafe_b64decode(b+'='*(-len(b)%4)))
        if p.get('exp',time.time()+1)<time.time():raise ValueError()
        return p
    except Exception:raise APIError(403,'Неприпустимий або прострочений токен')

class APIError(Exception):
    def __init__(self,status,message):self.status=status;self.message=message

def get_deal(c,deal_id):
    r=c.execute('SELECT * FROM deals WHERE id=?',(deal_id,)).fetchone()
    if not r:raise APIError(404,'Угоду не знайдено')
    d=json.loads(r['data']);d.update(id=r['id'],rev=r['rev'],invoice_number=r['invoice_number'])
    return d
def get_rate(c,day):
    if PILOT:
        r=c.execute('SELECT * FROM pilot_rates WHERE rate_date=?',(day,)).fetchone()
        return {**dict(r),'source_id':'pilot:control:'+day,'is_test':True,'published_at':None,'conflict':False,'events':1} if r else None
    rs=c.execute('SELECT * FROM rates WHERE rate_date=? ORDER BY received_at',(day,)).fetchall()
    if not rs:return None
    return {**dict(rs[0]),'conflict':len({r['mon_rate'] for r in rs})>1,'events':len(rs)}
def view(c,d):
    rate=get_rate(c,d.get('deal_date'));status,issues,calc=readiness(d,rate,now())
    numbering_required=bool(not d.get('invoice_number') and parse_date(d.get('deal_date')) and not c.execute('SELECT 1 FROM numbering WHERE day=?',(d['deal_date'],)).fetchone())
    if numbering_required:
        issues.append('Укажіть перший вільний номер рахунку на дату угоди.')
        if status=='Готова до генерації':status='Потрібна перевірка'
    calculated=get_calculated(c,d.get('deal_date'))
    heads={r['kind']:dict(r) for r in c.execute('SELECT v.* FROM heads h JOIN versions v ON v.id=h.version_id WHERE h.deal_id=?',(d['id'],))}
    if heads:
        if all(k in heads for k in ('docx','xlsx')):
            if all(h['valid'] for h in heads.values()):status='Комплект збережено'
            else:status='Розбіжності в документах'
        if issues:status='Потрібна перевірка'
        # Changed card never presents an old document set as current.
        for h in heads.values():
            g=c.execute('SELECT fingerprint FROM generations WHERE id=?',(h['generation_id'],)).fetchone()
            if g and g['fingerprint']!=fingerprint(d,rate):status='Дані змінено — перевірте версії'
    return {**d,'status':status,'issues':issues,'numbering_required':numbering_required,'source_ack_required':any(s not in AMOUNT_SOURCE_ISSUES for s in d.get('source_issues',[])),'source_documents':source_document_status(c,d),'calculation':calc,'rate':rate,'rate_comparison':mon_source.compare(rate,calculated),'documents':{k:{**{a:b for a,b in v.items() if a!='path'},'errors':json.loads(v['errors'])} for k,v in heads.items()}}

def get_calculated(c,day):
    row=c.execute('SELECT data FROM calculated_rates WHERE rate_date=? ORDER BY checked_at DESC,rowid DESC LIMIT 1',(day,)).fetchone()
    if not row:return None
    value=json.loads(row[0]);check=c.execute('SELECT checked_at,state FROM calculated_checks WHERE rate_date=?',(day,)).fetchone()
    if check:value.update(last_check_at=check[0],last_check_state=check[1])
    return value

def refresh_calculated(day):
    date=parse_date(day)
    if not date or day!=date.isoformat():raise RuleError('Потрібна дата YYYY-MM-DD')
    actual=datetime.now(KYIV)
    if date>actual.date() or (date==actual.date() and (actual.hour,actual.minute)<(10,1)):
        raise APIError(422,'Розрахунковий МОН перевіряється з 10:01 за Києвом після появи точки 09:00')
    try:point=mon_source.fetch(date)
    except Exception:
        with db() as c:c.execute('INSERT OR REPLACE INTO calculated_checks VALUES(?,?,?)',(day,utc(),'unavailable'))
        raise APIError(503,'Розрахунковий курс на цю дату недоступний у джерелі. Інший день не підставлено.')
    point['checked_at']=utc();point['test_space']=DEMO
    event_id=digest([point['rate_date'],point['mon_rate'],point['raw_value'],point['source_at'],point['policy']])
    with db() as c:
        c.execute('INSERT OR REPLACE INTO calculated_rates VALUES(?,?,?,?,?,?)',(event_id,day,point['mon_rate'],point['source_at'],point['checked_at'],encode(point)))
        c.execute('INSERT OR REPLACE INTO calculated_checks VALUES(?,?,?)',(day,point['checked_at'],'ok'))
    # Does not touch rates, invoices, generation fingerprints or file heads.
    return point
def fingerprint(d,rate):
    ignore={'id','rev','invoice_number','source_row','source_key','object_key','documents_link','automatic_fields','document_sources','document_evidence','reviewed_document_evidence','document_issues','document_conflicts'}
    return digest({'deal':{k:v for k,v in d.items() if k not in ignore},'rate':rate['mon_rate'] if rate else None,'document_rules':documents.RULES_VERSION})

def import_rows(rows,actor,window=True):
    if not isinstance(rows,list) or len(rows)>5000:raise RuleError('Некоректний імпорт')
    items=parse_rows(rows,now().date(),window);keys={};counts={'created':0,'updated':0,'review':0,'selected':len(items)}
    if PILOT:items=[d for d in items if d.get('deal_date')==PILOT_DAY];counts['selected']=len(items)
    for d in items:keys[d['source_key']]=keys.get(d['source_key'],0)+1
    with db() as c:
        for d in items:
            matches=c.execute('SELECT * FROM deals WHERE source_key=?',(d['source_key'],)).fetchall()
            object_matches=c.execute('SELECT id FROM deals WHERE object_key=?',(d['object_key'],)).fetchall()
            if keys[d['source_key']]>1 or len(matches)>1 or (not matches and object_matches):
                issue_id=digest([d['source_key'],d['source_row']])
                c.execute('INSERT OR REPLACE INTO import_issues VALUES(?,?,?,0)',(issue_id,encode(d),'Неоднозначне зіставлення: виберіть окрему угоду або наявну картку'))
                counts['review']+=1;continue
            if matches:
                r=matches[0];old=json.loads(r['data']);confirmed=old.get('confirmed',{})
                previous_source=source_signature(old)
                for k,v in d.items():
                    if not confirmed.get(k):old[k]=v
                resolve_source_amounts(old)
                if not DEMO and source_signature(old)!=previous_source:old['document_issues']=['Комплект документів із T потребує повторного автоматичного читання.']
                # Keep manual data and all file heads intact.
                if json.loads(r['data'])!=old:
                    c.execute('UPDATE deals SET data=?,rev=rev+1 WHERE id=?',(encode(old),r['id']))
                    audit(c,r['id'],'Імпорт оновлено',actor)
                counts['updated']+=1
            else:
                deal_id=uid();d['confirmed']={};d['demo']=DEMO or PILOT
                if not DEMO:
                    d['document_issues']=['Очікує автоматичного читання документів із T.']
                    for k,v in verified_document_reference(d).items():
                        if v:d[k]=v;d['confirmed'][k]=True
                c.execute('INSERT INTO deals(id,source_key,object_key,data) VALUES(?,?,?,?)',(deal_id,d['source_key'],d['object_key'],encode(d)))
                audit(c,deal_id,'Угоду імпортовано',actor);counts['created']+=1
        c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',('last_import',utc()))
    return counts

def receive_rate(payload):
    if PILOT:raise APIError(409,'Тест використовує окремий тестовий курс. Робочі публікації сюди не записуються.')
    if set(payload)!={'rate_date','mon_rate','published_at','source_id'}:raise RuleError('Потрібні рівно 4 поля контракту')
    day=payload['rate_date'];v=payload['mon_rate'];source=payload['source_id']
    if not isinstance(v,str) or not re.fullmatch(r'\d{1,4}\.\d{2,6}',v):raise RuleError('mon_rate: десятковий рядок із крапкою')
    if not parse_date(day) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',day):raise RuleError('rate_date: YYYY-MM-DD')
    if not isinstance(source,str) or not re.fullmatch(r'[a-zA-Z0-9:_.-]{1,160}',source):raise RuleError('Некоректний source_id')
    try:
        published=datetime.fromisoformat(payload['published_at'].replace('Z','+00:00'))
        if published.tzinfo is None:raise ValueError()
        if Decimal(v)<=0:raise ValueError()
    except Exception:raise RuleError('Некоректний курс або published_at без часового поясу')
    v=format(Decimal(v).normalize(),'f')
    if '.' not in v or len(v.split('.')[1])<2:v=format(Decimal(v),'.2f')
    with db() as c:
        old=c.execute('SELECT * FROM rates WHERE source_id=?',(source,)).fetchone()
        if old:
            if (old['rate_date'],old['mon_rate'],old['published_at'])!=(day,v,payload['published_at']):raise APIError(409,'source_id вже належить іншій події')
            return {'accepted':True,'duplicate':True,'conflict':get_rate(c,day)['conflict']}
        c.execute('INSERT INTO rates VALUES(?,?,?,?,?)',(source,day,v,payload['published_at'],utc()))
        audit(c,None,'Отримано курс','integration',digest(source))
        conflict=get_rate(c,day)['conflict']
    process_ready()
    return {'accepted':True,'duplicate':False,'conflict':conflict}

def put_version(c,deal_id,kind,generation,parent,author,data,origin,d,calc,number):
    errors=documents.validate(data,kind,d,calc,number);vid=uid()
    folder=DATA/'files'/deal_id;folder.mkdir(parents=True,exist_ok=True)
    path=folder/(vid+'.'+kind);path.write_bytes(data)
    sha=hashlib.sha256(data).hexdigest()
    c.execute('INSERT INTO versions VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(vid,deal_id,kind,generation,parent,author,utc(),str(path),sha,origin,int(not errors),encode(errors)))
    c.execute('INSERT OR REPLACE INTO heads VALUES(?,?,?)',(deal_id,kind,vid))
    audit(c,deal_id,'Документ збережено',author,kind+':'+origin)
    return vid,errors

def generate(deal_id,actor,expected_rev=None):
    with db() as c:
        d=get_deal(c,deal_id);rate=get_rate(c,d.get('deal_date'));status,issues,calc=readiness(d,rate,now())
        if expected_rev is not None and d['rev']!=expected_rev:raise APIError(409,'Картку вже змінено іншим менеджером. Оновіть сторінку.')
        if status!='Готова до генерації':raise APIError(422,'Генерацію заблоковано: '+(' · '.join(issues) or status))
        if c.execute('SELECT 1 FROM editor_sessions WHERE deal_id=? AND closed=0 AND expires>?',(deal_id,time.time())).fetchone():raise APIError(409,'Закрийте редактор перед генерацією')
        fp=fingerprint(d,rate)
        old=c.execute('SELECT id FROM generations WHERE deal_id=? AND fingerprint=?',(deal_id,fp)).fetchone()
        if old:return {'generation_id':old['id'],'unchanged':True}
        issued=c.execute('SELECT * FROM deals WHERE id=?',(deal_id,)).fetchone()
        if issued['invoice_number']:
            if issued['invoice_date']!=d['deal_date']:raise APIError(409,'Угода має виданий номер на іншу дату. Потрібна ручна перевірка; номер не змінено.')
            number=issued['invoice_number']
        else:
            seq=c.execute('SELECT * FROM numbering WHERE day=?',(d['deal_date'],)).fetchone()
            if not seq:raise APIError(422,'Спершу підтвердьте стартову нумерацію цього дня')
            n=seq['next_number'];number=('ТЕСТ-' if PILOT else '')+parse_date(d['deal_date']).strftime('%d-%m')+'/'+str(n)
            c.execute('UPDATE numbering SET next_number=? WHERE day=?',(n+1,d['deal_date']))
            c.execute('UPDATE deals SET invoice_number=?,invoice_date=?,sequence=? WHERE id=?',(number,d['deal_date'],n,deal_id))
        # Both files are built and validated before either becomes a head.
        word=documents.docx(d,calc,number);excel=documents.xlsx(d,calc,number)
        if documents.validate(word,'docx',d,calc,number) or documents.validate(excel,'xlsx',d,calc,number):raise APIError(500,'Перевірка створених документів не пройдена')
        generation=uid();c.execute('INSERT INTO generations VALUES(?,?,?,?,?,?)',(generation,deal_id,fp,encode(d),encode(calc),utc()))
        for kind,data in [('docx',word),('xlsx',excel)]:
            prev=c.execute('SELECT version_id FROM heads WHERE deal_id=? AND kind=?',(deal_id,kind)).fetchone()
            # Manual heads are preserved: regeneration creates a candidate, never an overwrite.
            manual=c.execute('SELECT origin FROM versions WHERE id=?',(prev['version_id'],)).fetchone() if prev else None
            vid,_=put_version(c,deal_id,kind,generation,prev['version_id'] if prev else None,actor,data,'automatic',d,calc,number)
            if manual and manual['origin']=='manual':c.execute('UPDATE heads SET version_id=? WHERE deal_id=? AND kind=?',(prev['version_id'],deal_id,kind))
        return {'generation_id':generation,'invoice_number':number,'unchanged':False}

def process_ready():
    if now().weekday()>4:return
    with db() as c:ids=[r[0] for r in c.execute('SELECT id FROM deals')]
    for deal_id in ids:
        try:
            with db() as c:d=get_deal(c,deal_id)
            if d.get('deal_date')==now().date().isoformat():generate(deal_id,'scheduler')
        except (APIError,RuleError):pass
        except Exception:
            with db() as c:audit(c,deal_id,'Помилка генерації','scheduler','Потрібен повторний запуск')

def refresh_source(actor='scheduler'):
    if DEMO:raise APIError(409,'Робоче джерело недоступне у тестовому просторі')
    token=os.environ.get('MON_GOOGLE_ACCESS_TOKEN','')
    try:
        if token:
            url=f'https://sheets.googleapis.com/v4/spreadsheets/{SOURCE_ID}/values/'+urllib.parse.quote("'Графік'!A1:T1500",safe='')+'?valueRenderOption=FORMATTED_VALUE'
            req=urllib.request.Request(url,headers={'Authorization':'Bearer '+token})
            with urllib.request.urlopen(req,timeout=30) as r:values=json.load(r).get('values',[])
        else:
            url=f'https://docs.google.com/spreadsheets/d/{SOURCE_ID}/gviz/tq?tqx=out:csv&gid=0&range=A1:T1500'
            with urllib.request.urlopen(url,timeout=30) as r:
                if not r.headers.get('Content-Type','').startswith('text/csv'):raise ValueError('not_csv')
                raw=r.read(2*1024*1024+1)
            if len(raw)>2*1024*1024:raise ValueError('source_too_large')
            values=list(csv.reader(io.StringIO(raw.decode('utf-8-sig'))))
    except Exception:raise APIError(503,'Не вдалося прочитати вкладку «Графік». Перевірте доступ Google.')
    # CSV contains display labels rather than hidden hyperlink destinations.
    # The public export reads only the same single tab, never another tab.
    link_warning=False
    if any(len(r)>19 and r[19] and not str(r[19]).startswith('https://') for r in values):
        try:
            targets={}
            for entry in documents.source_sheet_links(SOURCE_ID,include_identity=True).values():targets.setdefault(source_document_identity(entry['identity']),set()).add(entry['url'])
            for row in values:
                if len(row)>19 and row[19] and not str(row[19]).startswith('https://'):
                    matches=targets.get(source_document_identity([row[k] for k in (2,7,8,9)]),set())
                    if len(matches)==1:row[19]=next(iter(matches))
                    else:link_warning=True
        except Exception:link_warning=True
    out=import_rows(values,actor);out['document_links_need_review']=link_warning
    if actor!='scheduler':
        with db() as c:c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',('source-documents-refresh',str(time.time())))
    prepare_source_documents();process_ready();return out

def sync_finance(rate_date=None):
    if DEMO or PILOT:raise APIError(409,'Робочий курс не імпортується у тестовий простір')
    path=ROOT/'.local/finance-client.json'
    if not path.exists():raise APIError(503,'API підтверджених публікацій ще не підключений')
    config=json.loads(path.read_text())
    if config.get('mode')=='push':
        day=rate_date or now().date().isoformat()
        if not parse_date(day) or parse_date(day).isoformat()!=day:raise RuleError('Потрібна дата YYYY-MM-DD')
        with db() as c:rate=get_rate(c,day)
        return {'ok':True,'events':rate['events'] if rate else 0,'rate_date':day,'mode':'push','waiting':rate is None}
    base=config['api_url'].rstrip('/')
    if not base.startswith('https://') or not config.get('api_token'):raise APIError(503,'Потрібні HTTPS-адреса API й авторизація')
    day=rate_date or now().date().isoformat()
    if not parse_date(day) or parse_date(day).isoformat()!=day:raise RuleError('Потрібна дата YYYY-MM-DD')
    url=base+'/v1/mon-publications?rate_date='+day
    request=urllib.request.Request(url,headers={'Authorization':'Bearer '+config['api_token']})
    try:
        with urllib.request.urlopen(request,timeout=20) as response:body=json.load(response)
    except Exception:raise APIError(503,'API фінансів тимчасово недоступний')
    if not isinstance(body.get('events'),list) or len(body['events'])>100:raise APIError(502,'Некоректна відповідь API фінансів')
    accepted=0
    for event in body['events']:
        if event.get('rate_date')!=day or not str(event.get('source_id','')).startswith('finance:'):raise APIError(502,'Публікація належить іншій даті або джерелу')
        receive_rate(event);accepted+=1
    return {'ok':True,'events':accepted,'rate_date':day}


def version_file(row):
    """Only app-owned immutable DOCX/XLSX paths within this data store."""
    if any(len(row[k])!=32 or any(ch not in '0123456789abcdef' for ch in row[k]) for k in ('id','deal_id')):raise ValueError('unexpected_file_id')
    base=DATA/'files';folder=base/row['deal_id'];expected=folder/(row['id']+'.'+row['kind'])
    if row['kind'] not in ('docx','xlsx') or base.is_symlink() or folder.is_symlink() or expected.is_symlink():raise ValueError('unsafe_version_path')
    if not base.resolve().is_relative_to(DATA.resolve()) or not expected.resolve().is_relative_to(base.resolve()):raise ValueError('outside_file_store')
    if folder.parent!=base or Path(row['path']).absolute()!=expected.absolute():raise ValueError('unexpected_version_path')
    return expected

def cleanup_file_versions(current=None,dry_run=False):
    """Monthly: remove superseded versions older than 24h, without an archive.

    A deal is eligible only after both selected files pass their stored integrity
    checks and match the current card. An unfinished or open deal is left intact.
    The committed deletion queue makes interruption/retry safe without a file copy.
    """
    current=current or datetime.now(KYIV)
    if current.tzinfo is None:raise ValueError('timezone_required')
    month=current.astimezone(KYIV).strftime('%Y-%m');cutoff=current-timedelta(days=1)
    result={'month':month,'planned_versions':0,'deleted_files':0,'skipped_deals':0,'pending_files':0,'due':False}
    with LOCK:
        with db() as c:
            last=c.execute("SELECT value FROM settings WHERE key='version_cleanup_month'").fetchone()
            pending=c.execute("SELECT value FROM settings WHERE key='version_cleanup_pending'").fetchone()
            queue=json.loads(pending[0]) if pending else []
            result['due']=not last or last[0]!=month
            planned=[]
            if result['due']:
                groups={}
                for row in c.execute('SELECT * FROM versions ORDER BY rowid DESC'):
                    groups.setdefault(row['deal_id'],[]).append(dict(row))
                active={r[0] for r in c.execute('SELECT DISTINCT deal_id FROM editor_sessions WHERE closed=0 AND expires>?',(current.timestamp(),))}
                for deal_id,rows in groups.items():
                    try:
                        heads=list(c.execute('SELECT v.* FROM heads h JOIN versions v ON v.id=h.version_id WHERE h.deal_id=?',(deal_id,)))
                        if deal_id in active or {h['kind'] for h in heads}!={'docx','xlsx'}:raise ValueError('unfinished_deal')
                        d=get_deal(c,deal_id);fp=fingerprint(d,get_rate(c,d.get('deal_date')))
                        for head in heads:
                            generation=c.execute('SELECT fingerprint FROM generations WHERE id=?',(head['generation_id'],)).fetchone()
                            path=version_file(head)
                            if not head['valid'] or not generation or generation[0]!=fp or hashlib.sha256(path.read_bytes()).hexdigest()!=head['sha']:raise ValueError('unverified_head')
                    except (APIError,ValueError,OSError):
                        result['skipped_deals']+=1;continue
                    keep={h['id'] for h in heads}
                    for row in rows:
                        if row['id'] in keep:continue
                        try:
                            created=datetime.fromisoformat(row['created_at'])
                            if created.tzinfo is None or created>=cutoff:continue
                            path=version_file(row)
                            if path.exists() and hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha']:continue
                        except (ValueError,OSError):continue
                        planned.append({k:row[k] for k in ('id','deal_id','kind','path','sha','generation_id')})
                result['planned_versions']=len(planned)
                if not dry_run:
                    for row in planned:
                        c.execute('UPDATE versions SET parent=NULL WHERE parent=?',(row['id'],))
                        c.execute('DELETE FROM versions WHERE id=?',(row['id'],))
                    for generation in {row['generation_id'] for row in planned}:
                        c.execute('DELETE FROM generations WHERE id=? AND NOT EXISTS(SELECT 1 FROM versions WHERE generation_id=generations.id)',(generation,))
                    queue.extend(planned)
                    c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',('version_cleanup_pending',encode(queue)))
                    c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',('version_cleanup_month',month))
            if dry_run:
                result['pending_files']=len(queue);return result
        remaining=[]
        for row in queue:
            try:
                path=version_file(row)
                with db() as c:
                    referenced=c.execute('SELECT 1 FROM versions WHERE path=? UNION ALL SELECT 1 FROM attachments WHERE path=?',(str(path),str(path))).fetchone()
                if referenced:continue
                if path.exists():
                    if hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha']:raise ValueError('file_changed')
                    path.unlink();result['deleted_files']+=1
            except (OSError,ValueError):remaining.append(row)
        result['pending_files']=len(remaining)
        with db() as c:
            c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',('version_cleanup_pending',encode(remaining)))
            if result['due'] or queue:
                c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',('version_cleanup_result',encode(result)))
                if result['planned_versions'] or result['deleted_files']:
                    audit(c,None,'Очищено проміжні версії файлів','maintenance','removed='+str(result['deleted_files']))
    return result


def scheduler():
    maintenance_check=0
    while True:
        if time.time()-maintenance_check>=3600:
            maintenance_check=time.time()
            try:cleanup_file_versions();cleanup_source_temp()
            except Exception:
                with db() as c:audit(c,None,'Очищення проміжних версій відкладено','maintenance')
        if not DEMO and now().weekday()<5:
            local=now()
            if not PILOT and (local.hour,local.minute)>=(10,1):
                with db() as c:check=c.execute('SELECT checked_at FROM calculated_checks WHERE rate_date=?',(local.date().isoformat(),)).fetchone()
                if not check or (datetime.now().astimezone()-datetime.fromisoformat(check[0])).total_seconds()>=300:
                    try:refresh_calculated(local.date().isoformat())
                    except Exception:pass
            try:sync_finance()
            except Exception:pass
            try:
                with db() as c:r=c.execute('SELECT value FROM settings WHERE key=?',('last_poll',)).fetchone()
                if not r or time.time()-float(r[0])>=300:
                    refresh_source()
                    with db() as c:c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',('last_poll',str(time.time())))
            except Exception:pass
            prepare_source_documents();process_ready()
        time.sleep(30)

def office_command(payload):
    payload={**payload,'token':sign(payload,OFFICE_SECRET)}
    request=urllib.request.Request(OFFICE_INTERNAL+'/coauthoring/CommandService.ashx',data=encode(payload).encode(),headers={'Content-Type':'application/json'})
    try:
        with urllib.request.urlopen(request,timeout=30) as r:return json.load(r)
    except Exception:raise APIError(503,'Редактор тимчасово недоступний')

def extraction(path,source=False):
    result='';method='text';error=None;page_errors=[]
    try:
        if path.suffix.lower()=='.pdf':
            from pypdf import PdfReader
            reader=PdfReader(path)
            if source and len(reader.pages)>30:raise ValueError('page_limit')
            pages=[p.extract_text() or '' for p in reader.pages]
            if source and any(not p.strip() for p in pages) and shutil.which('tesseract'):
                with tempfile.TemporaryDirectory(prefix='mon-source-ocr-',dir=path.parent) as folder:
                    deadline=time.monotonic()+180
                    for index,value in enumerate(pages):
                        if value.strip():continue
                        try:
                            method='ocr';prefix=Path(folder)/('page-'+str(index+1))
                            remaining=deadline-time.monotonic()
                            if remaining<=0:raise TimeoutError()
                            subprocess.run(['pdftoppm','-r','180','-png','-singlefile','-f',str(index+1),'-l',str(index+1),str(path),str(prefix)],capture_output=True,check=True,timeout=min(30,remaining))
                            remaining=deadline-time.monotonic()
                            if remaining<=0:raise TimeoutError()
                            out=subprocess.run(['tesseract',str(prefix)+'.png','stdout','-l','ukr+eng'],capture_output=True,check=True,timeout=min(45,remaining),env={**os.environ,'OMP_THREAD_LIMIT':'1'})
                            pages[index]=out.stdout.decode('utf-8')
                        except Exception:page_errors.append(index+1)
            result='\f'.join(pages)
        elif path.suffix.lower()=='.docx':
            with zipfile.ZipFile(path) as z:
                from lxml import etree
                parser=etree.XMLParser(resolve_entities=False,no_network=True)
                root=etree.fromstring(z.read('word/document.xml'),parser)
                result='\n'.join(''.join(p.xpath('.//w:t/text()',namespaces=documents.NS)) for p in root.xpath('//w:p',namespaces=documents.NS))
        elif path.suffix.lower()=='.txt':result=path.read_text(encoding='utf-8')
        if not result.strip() and path.suffix.lower() in ('.pdf','.png','.jpg','.jpeg') and not (source and path.suffix.lower()=='.pdf' and shutil.which('tesseract')):
            method='ocr'
            if shutil.which('tesseract'):
                with tempfile.TemporaryDirectory(prefix='mon-ocr-',dir=path.parent if source else None) as folder:
                    images=[path];deadline=time.monotonic()+180
                    if path.suffix.lower()=='.pdf':
                        subprocess.run(['pdftoppm','-r','180','-png','-f','1','-l','30',str(path),str(Path(folder)/'page')],capture_output=True,check=True,timeout=45)
                        images=sorted(Path(folder).glob('*.png'))
                    chunks=[]
                    for image in images:
                        remaining=deadline-time.monotonic()
                        if remaining<=0:raise TimeoutError()
                        out=subprocess.run(['tesseract',str(image),'stdout','-l','ukr+eng'],capture_output=True,check=True,timeout=min(30,remaining))
                        chunks.append(out.stdout.decode('utf-8'))
                    result='\f'.join(chunks)
            else:
                cmd=['docker','run','--rm','--network','none','--memory','512m','--cpus','1','-v',str(path.parent)+':/work:ro','mon-sales-ocr:local','/usr/local/bin/ocr-file','/work/'+path.name]
                out=subprocess.run(cmd,capture_output=True,timeout=180,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                if out.returncode:raise RuntimeError()
                result=out.stdout.decode('utf-8')
    except Exception:error='Не вдалося розпізнати документ. Підтвердьте реквізити вручну.'
    # Never silently merge persons: extraction is only a candidate for human review.
    return {'method':method,'text':result[:100000],'needs_party_confirmation':not source,'error':error,'page_errors':page_errors}


def source_signature(d):
    return digest([d.get('documents_link',''),d.get('source_buyer_name') or d.get('name','')])


def source_document_status(c,d):
    r=c.execute('SELECT value FROM settings WHERE key=?',('source-documents:'+d['id'],)).fetchone()
    state=json.loads(r[0]) if r else {}
    return state if state.get('signature')==source_signature(d) else {'state':'waiting','message':'Очікує читання комплекту з колонки T.'}


def start_source_documents(deal_id,actor='scheduler',force=False):
    with db() as c:
        d=get_deal(c,deal_id)
        if DEMO:return {'state':'demo','message':'Тестовий простір: робочі документи Google не зчитуються.'}
        state=source_document_status(c,d)
        if deal_id in SOURCE_DOCUMENT_JOBS:return state
        ttl=300 if state.get('state')=='error' else 86400
        refresh=c.execute('SELECT value FROM settings WHERE key=?',('source-documents-refresh',)).fetchone()
        cutoff=float(refresh[0]) if refresh else 0
        if not force and state.get('state') in ('done','error') and state.get('checked_at',0)>=cutoff and state.get('checked_day')==now().date().isoformat() and time.time()-state.get('checked_at',0)<ttl:return state
        if not force and d.get('deal_date','')<now().date().isoformat() and c.execute('SELECT COUNT(*) FROM heads WHERE deal_id=?',(deal_id,)).fetchone()[0]==2:return state
        if not d.get('documents_link'):
            return {'state':'error','message':'У колонці T немає посилання на документи покупця.'}
        if not SOURCE_DOCUMENT_SLOTS.acquire(blocking=False):return {'state':'busy','message':'Черга обробки документів.'}
        signature=source_signature(d);SOURCE_DOCUMENT_JOBS[deal_id]=signature
        state={'state':'processing','signature':signature,'checked_at':time.time(),'processed':0,'total':0,'message':'Читаю комплект із колонки T та звіряю ПІБ із C.'}
        c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',('source-documents:'+deal_id,encode(state)))
    threading.Thread(target=source_document_worker,args=(deal_id,signature,actor),daemon=True).start()
    return state


def isolated_source_extraction(path):
    code="import sys,json;from pathlib import Path;"+('import resource;resource.setrlimit(resource.RLIMIT_AS,(768*1024*1024,768*1024*1024));' if os.name!='nt' else '')+"import app;print(json.dumps(app.extraction(Path(sys.argv[1]),source=True)))"
    try:
        r=subprocess.run([sys.executable,'-c',code,str(path)],cwd=ROOT,capture_output=True,timeout=220,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if r.returncode or len(r.stdout)>600000:raise ValueError()
        return json.loads(r.stdout)
    except Exception:return {'method':'ocr','text':'','error':'Не вдалося розпізнати документ. Заповніть відсутні дані вручну.'}


def verified_document_reference(d):
    path=ROOT/'.local/document-reference.json'
    if not path.exists():return {}
    try:
        cfg=json.loads(path.read_text(encoding='utf-8'))
        actual=sorted(hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'inputs').glob('*.docx'))
        actual.append(hashlib.sha256((ROOT/'templates/invoice.xlsx').read_bytes()).hexdigest())
        if actual!=cfg['template_hashes']:return {}
        return {'seller_confirmed':True,'address':cfg.get('object_addresses',{}).get(d.get('building'))}
    except Exception:return {}


def apply_source_candidates(c,d,records,result):
    before=encode(d);confirmed=d.setdefault('confirmed',{});auto=d.setdefault('automatic_fields',{});issues=list(result['issues']);conflicting_fields=list(result['conflicts'])
    candidates={k:v['value'] for k,v in result['fields'].items()}
    candidates['name']=source_party_name(d.get('source_buyer_name') or d['name'])
    if re.fullmatch(r'(?:\+380\d{9}|0\d{9})',re.sub(r'[ ()-]','',d.get('phone',''))):candidates['phone']=d['phone']
    candidates.update({k:v for k,v in verified_document_reference(d).items() if v})
    for field,value in candidates.items():
        if confirmed.get(field) and field not in auto:
            if d.get(field)!=value:
                issues.append('Поле «'+PARTY_LABELS.get(field,field)+'» відрізняється від документів. Перевірте його.');conflicting_fields.append(field)
            continue
        # Unconfirmed manual input also has priority over an OCR proposal.
        if d.get(field) and field not in auto and field not in ('name','phone','seller_confirmed'):continue
        d[field]=value;confirmed[field]=True;auto[field]={'value':value,'signature':source_signature(d)}
    # An earlier automatically filled value loses confirmation if its evidence
    # disappears or becomes contradictory. Confirmed manual input is untouched.
    for field in list(auto):
        if field not in candidates:
            confirmed[field]=False;del auto[field]
    evidence=digest([source_signature(d),sorted((a['sha'],a['id']) for a in records)])
    reviewed=d.get('reviewed_document_evidence')==evidence
    if reviewed:issues=[];conflicting_fields=[]
    identity=('name','birth_date','citizenship','tax_id','registration','phone')
    d['party_confirmed']=(bool(result['matched']) or reviewed) and all(d.get(k) and confirmed.get(k) for k in identity) and not issues
    confirmed['party_confirmed']=d['party_confirmed']
    d['document_issues']=issues;d['document_conflicts']=sorted(set(conflicting_fields));d['document_evidence']=evidence
    d['document_sources']=result['fields']
    stored={k:v for k,v in d.items() if k not in ('id','rev','invoice_number')}
    if encode(d)!=before:
        c.execute('UPDATE deals SET data=?,rev=rev+1 WHERE id=?',(encode(stored),d['id']))
        audit(c,d['id'],'Реквізити звірено з документами Сторони 2','source-documents')


def source_document_worker(deal_id,signature,actor):
    records=[];errors=[];size=0
    def update(state):
        with db() as c:
            d=get_deal(c,deal_id)
            if source_signature(d)!=signature:return False
            c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',('source-documents:'+deal_id,encode({**state,'signature':signature,'checked_at':time.time(),'checked_day':now().date().isoformat()})))
        return True
    try:
        with db() as c:d=get_deal(c,deal_id)
        targets=documents.drive_files(d['documents_link'])
        for index,target in enumerate(targets):
            if not update({'state':'processing','processed':index,'total':len(targets),'message':'Звіряю документи покупця за ПІБ із колонки C.'}):return
            try:
                name,raw,ext=documents.drive_download(target);size+=len(raw)
                if size>50*1024*1024:raise documents.SourceDocumentError('Комплект перевищує 50 МБ. Потрібна перевірка джерела.')
                sha=hashlib.sha256(raw).hexdigest()
                with db() as c:
                    old=next((dict(r) for r in c.execute("SELECT * FROM attachments WHERE deal_id=? AND path=''",(deal_id,)) if json.loads(r['extraction']).get('source_id')==target['id']),None)
                if old and old['sha']==sha and not json.loads(old['extraction']).get('error'):ex=json.loads(old['extraction'])
                else:
                    temp_root=DATA/'source-temp';temp_root.mkdir(exist_ok=True)
                    if temp_root.is_symlink() or temp_root.resolve().parent!=DATA.resolve():raise ValueError('unsafe_temp')
                    with tempfile.TemporaryDirectory(prefix='job-',dir=temp_root) as folder:
                        file=Path(folder)/('document'+ext);file.write_bytes(raw);ex=isolated_source_extraction(file)
                del raw
                ex.update(automatic=True,source_id=target['id'],source_url=target['url'],signature=signature)
                if ex.get('error'):errors.append('Файл '+str(index+1)+': '+ex['error'])
                if ex.get('page_errors'):errors.append('Файл '+str(index+1)+': не всі сторінки вдалося прочитати. Відсутні реквізити потрібно доповнити.')
                aid=old['id'] if old else uid()
                with db() as c:
                    if source_signature(get_deal(c,deal_id))!=signature:return
                    c.execute('INSERT OR REPLACE INTO attachments VALUES(?,?,?,?,?,?,?,?)',(aid,deal_id,name,'',sha,actor,utc(),encode(ex)))
                records.append({'id':aid,'sha':sha,'extraction':ex})
            except documents.SourceDocumentError as e:errors.append('Файл '+str(index+1)+': '+str(e))
        result=party_candidates(d.get('source_buyer_name') or d['name'],[a for a in records if not a['extraction'].get('error')])
        with db() as c:
            current=get_deal(c,deal_id)
            if source_signature(current)!=signature:return
            for a in records:
                a['extraction']['matched_party']=[p['page'] for p in result['matched'] if p['attachment_id']==a['id']]
                c.execute('UPDATE attachments SET extraction=? WHERE id=?',(encode(a['extraction']),a['id']))
            apply_source_candidates(c,current,records,result)
            keep={a['id'] for a in records}
            for r in c.execute("SELECT id FROM attachments WHERE deal_id=? AND path=''",(deal_id,)).fetchall():
                if r[0] not in keep:c.execute('DELETE FROM attachments WHERE id=?',(r[0],))
        message='Знайдені реквізити Сторони 2 заповнено за ПІБ із колонки C.' if result['matched'] else 'Немає однозначного збігу з ПІБ у C. Заповніть відсутні реквізити.'
        update({'state':'done','processed':len(targets),'total':len(targets),'matched_pages':len(result['matched']),'message':message,'issues':result['issues']+errors})
        process_ready()
    except Exception as e:
        message=str(e) if isinstance(e,documents.SourceDocumentError) else 'Не вдалося обробити комплект із T. Повторіть читання або заповніть відсутні реквізити.'
        with db() as c:
            current=get_deal(c,deal_id)
            if source_signature(current)==signature:
                stored={k:v for k,v in current.items() if k not in ('id','rev','invoice_number')};stored['document_issues']=[message]
                c.execute('UPDATE deals SET data=?,rev=rev+1 WHERE id=?',(encode(stored),deal_id))
        update({'state':'error','message':message})
    finally:
        with LOCK:SOURCE_DOCUMENT_JOBS.pop(deal_id,None)
        SOURCE_DOCUMENT_SLOTS.release()


def prepare_source_documents():
    if DEMO:return
    with db() as c:ids=[r[0] for r in c.execute('SELECT id FROM deals') if get_deal(c,r[0]).get('deal_date') in (now().date().isoformat(),next_business(now().date()).isoformat())]
    for deal_id in ids:start_source_documents(deal_id)


def pilot_paths(day):
    parsed=parse_date(day)
    if not parsed or parsed.isoformat()!=day or parsed>datetime.now(KYIV).date() or parsed.year<2000:raise RuleError('Оберіть наявну дату тестових угод.')
    folder=(DATA/'pilot-workspaces'/day).resolve();config=(CONFIG/'pilot'/day).resolve()
    if not folder.is_relative_to(DATA.resolve()) or not config.is_relative_to(CONFIG.resolve()):raise RuleError('Некоректний тестовий простір.')
    return folder,config


def pilot_has_editors():
    settings=CONFIG/'pilot.json'
    if not settings.exists():return False
    day=json.loads(settings.read_text(encoding='utf-8'))['rate_date'];folder,_=pilot_paths(day);path=folder/'registry.sqlite3'
    if not path.exists():return False
    with sqlite3.connect(path) as c:return bool(c.execute('SELECT 1 FROM editor_sessions WHERE closed=0 AND expires>?',(time.time(),)).fetchone())


def stop_pilot():
    global PILOT_PROCESS
    with PILOT_LOCK:
        process=PILOT_PROCESS;PILOT_PROCESS=None
        if process and process.poll() is None:
            process.terminate()
            try:process.wait(timeout=8)
            except subprocess.TimeoutExpired:process.kill();process.wait(timeout=5)


def ensure_pilot():
    global PILOT_PROCESS
    if PILOT:raise APIError(404,'Недоступно')
    settings=CONFIG/'pilot.json'
    if not settings.exists():raise APIError(404,'Тестовий простір ще не підготовлено.')
    with PILOT_LOCK:
        if PILOT_PROCESS and PILOT_PROCESS.poll() is None:return
        cfg=json.loads(settings.read_text(encoding='utf-8'));folder,config=pilot_paths(cfg['rate_date'])
        env={**os.environ,'MON_DEMO':'0','MON_PILOT':'1','MON_PILOT_DATE':cfg['rate_date'],'MON_CONFIG_DIR':str(config),'MON_DATA':str(folder),'MON_BIND':'127.0.0.1','MON_PORT':str(PILOT_PORT),'MON_PUBLIC_URL':PUBLIC+'/test','MON_INTERNAL_URL':INTERNAL+'/test','MON_RATE_TOKEN':'','MON_PILOT_PARENT_PID':str(os.getpid())}
        with (CONFIG/'pilot-service.log').open('ab') as log:
            PILOT_PROCESS=subprocess.Popen([sys.executable,str(ROOT/'app.py')],cwd=ROOT,env=env,stdout=log,stderr=log,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        deadline=time.monotonic()+12
        while time.monotonic()<deadline:
            if PILOT_PROCESS.poll() is not None:raise APIError(503,'Тестовий простір не запустився. Зверніться до розробника.')
            try:
                with urllib.request.urlopen(f'http://127.0.0.1:{PILOT_PORT}/health',timeout=1) as response:
                    if json.load(response).get('pilot'):return
            except Exception:pass
            threading.Event().wait(.15)
        raise APIError(503,'Тестовий простір запускається. Повторіть за кілька секунд.')


def setup_pilot(payload,actor):
    if PILOT or DEMO:raise APIError(404,'Недоступно')
    day=payload.get('rate_date','');folder,config=pilot_paths(day)
    try:
        value=Decimal(str(payload['mon_rate']))
        if not value.is_finite() or not 0<value<10000:raise ValueError()
    except Exception:raise RuleError('Укажіть тестовий курс числом.')
    names=payload.get('users',[])
    if not isinstance(names,list) or not 1<=len(names)<=10 or not all(isinstance(v,str) for v in names):raise RuleError('Оберіть користувачів тестового простору.')
    label=str(payload.get('rate_label','Тестовий курс, заданий для перевірки'))[:200]
    with db() as c:
        users=[{k:r[k] for k in ('id','username','name','password')} for r in c.execute('SELECT * FROM users WHERE enabled=1') if r['username'] in names]
        if len(users)!=len(set(names)):raise RuleError('Користувача не знайдено або його доступ вимкнено.')
    seed={'users':users,'mon_rate':format(value,'f'),'rate_label':label,'selected_at':utc()}
    with PILOT_LOCK:
        previous=config/'pilot-seed.json'
        same=False
        if previous.exists():
            old=json.loads(previous.read_text(encoding='utf-8'));same=all(old.get(k)==seed[k] for k in ('users','mon_rate','rate_label'))
        if not same:
            if pilot_has_editors():raise APIError(409,'Спершу збережіть і закрийте тестові документи.')
            stop_pilot();folder.mkdir(parents=True,exist_ok=True);config.mkdir(parents=True,exist_ok=True)
            for name,value in (('pilot-seed.json',encode(seed)),('office-secret',OFFICE_SECRET)):
                target=config/name;target.write_text(value,encoding='utf-8');target.chmod(0o600)
        settings=CONFIG/'pilot.json';settings.write_text(encode({'rate_date':day}),encoding='utf-8');settings.chmod(0o600)
        ensure_pilot()
    with db() as c:audit(c,None,'Тест на реальних даних підготовлено',actor,day)
    return {'url':PUBLIC+'/test/','rate_date':day,'is_test':True,'users':len(users)}


def pilot_parent_watch():
    parent=int(os.environ.get('MON_PILOT_PARENT_PID','0'))
    while parent and os.name!='nt':
        threading.Event().wait(5)
        if os.getppid()!=parent:
            if SERVER:SERVER.shutdown()
            return

class Handler(BaseHTTPRequestHandler):
    server_version='MON'
    def log_message(self,*args):pass
    def send(self,status,data,content_type='application/json; charset=utf-8',headers=None):
        raw=encode(data).encode() if content_type.startswith('application/json') else data.encode() if isinstance(data,str) else data
        self.send_response(status)
        self.send_header('Content-Type',content_type);self.send_header('Content-Length',str(len(raw)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer');self.send_header('X-Frame-Options','SAMEORIGIN')
        for k,v in (headers or {}).items():self.send_header(k,v)
        self.end_headers();self.wfile.write(raw)
    def body(self):
        n=int(self.headers.get('Content-Length','0'))
        if n>30*1024*1024:raise APIError(413,'Файл завеликий')
        try:return json.loads(self.rfile.read(n)) if n else {}
        except Exception:raise APIError(400,'Некоректний JSON')
    def auth(self,write=False):
        cookie=http.cookies.SimpleCookie(self.headers.get('Cookie',''));sid=cookie.get('mon_pilot_session' if PILOT else 'mon_session')
        with db() as c:
            r=c.execute('SELECT u.*,l.csrf,l.expires FROM logins l JOIN users u ON u.id=l.user_id WHERE l.token=? AND u.enabled=1',(sid.value if sid else '',)).fetchone()
        if not r or r['expires']<time.time():raise APIError(401,'Увійдіть до реєстру')
        if write and not hmac.compare_digest(self.headers.get('X-CSRF-Token',''),r['csrf']):raise APIError(403,'Оновіть сторінку та повторіть дію')
        return dict(r)
    def do_GET(self):self.dispatch('GET')
    def do_POST(self):self.dispatch('POST')
    def do_PUT(self):self.dispatch('PUT')
    def dispatch(self,method):
        try:self.route(method)
        except APIError as e:self.send(e.status,{'error':e.message})
        except RuleError as e:self.send(422,{'error':str(e)})
        except sqlite3.IntegrityError:self.send(409,{'error':'Запис уже існує. Оновіть сторінку.'})
        except (ValueError,KeyError,TypeError):self.send(400,{'error':'Перевірте формат і обов’язкові поля запиту'})
        except (BrokenPipeError,ConnectionResetError):pass
        except Exception:self.send(500,{'error':'Внутрішня помилка. Дані не змінено; спробуйте повторно.'})
    def route(self,method):
        url=urllib.parse.urlparse(self.path);path=url.path;q=urllib.parse.parse_qs(url.query)
        if not PILOT and path=='/test':return self.send(308,b'','text/plain',{'Location':'/test/'})
        if not PILOT and path.startswith('/test/'):
            ensure_pilot()
            class NoRedirect(urllib.request.HTTPRedirectHandler):
                def redirect_request(self,*args,**kwargs):return None
            size=int(self.headers.get('Content-Length','0'))
            if size>30*1024*1024:raise APIError(413,'Запит завеликий')
            headers={k:self.headers[k] for k in ('Content-Type','X-CSRF-Token') if self.headers.get(k)}
            cookies=http.cookies.SimpleCookie(self.headers.get('Cookie',''))
            if cookies.get('mon_pilot_session'):headers['Cookie']='mon_pilot_session='+cookies['mon_pilot_session'].value
            request=urllib.request.Request(f'http://127.0.0.1:{PILOT_PORT}'+self.path[len('/test'):],data=self.rfile.read(size) if method!='GET' else None,headers=headers,method=method)
            try:response=urllib.request.build_opener(NoRedirect()).open(request,timeout=90)
            except urllib.error.HTTPError as e:response=e
            except Exception:raise APIError(503,'Тестовий простір тимчасово недоступний.')
            with response:
                raw=response.read(64*1024*1024+1)
                if len(raw)>64*1024*1024:raise APIError(413,'Файл завеликий')
                self.send_response(response.status)
                for name in ('Content-Type','Cache-Control','X-Content-Type-Options','Referrer-Policy','X-Frame-Options','Location','Content-Disposition','Set-Cookie'):
                    for value in response.headers.get_all(name,[]):self.send_header(name,value)
                self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
            return
        if method=='GET' and path in ('/','/app.js','/style.css','/editor.html'):
            name={'/':'index.html'}.get(path,path[1:]);mime='text/html; charset=utf-8' if name.endswith('html') else 'text/javascript; charset=utf-8' if name.endswith('js') else 'text/css; charset=utf-8'
            return self.send(200,(ROOT/'web'/name).read_bytes(),mime)
        if method=='GET' and path=='/health':return self.send(200,{'ok':True,'demo':DEMO,'pilot':PILOT})
        if method=='GET' and path=='/api/version':return self.send(200,{'version':updater.current(ROOT)})
        if method=='POST' and path=='/api/login':
            b=self.body();user=b.get('username','');password=b.get('password','')
            with db() as c:
                # Persistent bounded attempt counter; no usernames / IPs in logs.
                attempts=c.execute('SELECT value FROM settings WHERE key=?',('login_attempts',)).fetchone();a=json.loads(attempts[0]) if attempts else {'time':time.time(),'count':0}
                if time.time()-a['time']>60:a={'time':time.time(),'count':0}
                if a['count']>=20:raise APIError(429,'Забагато спроб входу. Зачекайте хвилину.')
                r=c.execute('SELECT * FROM users WHERE username=? AND enabled=1',(user,)).fetchone()
                valid=r and check_password(password,r['password'])
                if not valid:
                    a['count']+=1;c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',('login_attempts',encode(a)))
            if not valid:raise APIError(401,'Неправильний логін або пароль')
            token=secrets.token_urlsafe(40);csrf=secrets.token_urlsafe(30)
            with db() as c:c.execute('INSERT INTO logins VALUES(?,?,?,?)',(token,r['id'],time.time()+28800,csrf))
            return self.send(200,{'name':r['name'],'csrf':csrf},headers={'Set-Cookie':('mon_pilot_session' if PILOT else 'mon_session')+'='+token+'; HttpOnly; SameSite=Strict; Path='+('/test/' if PILOT else '/')+('; Secure' if PUBLIC.startswith('https') else '')})
        if method=='POST' and path=='/integrations/mon-rate':
            if not RATE_TOKEN:raise APIError(503,'Приймач курсу не налаштований')
            if not hmac.compare_digest(self.headers.get('Authorization',''),'Bearer '+RATE_TOKEN):raise APIError(401,'Неавторизований запит')
            if DEMO:raise APIError(409,'Робочі події не приймаються у демо')
            return self.send(200,receive_rate(self.body()))
        if path.startswith('/office/'):
            return self.office_route(method,path,q)
        user=self.auth(method!='GET');actor=user['id']
        if path=='/api/session':return self.send(200,{'id':actor,'name':user['name'],'csrf':user['csrf'],'demo':DEMO,'pilot':PILOT,'pilot_date':PILOT_DAY if PILOT else None,'now':now().isoformat(),'storage':'local','full_rights':True})
        if path=='/api/pilot-setup' and method=='POST':return self.send(200,setup_pilot(self.body(),actor))
        if path=='/api/updates':
            if PILOT:return self.send(200,{'state':'current','current_version':updater.current(ROOT)})
            if method=='GET':return self.send(200,updater.status(ROOT))
            if method=='POST':return self.send(200,updater.check(ROOT))
        if path=='/api/updates/apply' and method=='POST':
            if PILOT:raise APIError(409,'Оновлення встановлює розробник у робочому просторі.')
            if pilot_has_editors():raise APIError(409,'Спершу збережіть і закрийте тестові редактори документів.')
            if SOURCE_DOCUMENT_JOBS:raise APIError(409,'Триває обробка документів. Оновлення можна встановити після її завершення.')
            state=updater.status(ROOT)
            if state.get('state')!='staged':raise APIError(422,'Немає перевіреної нової версії для встановлення')
            if os.environ.get('MON_SUPERVISED')!='1':raise APIError(409,'Закрийте програму та запустіть через штатний ярлик для встановлення оновлення')
            with db() as c:
                if c.execute('SELECT 1 FROM editor_sessions WHERE closed=0 AND expires>?',(time.time(),)).fetchone():raise APIError(409,'Спершу збережіть і закрийте відкриті редактори документів')
                audit(c,None,'Запитано встановлення оновлення',actor)
            (ROOT/'.local/updates/restart-request').write_text('verified-update',encoding='ascii')
            self.send(200,{'restarting':True})
            def restart():
                time.sleep(.5)
                if SERVER:SERVER.shutdown()
            threading.Thread(target=restart,daemon=True).start();return
        if path=='/api/finance-sync' and method=='POST':return self.send(200,sync_finance(self.body().get('rate_date')))
        if path=='/api/calculated-rate' and method=='POST':return self.send(200,refresh_calculated(self.body()['rate_date']))
        if path=='/api/rate-comparison' and method=='GET':
            day=q.get('rate_date',[now().date().isoformat()])[0]
            with db() as c:value=mon_source.compare(get_rate(c,day),get_calculated(c,day))
            return self.send(200,{'rate_date':day,**value})
        if path=='/api/logout' and method=='POST':
            with db() as c:c.execute('DELETE FROM logins WHERE user_id=?',(actor,))
            return self.send(200,{'ok':True},headers={'Set-Cookie':('mon_pilot_session' if PILOT else 'mon_session')+'=; HttpOnly; SameSite=Strict; Path='+('/test/' if PILOT else '/')+'; Max-Age=0'})
        if path=='/api/users':
            if method=='GET':
                with db() as c:out=[dict(r) for r in c.execute('SELECT id,username,name,enabled FROM users')]
                return self.send(200,out)
            b=self.body();add_user(b['username'],b['name'],b['password']);return self.send(201,{'ok':True})
        if path=='/api/deals' and method=='GET':
            with db() as c:out=[view(c,get_deal(c,r[0])) for r in c.execute('SELECT id FROM deals')]
            out.sort(key=lambda d:(d.get('deal_date') or '',d['id']))
            return self.send(200,out)
        if path=='/api/refresh' and method=='POST':return self.send(200,refresh_source(actor))
        if path=='/api/numbering' and method=='POST':
            b=self.body();day=b['day'];n=int(b['start'])
            if not parse_date(day) or n<1 or n>100000:raise RuleError('Перевірте дату й стартовий номер')
            with db() as c:
                old=c.execute('SELECT next_number FROM numbering WHERE day=?',(day,)).fetchone()
                max_used=c.execute('SELECT COALESCE(MAX(sequence),0) FROM deals WHERE invoice_date=?',(day,)).fetchone()[0]
                if n<=max_used or (old and n<old[0]):raise APIError(409,'Номер уже використаний або нижчий за підтверджений старт')
                c.execute('INSERT OR REPLACE INTO numbering VALUES(?,?,?)',(day,n,actor));audit(c,None,'Нумерацію підтверджено',actor,day)
            process_ready();return self.send(200,{'ok':True})
        if path=='/api/rates' and method=='GET':
            with db() as c:out=[get_rate(c,r[0]) for r in c.execute('SELECT rate_date FROM pilot_rates ORDER BY rate_date DESC')] if PILOT else [dict(r) for r in c.execute('SELECT * FROM rates ORDER BY rate_date DESC')]
            return self.send(200,out)
        if path=='/api/demo/rate' and method=='POST':
            if not DEMO:raise APIError(404,'Недоступно')
            return self.send(200,receive_rate(self.body()))
        if path=='/api/import-issues' and method=='GET':
            with db() as c:out=[{**dict(r),'payload':json.loads(r['payload'])} for r in c.execute('SELECT * FROM import_issues WHERE resolved=0')]
            return self.send(200,out)
        if path.startswith('/api/import-issues/') and method=='POST':
            issue_id=path.split('/')[-1];b=self.body()
            with db() as c:
                r=c.execute('SELECT * FROM import_issues WHERE id=? AND resolved=0',(issue_id,)).fetchone()
                if not r:raise APIError(404,'Запис не знайдено')
                d=json.loads(r['payload']);target=b.get('deal_id')
                if target:
                    old=get_deal(c,target);confirmed=old.get('confirmed',{})
                    for k,v in d.items():
                        if not confirmed.get(k):old[k]=v
                    c.execute('UPDATE deals SET source_key=?,object_key=?,data=?,rev=rev+1 WHERE id=?',(d['source_key'],d['object_key'],encode(old),target))
                else:
                    target=uid();d['confirmed']={};d['demo']=DEMO
                    # Manager gives a distinct identity when same natural key is ambiguous.
                    d['source_key']+=':manual:'+target
                    c.execute('INSERT INTO deals(id,source_key,object_key,data) VALUES(?,?,?,?)',(target,d['source_key'],d['object_key'],encode(d)))
                c.execute('UPDATE import_issues SET resolved=1 WHERE id=?',(issue_id,));audit(c,target,'Зіставлення підтверджено',actor)
            return self.send(200,{'deal_id':target})
        parts=path.strip('/').split('/')
        if len(parts)>=3 and parts[:2]==['api','deals']:
            deal_id=parts[2]
            if len(parts)==3:
                with db() as c:
                    d=get_deal(c,deal_id)
                    if method=='PUT':
                        b=self.body()
                        if b.get('rev')!=d['rev']:raise APIError(409,'Картку змінив інший менеджер. Оновіть сторінку.')
                        allowed={'name','birth_date','citizenship','tax_id','registration','phone','address','seller_confirmed','party_confirmed','terms','custom_schedule','schedule_confirmed','contract_number','agreed_percent','kind','deal_date','total_usd','first_usd','unit','source_issues'}
                        changed=[]
                        for k,v in b.get('fields',{}).items():
                            if k not in allowed:raise RuleError('Поле не можна змінювати: '+k)
                            if d.get(k)!=v:changed.append(k)
                            d[k]=v
                            d.get('automatic_fields',{}).pop(k,None)
                        confirmed=d.setdefault('confirmed',{})
                        for k,v in b.get('confirmed',{}).items():
                            if k in allowed:confirmed[k]=bool(v)
                        resolve_source_amounts(d)
                        identity=('name','birth_date','citizenship','tax_id','registration','phone')
                        d['party_confirmed']=all(d.get(k) and confirmed.get(k) for k in identity)
                        confirmed['party_confirmed']=d['party_confirmed']
                        if b.get('documents_reviewed'):
                            d['document_issues']=[];d['document_conflicts']=[];d['reviewed_document_evidence']=d.get('document_evidence')
                        stored={k:v for k,v in d.items() if k not in ('id','rev','invoice_number')}
                        c.execute('UPDATE deals SET data=?,rev=rev+1 WHERE id=?',(encode(stored),deal_id));audit(c,deal_id,'Поля підтверджено',actor,','.join(changed))
                        d=get_deal(c,deal_id)
                if method=='PUT':process_ready()
                with db() as c:return self.send(200,view(c,get_deal(c,deal_id)))
            action=parts[3]
            if action=='source-documents':
                if method=='POST':return self.send(200,start_source_documents(deal_id,actor,bool(self.body().get('force'))))
                if method=='GET':
                    with db() as c:return self.send(200,source_document_status(c,get_deal(c,deal_id)))
            if action=='revalidate' and method=='POST':
                with db() as c:
                    d=get_deal(c,deal_id);rate=get_rate(c,d.get('deal_date'))
                    if not rate or rate['conflict']:raise APIError(422,'Потрібен підтверджений курс на дату угоди')
                    calc=schedule(d,rate['mon_rate'])
                    heads=c.execute('SELECT v.* FROM heads h JOIN versions v ON h.version_id=v.id WHERE h.deal_id=?',(deal_id,)).fetchall()
                    for v in heads:
                        errors=documents.validate(Path(v['path']).read_bytes(),v['kind'],d,calc,d['invoice_number'])
                        c.execute('UPDATE versions SET valid=?,errors=? WHERE id=?',(int(not errors),encode(errors),v['id']))
                    audit(c,deal_id,'Контроль файлів повторено',actor)
                return self.send(200,{'ok':True})
            if action=='generate' and method=='POST':return self.send(200,generate(deal_id,actor,self.body().get('rev')))
            if action=='history' and method=='GET':
                with db() as c:
                    get_deal(c,deal_id)
                    versions=[{k:v for k,v in dict(r).items() if k!='path'} for r in c.execute('SELECT v.*,u.name AS author_name FROM versions v LEFT JOIN users u ON u.id=v.author WHERE deal_id=? ORDER BY v.rowid DESC',(deal_id,))]
                    events=[dict(r) for r in c.execute('SELECT a.*,u.name AS author_name FROM audit a LEFT JOIN users u ON u.id=a.author WHERE deal_id=? ORDER BY a.id DESC',(deal_id,))]
                return self.send(200,{'versions':versions,'events':events})
            if action=='versions' and method=='POST':
                b=self.body()
                with db() as c:
                    d=get_deal(c,deal_id);v=c.execute('SELECT * FROM versions WHERE id=? AND deal_id=?',(b['version_id'],deal_id)).fetchone()
                    if not v:raise APIError(404,'Версію не знайдено')
                    h=c.execute('SELECT version_id FROM heads WHERE deal_id=? AND kind=?',(deal_id,v['kind'])).fetchone()
                    if h[0]!=b.get('expected_head'):raise APIError(409,'Поточну версію вже змінено')
                    if c.execute('SELECT 1 FROM editor_sessions WHERE deal_id=? AND closed=0 AND expires>?',(deal_id,time.time())).fetchone():raise APIError(409,'Спершу закрийте редактор')
                    g=c.execute('SELECT * FROM generations WHERE id=?',(v['generation_id'],)).fetchone();rate=get_rate(c,d['deal_date'])
                    if g['fingerprint']!=fingerprint(d,rate):raise APIError(409,'Версія не відповідає поточній картці')
                    c.execute('UPDATE heads SET version_id=? WHERE deal_id=? AND kind=?',(v['id'],deal_id,v['kind']));audit(c,deal_id,'Версію вибрано',actor,v['kind'])
                return self.send(200,{'ok':True})
            if action=='download' and method=='GET':return self.download(deal_id,q,actor)
            if action=='editor' and method=='POST':return self.open_editor(deal_id,self.body(),actor,user['name'])
            if action=='attachments':
                with db() as c:get_deal(c,deal_id)
                if method=='GET':
                    with db() as c:
                        signature=source_signature(get_deal(c,deal_id))
                        out=[{k:v for k,v in dict(r).items() if k!='path'} for r in c.execute('SELECT * FROM attachments WHERE deal_id=?',(deal_id,)) if r['path'] or json.loads(r['extraction']).get('signature')==signature]
                    return self.send(200,out)
                raise APIError(404,'Документи отримуються автоматично з колонки T.')
        if path.startswith('/api/attachments/') and method=='GET':
            with db() as c:r=c.execute('SELECT * FROM attachments WHERE id=?',(parts[-1],)).fetchone()
            if not r:raise APIError(404,'Файл не знайдено')
            if not r['path']:
                target=documents.drive_target(json.loads(r['extraction'])['source_url'])
                return self.send(302,b'','text/plain',{'Location':target['url']})
            return self.send(200,Path(r['path']).read_bytes(),'application/octet-stream',{'Content-Disposition':"attachment; filename*=UTF-8''"+urllib.parse.quote(r['name'])})
        if path.startswith('/api/editor/') and method=='POST':
            sid=parts[2];action=parts[3];b=self.body()
            with db() as c:
                s=c.execute('SELECT * FROM editor_sessions WHERE id=? AND user_id=?',(sid,actor)).fetchone()
                if not s or s['closed'] or s['expires']<time.time():raise APIError(409,'Сеанс закритий або прострочений')
                if action=='heartbeat':c.execute('UPDATE editor_sessions SET expires=? WHERE id=?',(time.time()+1800,sid))
            if action=='save':
                result=office_command({'c':'forcesave','key':s['doc_key']})
                if result.get('error') not in (0,4):raise APIError(503,'Редактор ще не готовий до збереження')
                return self.send(200,{'ok':True,'pending':result.get('error')==0})
            if action=='close':
                with db() as c:c.execute('UPDATE editor_sessions SET closed=1 WHERE id=?',(sid,))
                return self.send(200,{'ok':True})
            return self.send(200,{'ok':True})
        raise APIError(404,'Не знайдено')

    def download(self,deal_id,q,actor):
        with LOCK:
            with db() as c:
                d=get_deal(c,deal_id);rate=get_rate(c,d.get('deal_date'));kind=q.get('kind',['bundle'])[0];version=q.get('version',[None])[0]
                if version:
                    v=c.execute('SELECT * FROM versions WHERE id=? AND deal_id=?',(version,deal_id)).fetchone()
                    if not v:raise APIError(404,'Версію не знайдено')
                    out=[v]
                else:
                    out=[]
                    for k in (('docx','xlsx') if kind=='bundle' else (kind,)):
                        head=c.execute('SELECT v.* FROM heads h JOIN versions v ON h.version_id=v.id WHERE h.deal_id=? AND h.kind=?',(deal_id,k)).fetchone()
                        if not head:raise APIError(422,'Комплект ще не створено')
                        # Default download never silently bypasses a bad latest head.
                        if not head['valid']:raise APIError(422,'Виправте розбіжності документа перед завантаженням')
                        g=c.execute('SELECT fingerprint FROM generations WHERE id=?',(head['generation_id'],)).fetchone()
                        if g['fingerprint']!=fingerprint(d,rate):raise APIError(409,'Документ не відповідає поточним даним картки')
                        out.append(head)
                    if len({v['generation_id'] for v in out})>1:raise APIError(409,'Документи належать різним розрахункам')
                audit(c,deal_id,'Файл завантажено',actor,'history' if version else kind)
            if len(out)==1:
                raw=Path(out[0]['path']).read_bytes();ext=out[0]['kind'];mime='application/vnd.openxmlformats-officedocument.wordprocessingml.document' if ext=='docx' else 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            else:
                stream=io.BytesIO()
                with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as z:
                    for v in out:z.writestr(('Додаток_2' if v['kind']=='docx' else 'Рахунок (перший внесок)')+'.'+v['kind'],Path(v['path']).read_bytes())
                raw=stream.getvalue();ext='zip';mime='application/zip'
            name=('TEST_' if DEMO or PILOT else '')+('Рахунок (перший внесок)_' if ext=='xlsx' else '')+(d.get('invoice_number') or deal_id).replace('/','_')+'.'+ext
            return self.send(200,raw,mime,{'Content-Disposition':"attachment; filename*=UTF-8''"+urllib.parse.quote(name)})

    def open_editor(self,deal_id,b,actor,name):
        kind=b['kind']
        if kind not in ('docx','xlsx'):raise RuleError('Непідтримуваний формат')
        with db() as c:
            d=get_deal(c,deal_id)
            h=c.execute('SELECT v.* FROM heads h JOIN versions v ON h.version_id=v.id WHERE h.deal_id=? AND h.kind=?',(deal_id,kind)).fetchone()
            if not h:raise APIError(422,'Документ ще не створено')
            if b.get('expected_head')!=h['id']:raise APIError(409,'Документ уже змінено. Оновіть картку.')
            if c.execute('SELECT 1 FROM editor_sessions WHERE deal_id=? AND kind=? AND closed=0 AND expires>?',(deal_id,kind,time.time())).fetchone():raise APIError(409,'Документ уже редагує менеджер. Збережіть і закрийте попередній сеанс.')
            sid=uid();key=uid();exp=time.time()+1800
            c.execute('INSERT INTO editor_sessions VALUES(?,?,?,?,?,?,?,?,0)',(sid,deal_id,kind,actor,h['id'],h['id'],key,exp))
            tok=sign({'purpose':'office','sid':sid,'exp':time.time()+28800})
            config={'documentType':'word' if kind=='docx' else 'cell','type':'desktop','height':'100%','width':'100%','document':{'fileType':kind,'key':key,'title':('ТЕСТОВИЙ ' if DEMO or PILOT else '')+('Додаток №2' if kind=='docx' else 'Рахунок (перший внесок)')+' '+d['invoice_number'],'url':INTERNAL+'/office/file?token='+tok,'permissions':{'edit':True,'download':False,'print':True}},'editorConfig':{'mode':'edit','lang':'uk','callbackUrl':INTERNAL+'/office/callback?token='+tok,'user':{'id':actor,'name':name},'customization':{'forcesave':True,'autosave':True,'compactHeader':True,'goback':{'url':PUBLIC,'text':'До реєстру'}}}}
            config['token']=sign(config,OFFICE_SECRET);audit(c,deal_id,'Редактор відкрито',actor,kind)
        return self.send(200,{'session_id':sid,'config':config,'office_url':OFFICE,'base_version':h['id']})

    def office_route(self,method,path,q):
        payload=verify(q.get('token',[''])[0])
        if payload.get('purpose')!='office':raise APIError(403,'Недостатньо прав')
        with db() as c:
            s=c.execute('SELECT s.*,u.enabled FROM editor_sessions s JOIN users u ON s.user_id=u.id WHERE s.id=?',(payload['sid'],)).fetchone()
            if not s or not s['enabled'] or s['closed'] or s['expires']<time.time():raise APIError(403,'Сеанс недійсний')
            if path=='/office/file' and method=='GET':
                v=c.execute('SELECT * FROM versions WHERE id=?',(s['base_version'],)).fetchone()
                return self.send(200,Path(v['path']).read_bytes(),'application/octet-stream')
        if path=='/office/callback' and method=='POST':
            b=self.body();bearer=self.headers.get('Authorization','').removeprefix('Bearer ')
            checked=verify(bearer or b.get('token',''),OFFICE_SECRET)
            signed=checked.get('payload',checked)
            for k in ('key','status','url'):
                if k in b and signed.get(k)!=b[k]:raise APIError(403,'Підпис callback не збігається')
            if b.get('key')!=s['doc_key']:raise APIError(403,'Невірний ключ документа')
            if b.get('status') not in (2,6):return self.send(200,{'error':0})
            u=urllib.parse.urlparse(b.get('url',''));allowed=urllib.parse.urlparse(OFFICE_INTERNAL)
            # Callback content URL is fetched exclusively from the configured office server.
            public=urllib.parse.urlparse(OFFICE)
            actual_port=u.port or (443 if u.scheme=='https' else 80)
            origins={(allowed.hostname,allowed.port or (443 if allowed.scheme=='https' else 80)),(public.hostname,public.port or (443 if public.scheme=='https' else 80))}
            if u.scheme not in ('http','https') or (u.hostname,actual_port) not in origins:raise APIError(403,'Неприпустима адреса файлу редактора')
            local=allowed.scheme+'://'+allowed.netloc+u.path+('?' + u.query if u.query else '')
            try:
                with urllib.request.urlopen(local,timeout=60) as r:data=r.read(30*1024*1024+1)
                if len(data)>30*1024*1024:raise ValueError()
            except Exception:raise APIError(503,'Не вдалося зберегти файл редактора')
            with db() as c:
                latest=c.execute('SELECT * FROM editor_sessions WHERE id=?',(s['id'],)).fetchone()
                h=c.execute('SELECT version_id FROM heads WHERE deal_id=? AND kind=?',(s['deal_id'],s['kind'])).fetchone()
                if latest['closed'] or latest['expires']<time.time() or h[0]!=latest['saved_head']:raise APIError(409,'Конфлікт версій. Файл не перезаписано.')
                prev=c.execute('SELECT * FROM versions WHERE id=?',(h[0],)).fetchone()
                if hashlib.sha256(data).hexdigest()!=prev['sha']:
                    g=c.execute('SELECT * FROM generations WHERE id=?',(prev['generation_id'],)).fetchone();d=get_deal(c,s['deal_id']);rate=get_rate(c,d['deal_date'])
                    calc=schedule(d,rate['mon_rate'])
                    vid,errors=put_version(c,s['deal_id'],s['kind'],g['id'],h[0],s['user_id'],data,'manual',d,calc,d['invoice_number'])
                    c.execute('UPDATE editor_sessions SET saved_head=?,expires=? WHERE id=?',(vid,time.time()+1800,s['id']))
                if b['status']==2:c.execute('UPDATE editor_sessions SET closed=1 WHERE id=?',(s['id'],))
            return self.send(200,{'error':0})
        raise APIError(404,'Не знайдено')

def run():
    global SERVER
    init();threading.Thread(target=scheduler,daemon=True).start()
    if not PILOT:threading.Thread(target=updater.background,daemon=True).start()
    else:threading.Thread(target=pilot_parent_watch,daemon=True).start()
    host=os.environ.get('MON_BIND','127.0.0.1')
    if host not in ('127.0.0.1','localhost') and not PUBLIC.startswith('https://') and os.environ.get('MON_ALLOW_LAN_HTTP')!='1':
        raise SystemExit('Для віддаленого доступу налаштуйте HTTPS або явно дозвольте HTTP у довіреній локальній мережі.')
    print('MON registry: '+PUBLIC+' · '+('PILOT' if PILOT else 'TEST' if DEMO else 'LIVE'),flush=True)
    SERVER=ThreadingHTTPServer((host,PORT),Handler)
    if not PILOT and (CONFIG/'pilot.json').exists():
        def resume_pilot():
            try:ensure_pilot()
            except Exception:pass
        threading.Thread(target=resume_pilot,daemon=True).start()
    try:SERVER.serve_forever()
    finally:SERVER.server_close();stop_pilot()

if __name__=='__main__':run()
