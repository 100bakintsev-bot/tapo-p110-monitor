"""Apply verified updates before opening app files and starting the registry."""
import os,socket,subprocess,sys
from pathlib import Path
import updater
root=Path(__file__).resolve().parent
for port in {18741,18743,int(os.environ.get('MON_PORT','18741'))}:
    try:
        with socket.create_connection(('127.0.0.1',port),timeout=1):
            raise SystemExit('Реєстр уже запущено. Відкрийте його в браузері; оновлення буде застосовано після закриття.')
    except (ConnectionRefusedError,TimeoutError,OSError):pass
guard=root/'.local/application.lock';guard.parent.mkdir(exist_ok=True)
with guard.open('a+b') as f:
    f.seek(0);f.write(b'0');f.flush();f.seek(0)
    if os.name=='nt':
        import msvcrt
        msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
    else:
        import fcntl
        fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
    while True:
        try:
            updater.check(root)
            updater.apply_pending(root)
        except Exception:
            print('Оновлення не встановлено. Відновлено попередню версію; локальні дані збережено.',flush=True)
        result=subprocess.call([sys.executable,str(root/'app.py')],cwd=root,env={**os.environ,'MON_SUPERVISED':'1'})
        request=root/'.local/updates/restart-request'
        if not request.exists():raise SystemExit(result)
        request.unlink()
