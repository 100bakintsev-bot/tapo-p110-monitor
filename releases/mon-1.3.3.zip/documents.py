"""Template-preserving OOXML package patches and control reconciliation."""
from copy import deepcopy
from datetime import date
from decimal import Decimal
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from lxml import etree as E
from core import cash

ROOT=Path(__file__).resolve().parent
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
S='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
NS={'w':W,'s':S}

def fmt(v):
    return f'{Decimal(v):,.2f}'.replace(',',' ').replace('.',',')

def dt(v):
    return date.fromisoformat(v).strftime('%d.%m.%Y')

def patch_package(source,changes):
    out=BytesIO()
    with ZipFile(source) as z, ZipFile(out,'w',ZIP_DEFLATED) as w:
        for info in z.infolist():
            w.writestr(info,changes.get(info.filename,z.read(info.filename)))
    return out.getvalue()

def text(node):
    return ''.join(node.itertext()) if node is None else ''.join(node.xpath('.//w:t/text()',namespaces=NS))

def set_text(node,value):
    ts=node.xpath('.//w:t',namespaces=NS)
    if not ts:
        p=node if node.tag==f'{{{W}}}p' else E.SubElement(node,f'{{{W}}}p')
        r=E.SubElement(p,f'{{{W}}}r');ts=[E.SubElement(r,f'{{{W}}}t')]
    ts[0].text=str(value);ts[0].set('{http://www.w3.org/XML/1998/namespace}space','preserve')
    for t in ts[1:]: t.text=''

def party_text(d):
    return ['Сторона-2','',d['name']+',',dt(d['birth_date'])+' року народження', '(громадянство: '+d['citizenship']+'),','реєстраційний номер облікової картки платника податків '+d['tax_id']+',','адреса реєстрації: '+d['registration'],'','т. '+d['phone'],'','','________________________________']

def docx(d,calc,number):
    templates=sorted((ROOT/'inputs').glob('*.docx'))
    # Source variants are selected by their real table capacity, not source buyers.
    def capacity(p):
        with ZipFile(p) as z:
            r=E.fromstring(z.read('word/document.xml'))
            return len(r.xpath('//w:body/w:tbl[1]/w:tr',namespaces=NS))
    templates.sort(key=capacity)
    source=templates[-1] if len(calc['rows'])>10 else templates[0]
    with ZipFile(source) as z:
        r=E.fromstring(z.read('word/document.xml'))
        body=r.find(f'{{{W}}}body'); paragraphs=body.findall(f'{{{W}}}p')
        set_text(paragraphs[2],f"{dt(d['deal_date'])} р. № {d.get('contract_number') or '___'}"+(' · ТЕСТОВА ЧЕРНЕТКА' if d.get('demo') else ' · ЧЕРНЕТКА' if not d.get('contract_number') else ''))
        table=body.findall(f'{{{W}}}tbl')[0]; rows=table.findall(f'{{{W}}}tr')
        pattern=deepcopy(rows[2]); total_row=deepcopy(rows[-1])
        for row in rows[2:]: table.remove(row)
        for i,payment in enumerate(calc['rows'],1):
            row=deepcopy(pattern)
            for cell,value in zip(row.findall(f'{{{W}}}tc'),[i,fmt(payment['usd']),fmt(payment['uah']),dt(payment['date'])]): set_text(cell,value)
            table.append(row)
        cells=total_row.findall(f'{{{W}}}tc')
        for cell,value in zip(cells,['Всього',fmt(calc['total_usd']),fmt(calc['total_uah'])]):set_text(cell,value)
        table.append(total_row)
        parties=body.findall(f'{{{W}}}tbl')[1]
        # Last cell is Party 2 in both reference structures (one has spacer cell).
        buyer=parties.xpath('./w:tr/w:tc',namespaces=NS)[-1]
        ps=buyer.findall(f'{{{W}}}p'); proto=deepcopy(ps[2] if len(ps)>2 else ps[0])
        for p in ps: buyer.remove(p)
        for line in party_text(d):
            p=deepcopy(proto);set_text(p,line);buyer.append(p)
        # Preserve source legal wording, signatures, styles, geometry, relationships.
        changes={'word/document.xml':E.tostring(r,xml_declaration=True,encoding='UTF-8',standalone=True)}
        if 'docProps/core.xml' in z.namelist():
            c=E.fromstring(z.read('docProps/core.xml'))
            for el in c:
                if E.QName(el).localname in ('creator','lastModifiedBy','title','subject','description','keywords'):el.text='MON registry'
            changes['docProps/core.xml']=E.tostring(c,xml_declaration=True,encoding='UTF-8',standalone=True)
    return patch_package(source,changes)

ONES=['','один','два','три','чотири','п’ять','шість','сім','вісім','дев’ять']
TEENS=['десять','одинадцять','дванадцять','тринадцять','чотирнадцять','п’ятнадцять','шістнадцять','сімнадцять','вісімнадцять','дев’ятнадцять']
TENS=['','','двадцять','тридцять','сорок','п’ятдесят','шістдесят','сімдесят','вісімдесят','дев’яносто']
HUNDREDS=['','сто','двісті','триста','чотириста','п’ятсот','шістсот','сімсот','вісімсот','дев’ятсот']
def plural(n,forms):return forms[2] if 11<=n%100<=14 else forms[0] if n%10==1 else forms[1] if 2<=n%10<=4 else forms[2]
def triple(n,female=False):
    a=[HUNDREDS[n//100]];n%=100
    if 10<=n<20:a.append(TEENS[n-10])
    else:a.extend([TENS[n//10],('одна' if n%10==1 else 'дві' if n%10==2 else ONES[n%10]) if female else ONES[n%10]])
    return ' '.join(x for x in a if x)
def words(v):
    v=cash(v);n=int(v);parts=[]
    for divider,forms,female in [(10**9,('мільярд','мільярди','мільярдів'),False),(10**6,('мільйон','мільйони','мільйонів'),False),(1000,('тисяча','тисячі','тисяч'),True)]:
        group,n=divmod(n,divider)
        if group:parts += [triple(group,female),plural(group,forms)]
    if n:parts.append(triple(n,True))
    return (' '.join(parts) if parts else 'нуль').capitalize()+' '+plural(int(v),('гривня','гривні','гривень'))+f' {int((v-int(v))*100):02d} копійок'

def purpose(d):
    vat='без ПДВ' if d['kind']=='квартира' else 'в т.ч. ПДВ'
    return f"Оплата згідно договору к-п МОН (другий продаж), за реєстр. № {d.get('contract_number') or '___'} від {dt(d['deal_date'])}, МОН ({d['kind']} {d['unit']}, {d['address']}), {vat}; {d['name']}; ІПН {d['tax_id']}"

def invoice_values(d,calc,number):
    return {'A1':f"Рахунок № {number} від {dt(d['deal_date'])} року"+(' · ТЕСТОВА ЧЕРНЕТКА' if d.get('demo') else ' · ЧЕРНЕТКА' if not d.get('contract_number') else ''),'C17':purpose(d),'C19':d['name'],'C23':Decimal(calc['first_uah']),'C24':'('+words(calc['first_uah'])+')','D25':(date.fromisoformat(d['deal_date'])-date(1899,12,30)).days,'C27':'ТЕСТОВИЙ ДОКУМЕНТ. Не використовувати для оплати.' if d.get('demo') else ''}

def print_layout(r):
    # Original XLS has no fit-to-page and splits the invoice across two sheets.
    # Preserve paper, margins, row/column layout; fit the existing form to one page.
    prop=r.find(f'{{{S}}}sheetPr')
    if prop is None:prop=E.Element(f'{{{S}}}sheetPr');r.insert(0,prop)
    setup=prop.find(f'{{{S}}}pageSetUpPr')
    if setup is None:setup=E.SubElement(prop,f'{{{S}}}pageSetUpPr')
    setup.set('fitToPage','1')
    page=r.find(f'{{{S}}}pageSetup')
    if page is None:page=E.SubElement(r,f'{{{S}}}pageSetup')
    page.attrib.pop('scale',None);page.set('fitToWidth','1');page.set('fitToHeight','1')
    row=r.find(f'.//{{{S}}}row[@r="25"]')
    if row is not None and float(row.get('ht','0'))<36:
        row.set('ht','36');row.set('customHeight','1')

def xlsx(d,calc,number):
    source=ROOT/'templates/invoice.xlsx'
    with ZipFile(source) as z:
        r=E.fromstring(z.read('xl/worksheets/sheet1.xml'))
        for coord,value in invoice_values(d,calc,number).items():
            c=r.find(f'.//{{{S}}}c[@r="{coord}"]')
            if c is None:raise RuntimeError('Template cell missing: '+coord)
            for el in list(c):c.remove(el)
            if isinstance(value,(Decimal,int)):
                c.attrib.pop('t',None);E.SubElement(c,f'{{{S}}}v').text=str(value)
            else:
                c.set('t','inlineStr');E.SubElement(E.SubElement(c,f'{{{S}}}is'),f'{{{S}}}t').text=str(value)
        print_layout(r)
        changes={'xl/worksheets/sheet1.xml':E.tostring(r,xml_declaration=True,encoding='UTF-8',standalone=True)}
        # Clear unreferenced sample strings so old buyer data does not remain in ZIP.
        if 'xl/sharedStrings.xml' in z.namelist():
            strings=E.fromstring(z.read('xl/sharedStrings.xml'))
            used={int(c.findtext(f'{{{S}}}v')) for c in r.findall(f'.//{{{S}}}c') if c.get('t')=='s'}
            for i,si in enumerate(strings):
                if i not in used:
                    for el in list(si):si.remove(el)
                    E.SubElement(si,f'{{{S}}}t').text=''
            changes['xl/sharedStrings.xml']=E.tostring(strings,xml_declaration=True,encoding='UTF-8',standalone=True)
        if 'docProps/core.xml' in z.namelist():
            props=E.fromstring(z.read('docProps/core.xml'))
            for el in props:
                if E.QName(el).localname in ('creator','lastModifiedBy','title','subject','description','keywords'):el.text='MON registry'
            changes['docProps/core.xml']=E.tostring(props,xml_declaration=True,encoding='UTF-8',standalone=True)
        return patch_package(source,changes)

def xlsx_cells(data):
    with ZipFile(BytesIO(data)) as z:
        strings=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            r=E.fromstring(z.read('xl/sharedStrings.xml'))
            strings=[''.join(si.itertext()) for si in r]
        r=E.fromstring(z.read('xl/worksheets/sheet1.xml'));out={}
        for c in r.findall(f'.//{{{S}}}c'):
            typ=c.get('t');v=c.findtext(f'{{{S}}}v')
            out[c.get('r')]=''.join(c.xpath('.//s:t/text()',namespaces=NS)) if typ=='inlineStr' else strings[int(v)] if typ=='s' and v is not None else v
        return out

def validate(data,kind,d,calc,number):
    errors=[]
    def compare(field,actual,expected):
        equal=actual==expected if isinstance(actual,Decimal) and isinstance(expected,Decimal) else str(actual or '').strip()==str(expected or '').strip()
        if not equal:errors.append({'field':field,'actual':str(actual),'expected':str(expected)})
    try:
        with ZipFile(BytesIO(data)) as z:
            if len(data)>30*1024*1024 or sum(i.file_size for i in z.infolist())>100*1024*1024:raise ValueError('File too large')
            if any('vbaProject' in x or 'externalLink' in x for x in z.namelist()):raise ValueError('External or macro content')
        if kind=='xlsx':
            cells=xlsx_cells(data)
            for coord,expected in invoice_values(d,calc,number).items():
                if coord=='C27':continue
                actual=cells.get(coord)
                if isinstance(expected,(Decimal,int)):
                    try: actual=Decimal(str(actual)); expected=Decimal(expected)
                    except Exception:pass
                compare('Рахунок!'+coord,actual,expected)
        else:
            with ZipFile(BytesIO(data)) as z:r=E.fromstring(z.read('word/document.xml'))
            paragraphs=r.xpath('//w:body/w:p',namespaces=NS)
            expected=f"{dt(d['deal_date'])} р. № {d.get('contract_number') or '___'}"
            if expected not in text(paragraphs[2]):compare('Word: дата / номер договору',text(paragraphs[2]),expected)
            tables=r.xpath('//w:body/w:tbl',namespaces=NS)
            rows=tables[0].findall(f'{{{W}}}tr')[2:]
            compare('Word: кількість платежів',len(rows)-1,len(calc['rows']))
            for i,(row,payment) in enumerate(zip(rows,calc['rows']),1):
                for col,(cell,v) in enumerate(zip(row.findall(f'{{{W}}}tc'),[str(i),fmt(payment['usd']),fmt(payment['uah']),dt(payment['date'])])):
                    compare(f'Word: платіж {i}, стовпець {col+1}',text(cell),v)
            total=rows[-1].findall(f'{{{W}}}tc')
            compare('Word: підсумок USD',text(total[1]),fmt(calc['total_usd']))
            compare('Word: підсумок UAH',text(total[2]),fmt(calc['total_uah']))
            party=text(tables[1].xpath('./w:tr/w:tc',namespaces=NS)[-1])
            if dt(d['birth_date']) not in party:compare('Word: дата народження','не збігається',dt(d['birth_date']))
            for field in ['name','tax_id','registration','phone','citizenship']:
                if d[field] not in party:compare('Word: '+field,'не збігається',d[field])
    except Exception:
        errors.append({'field':'Структура файлу','actual':'Неприпустимий або пошкоджений файл','expected':kind})
    return errors
