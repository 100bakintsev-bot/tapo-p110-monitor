param([switch]$Live,[switch]$NoBrowser)
$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
$monPython=Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
if (!(Test-Path -LiteralPath $monPython)) { throw 'Не знайдено Python середовища Codex. Використайте Python 3.12+ з requirements.txt.' }
$env:PYTHONIOENCODING='utf-8'
if ($Live) { $env:MON_DEMO='0'; $env:MON_DATA=Join-Path $PSScriptRoot '.local\live'; $env:MON_PORT='18743'; $env:MON_PUBLIC_URL='http://localhost:18743'; $env:MON_INTERNAL_URL='http://host.docker.internal:18743' } else { $env:MON_DEMO='1';$env:MON_DATA=Join-Path $PSScriptRoot '.local\demo';$env:MON_PORT='18741' }
& $monPython manage.py office-env
if ($LASTEXITCODE -ne 0) { throw 'Помилка конфігурації' }
$monOffice=docker ps -a --filter 'name=^mon-sales-office$' --format '{{.Names}}'
if (!$monOffice) { docker run -d --name mon-sales-office --restart unless-stopped -p 127.0.0.1:18742:80 --env-file .local/office.env --mount type=volume,source=mon-sales-office-cache,target=/var/lib/onlyoffice onlyoffice/documentserver@sha256:ca17889f10b11141cc6441836aebdd2835cf3e1b49681b2fd6e155c94b7850b3 | Out-Null } else { docker start mon-sales-office | Out-Null }
if (!$Live) { & $monPython manage.py seed-demo }
if (!$NoBrowser) { $monOpenUrl=$env:MON_PUBLIC_URL; if (!$monOpenUrl) { $monOpenUrl='http://localhost:'+$env:MON_PORT }; Start-Process $monOpenUrl }
& $monPython launch.py
