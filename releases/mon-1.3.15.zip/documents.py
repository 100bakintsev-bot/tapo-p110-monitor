"""Template-preserving OOXML package patches and control reconciliation."""
from copy import deepcopy
from datetime import date
from decimal import Decimal
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import re, time, urllib.request, urllib.parse
from html.parser import HTMLParser
from email.message import Message
from lxml import etree as E
from core import cash

ROOT=Path(__file__).resolve().parent
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
S='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
NS={'w':W,'s':S}
# Include document rules in generation identity so older output is reviewed again.
RULES_VERSION=2

def fmt(v):
    return f'{Decimal(v):,.2f}'.replace(',',' ').replace('.',',')

def dt(v):
    return date.fromisoformat(v).strftime('%d.%m.%Y')

def patch_package(source,changes):
    out=BytesIO()
    with ZipFile(source) as z, ZipFile(out,'w',ZIP_DEFLATED) as w:
        for info in z.infolist():
            w.writestr(info,changes.get(info.filename,z.read(info.filename)))
    return out.getvalue()

def text(node):
    return ''.join(node.itertext()) if node is None else ''.join(node.xpath('.//w:t/text()',namespaces=NS))

def set_text(node,value):
    ts=node.xpath('.//w:t',namespaces=NS)
    if not ts:
        p=node if node.tag==f'{{{W}}}p' else E.SubElement(node,f'{{{W}}}p')
        r=E.SubElement(p,f'{{{W}}}r');ts=[E.SubElement(r,f'{{{W}}}t')]
    ts[0].text=str(value);ts[0].set('{http://www.w3.org/XML/1998/namespace}space','preserve')
    for t in ts[1:]: t.text=''

def party_text(d):
    return ['Сторона-2','',d['name']+',',dt(d['birth_date'])+' року народження', '(громадянство: '+d['citizenship']+'),','реєстраційний номер облікової картки платника податків '+d['tax_id']+',','адреса реєстрації: '+d['registration'],'','т. '+d['phone'],'','','________________________________']

def docx(d,calc,number):
    templates=sorted((ROOT/'inputs').glob('*.docx'))
    # Source variants are selected by their real table capacity, not source buyers.
    def capacity(p):
        with ZipFile(p) as z:
            r=E.fromstring(z.read('word/document.xml'))
            return len(r.xpath('//w:body/w:tbl[1]/w:tr',namespaces=NS))
    templates.sort(key=capacity)
    source=templates[-1] if len(calc['rows'])>10 else templates[0]
    with ZipFile(source) as z:
        r=E.fromstring(z.read('word/document.xml'))
        body=r.find(f'{{{W}}}body'); paragraphs=body.findall(f'{{{W}}}p')
        set_text(paragraphs[2],f"{dt(d['deal_date'])} р. № {d.get('contract_number') or '___'}"+(' · ТЕСТОВА ЧЕРНЕТКА' if d.get('demo') else ' · ЧЕРНЕТКА' if not d.get('contract_number') else ''))
        table=body.findall(f'{{{W}}}tbl')[0]; rows=table.findall(f'{{{W}}}tr')
        pattern=deepcopy(rows[2]); total_row=deepcopy(rows[-1])
        for row in rows[2:]: table.remove(row)
        for i,payment in enumerate(calc['rows'],1):
            row=deepcopy(pattern)
            for cell,value in zip(row.findall(f'{{{W}}}tc'),[i,fmt(payment['usd']),fmt(payment['uah']),dt(payment['date'])]): set_text(cell,value)
            table.append(row)
        cells=total_row.findall(f'{{{W}}}tc')
        for cell,value in zip(cells,['Всього',fmt(calc['total_usd']),fmt(calc['total_uah'])]):set_text(cell,value)
        table.append(total_row)
        parties=body.findall(f'{{{W}}}tbl')[1]
        # Last cell is Party 2 in both reference structures (one has spacer cell).
        buyer=parties.xpath('./w:tr/w:tc',namespaces=NS)[-1]
        ps=buyer.findall(f'{{{W}}}p'); proto=deepcopy(ps[2] if len(ps)>2 else ps[0])
        for p in ps: buyer.remove(p)
        for line in party_text(d):
            p=deepcopy(proto);set_text(p,line);buyer.append(p)
        # Preserve source legal wording, signatures, styles, geometry, relationships.
        changes={'word/document.xml':E.tostring(r,xml_declaration=True,encoding='UTF-8',standalone=True)}
        if 'docProps/core.xml' in z.namelist():
            c=E.fromstring(z.read('docProps/core.xml'))
            for el in c:
                if E.QName(el).localname in ('creator','lastModifiedBy','title','subject','description','keywords'):el.text='MON registry'
            changes['docProps/core.xml']=E.tostring(c,xml_declaration=True,encoding='UTF-8',standalone=True)
    return patch_package(source,changes)

ONES=['','один','два','три','чотири','п’ять','шість','сім','вісім','дев’ять']
TEENS=['десять','одинадцять','дванадцять','тринадцять','чотирнадцять','п’ятнадцять','шістнадцять','сімнадцять','вісімнадцять','дев’ятнадцять']
TENS=['','','двадцять','тридцять','сорок','п’ятдесят','шістдесят','сімдесят','вісімдесят','дев’яносто']
HUNDREDS=['','сто','двісті','триста','чотириста','п’ятсот','шістсот','сімсот','вісімсот','дев’ятсот']
def plural(n,forms):return forms[2] if 11<=n%100<=14 else forms[0] if n%10==1 else forms[1] if 2<=n%10<=4 else forms[2]
def triple(n,female=False):
    a=[HUNDREDS[n//100]];n%=100
    if 10<=n<20:a.append(TEENS[n-10])
    else:a.extend([TENS[n//10],('одна' if n%10==1 else 'дві' if n%10==2 else ONES[n%10]) if female else ONES[n%10]])
    return ' '.join(x for x in a if x)
def words(v):
    v=cash(v);n=int(v);parts=[]
    for divider,forms,female in [(10**9,('мільярд','мільярди','мільярдів'),False),(10**6,('мільйон','мільйони','мільйонів'),False),(1000,('тисяча','тисячі','тисяч'),True)]:
        group,n=divmod(n,divider)
        if group:parts += [triple(group,female),plural(group,forms)]
    if n:parts.append(triple(n,True))
    return (' '.join(parts) if parts else 'нуль').capitalize()+' '+plural(int(v),('гривня','гривні','гривень'))+f' {int((v-int(v))*100):02d} копійок'

def purpose(d):
    vat='без ПДВ' if d['kind']=='квартира' else 'в т.ч. ПДВ'
    return f"Оплата згідно договору к-п МОН (другий продаж), за реєстр. № {d.get('contract_number') or '___'} від {dt(d['deal_date'])}, МОН ({d['kind']} {d['unit']}, {d['address']}), {vat}; {d['name']}; ІПН {d['tax_id']}"

def invoice_values(d,calc,number):
    day=date.fromisoformat(d['deal_date'])
    # All invoice dates are the agreement date. Preserve the source form's
    # two-digit year only in the paid-to-date statement (C27).
    return {'A1':f"Рахунок № {number} від {dt(d['deal_date'])} року"+(' · ТЕСТОВА ЧЕРНЕТКА' if d.get('demo') else ' · ЧЕРНЕТКА' if not d.get('contract_number') else ''),'C17':purpose(d),'C19':d['name'],'C23':Decimal(calc['first_uah']),'C24':'('+words(calc['first_uah'])+')','D25':(day-date(1899,12,30)).days,'C27':f"Станом на {day.strftime('%d.%m.%y')} сплачено 0 грн."}

def print_layout(r):
    # Original XLS has no fit-to-page and splits the invoice across two sheets.
    # Preserve paper, margins, row/column layout; fit the existing form to one page.
    prop=r.find(f'{{{S}}}sheetPr')
    if prop is None:prop=E.Element(f'{{{S}}}sheetPr');r.insert(0,prop)
    setup=prop.find(f'{{{S}}}pageSetUpPr')
    if setup is None:setup=E.SubElement(prop,f'{{{S}}}pageSetUpPr')
    setup.set('fitToPage','1')
    page=r.find(f'{{{S}}}pageSetup')
    if page is None:page=E.SubElement(r,f'{{{S}}}pageSetup')
    page.attrib.pop('scale',None);page.set('fitToWidth','1');page.set('fitToHeight','1')
    row=r.find(f'.//{{{S}}}row[@r="25"]')
    if row is not None and float(row.get('ht','0'))<36:
        row.set('ht','36');row.set('customHeight','1')

def xlsx(d,calc,number):
    source=ROOT/'templates/invoice.xlsx'
    with ZipFile(source) as z:
        r=E.fromstring(z.read('xl/worksheets/sheet1.xml'))
        for coord,value in invoice_values(d,calc,number).items():
            c=r.find(f'.//{{{S}}}c[@r="{coord}"]')
            if c is None:raise RuntimeError('Template cell missing: '+coord)
            for el in list(c):c.remove(el)
            if isinstance(value,(Decimal,int)):
                c.attrib.pop('t',None);E.SubElement(c,f'{{{S}}}v').text=str(value)
            else:
                c.set('t','inlineStr');E.SubElement(E.SubElement(c,f'{{{S}}}is'),f'{{{S}}}t').text=str(value)
        print_layout(r)
        changes={'xl/worksheets/sheet1.xml':E.tostring(r,xml_declaration=True,encoding='UTF-8',standalone=True)}
        # Clear unreferenced sample strings so old buyer data does not remain in ZIP.
        if 'xl/sharedStrings.xml' in z.namelist():
            strings=E.fromstring(z.read('xl/sharedStrings.xml'))
            used={int(c.findtext(f'{{{S}}}v')) for c in r.findall(f'.//{{{S}}}c') if c.get('t')=='s'}
            for i,si in enumerate(strings):
                if i not in used:
                    for el in list(si):si.remove(el)
                    E.SubElement(si,f'{{{S}}}t').text=''
            changes['xl/sharedStrings.xml']=E.tostring(strings,xml_declaration=True,encoding='UTF-8',standalone=True)
        if 'docProps/core.xml' in z.namelist():
            props=E.fromstring(z.read('docProps/core.xml'))
            for el in props:
                if E.QName(el).localname in ('creator','lastModifiedBy','title','subject','description','keywords'):el.text='MON registry'
            changes['docProps/core.xml']=E.tostring(props,xml_declaration=True,encoding='UTF-8',standalone=True)
        return patch_package(source,changes)

def xlsx_cells(data):
    with ZipFile(BytesIO(data)) as z:
        strings=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            r=E.fromstring(z.read('xl/sharedStrings.xml'))
            strings=[''.join(si.itertext()) for si in r]
        r=E.fromstring(z.read('xl/worksheets/sheet1.xml'));out={}
        for c in r.findall(f'.//{{{S}}}c'):
            typ=c.get('t');v=c.findtext(f'{{{S}}}v')
            out[c.get('r')]=''.join(c.xpath('.//s:t/text()',namespaces=NS)) if typ=='inlineStr' else strings[int(v)] if typ=='s' and v is not None else v
        return out

def validate(data,kind,d,calc,number):
    errors=[]
    def compare(field,actual,expected):
        equal=actual==expected if isinstance(actual,Decimal) and isinstance(expected,Decimal) else str(actual or '').strip()==str(expected or '').strip()
        if not equal:errors.append({'field':field,'actual':str(actual),'expected':str(expected)})
    try:
        with ZipFile(BytesIO(data)) as z:
            if len(data)>30*1024*1024 or sum(i.file_size for i in z.infolist())>100*1024*1024:raise ValueError('File too large')
            if any('vbaProject' in x or 'externalLink' in x for x in z.namelist()):raise ValueError('External or macro content')
        if kind=='xlsx':
            cells=xlsx_cells(data)
            for coord,expected in invoice_values(d,calc,number).items():
                actual=cells.get(coord)
                if isinstance(expected,(Decimal,int)):
                    try: actual=Decimal(str(actual)); expected=Decimal(expected)
                    except Exception:pass
                compare('Рахунок!'+coord,actual,expected)
        else:
            with ZipFile(BytesIO(data)) as z:r=E.fromstring(z.read('word/document.xml'))
            paragraphs=r.xpath('//w:body/w:p',namespaces=NS)
            expected=f"{dt(d['deal_date'])} р. № {d.get('contract_number') or '___'}"
            if expected not in text(paragraphs[2]):compare('Word: дата / номер договору',text(paragraphs[2]),expected)
            tables=r.xpath('//w:body/w:tbl',namespaces=NS)
            rows=tables[0].findall(f'{{{W}}}tr')[2:]
            compare('Word: кількість платежів',len(rows)-1,len(calc['rows']))
            for i,(row,payment) in enumerate(zip(rows,calc['rows']),1):
                for col,(cell,v) in enumerate(zip(row.findall(f'{{{W}}}tc'),[str(i),fmt(payment['usd']),fmt(payment['uah']),dt(payment['date'])])):
                    compare(f'Word: платіж {i}, стовпець {col+1}',text(cell),v)
            total=rows[-1].findall(f'{{{W}}}tc')
            compare('Word: підсумок USD',text(total[1]),fmt(calc['total_usd']))
            compare('Word: підсумок UAH',text(total[2]),fmt(calc['total_uah']))
            party=text(tables[1].xpath('./w:tr/w:tc',namespaces=NS)[-1])
            if dt(d['birth_date']) not in party:compare('Word: дата народження','не збігається',dt(d['birth_date']))
            for field in ['name','tax_id','registration','phone','citizenship']:
                if d[field] not in party:compare('Word: '+field,'не збігається',d[field])
    except Exception:
        errors.append({'field':'Структура файлу','actual':'Неприпустимий або пошкоджений файл','expected':kind})
    return errors


class SourceDocumentError(Exception):
    """Safe user-facing failure; never contains URLs or personal data."""


class GoogleRedirects(urllib.request.HTTPRedirectHandler):
    @staticmethod
    def check(url):
        u=urllib.parse.urlsplit(url)
        host=(u.hostname or '').lower()
        if u.scheme!='https' or u.username or u.password or u.port not in (None,443) or not (host in ('drive.google.com','docs.google.com','drive.usercontent.google.com') or host.endswith('.googleusercontent.com')):
            raise SourceDocumentError('Адреса документа не підтримується. Потрібне HTTPS-посилання Google Drive.')
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        self.check(newurl)
        return super().redirect_request(req,fp,code,msg,headers,newurl)


def google_read(url,limit):
    GoogleRedirects.check(url)
    try:
        opener=urllib.request.build_opener(GoogleRedirects())
        with opener.open(urllib.request.Request(url,headers={'User-Agent':'MON-Documents/1'}),timeout=20) as r:
            GoogleRedirects.check(r.url)
            if int(r.headers.get('Content-Length','0'))>limit:raise SourceDocumentError('Документ перевищує дозволений розмір.')
            chunks=[];size=0;deadline=time.monotonic()+45
            while True:
                chunk=r.read(min(65536,limit-size+1))
                if not chunk:break
                chunks.append(chunk);size+=len(chunk)
                if size>limit:raise SourceDocumentError('Документ перевищує дозволений розмір.')
                if time.monotonic()>deadline:raise SourceDocumentError('Google Drive надто довго передає документ. Спробуйте ще раз.')
            return b''.join(chunks),r.headers
    except SourceDocumentError:raise
    except Exception:raise SourceDocumentError('Не вдалося отримати документ із Google Drive. Перевірте доступ за посиланням і повторіть.') from None


def drive_target(url):
    GoogleRedirects.check(url)
    u=urllib.parse.urlsplit(url);q=urllib.parse.parse_qs(u.query)
    if u.hostname!='drive.google.com':raise SourceDocumentError('У колонці T потрібне посилання на файл або папку Google Drive.')
    m=re.fullmatch(r'/drive/(?:u/\d+/)?folders/([A-Za-z0-9_-]{10,})/?',u.path)
    kind='folder' if m else 'file'
    if not m:m=re.fullmatch(r'/file/d/([A-Za-z0-9_-]{10,})(?:/.*)?',u.path)
    fid=m[1] if m else q.get('id',[''])[0] if u.path in ('/open','/uc') else ''
    if not re.fullmatch(r'[A-Za-z0-9_-]{10,}',fid):raise SourceDocumentError('У колонці T немає підтримуваного посилання Google Drive.')
    key=q.get('resourcekey',[''])[0]
    if key and not re.fullmatch(r'[A-Za-z0-9_-]{1,200}',key):raise SourceDocumentError('Некоректне посилання Google Drive.')
    canonical='https://drive.google.com/'+('drive/folders/' if kind=='folder' else 'file/d/')+fid+('' if kind=='folder' else '/view')
    if key:canonical+='?'+urllib.parse.urlencode({'resourcekey':key})
    return {'id':fid,'kind':kind,'key':key,'url':canonical}


class FolderLinks(HTMLParser):
    def __init__(self):super().__init__();self.links=[]
    def handle_starttag(self,tag,attrs):
        if tag=='a':
            href=dict(attrs).get('href','')
            if href.startswith('https://drive.google.com/') and ('/file/d/' in href or '/folders/' in href):self.links.append(href)


def drive_files(url):
    """Only the linked folder tree, bounded; no JavaScript or page text execution."""
    files={};folders=set()
    def walk(target,depth):
        if target['kind']=='file':
            files.setdefault(target['id'],target)
            if len(files)>12:raise SourceDocumentError('У комплекті понад 12 файлів. Відкрийте джерело й оберіть потрібні документи вручну.')
            return
        if target['id'] in folders:return
        if depth>2 or len(folders)>=6:raise SourceDocumentError('Забагато вкладених папок. Відкрийте джерельний комплект.')
        folders.add(target['id'])
        query={'id':target['id']}
        if target['key']:query['resourcekey']=target['key']
        raw,_=google_read('https://drive.google.com/embeddedfolderview?'+urllib.parse.urlencode(query),2*1024*1024)
        p=FolderLinks();p.feed(raw.decode('utf-8'))
        if not p.links:raise SourceDocumentError('Папка порожня або її перелік недоступний. Відкрийте джерело й перевірте доступ.')
        for link in p.links:walk(drive_target(link),depth+1)
    walk(drive_target(url),0)
    return list(files.values())


def drive_download(target):
    query={'export':'download','id':target['id']}
    if target['key']:query['resourcekey']=target['key']
    raw,headers=google_read('https://drive.google.com/uc?'+urllib.parse.urlencode(query),20*1024*1024)
    disposition=Message();disposition['Content-Disposition']=headers.get('Content-Disposition','')
    name=str(disposition.get_filename() or target['id']).replace('\\','/').split('/')[-1][:240]
    if any(ord(c)<32 for c in name):raise SourceDocumentError('Некоректна назва документа.')
    ext=Path(name).suffix.lower()
    actual='.pdf' if raw.startswith(b'%PDF-') else '.png' if raw.startswith(b'\x89PNG\r\n\x1a\n') else '.jpg' if raw.startswith(b'\xff\xd8\xff') else ''
    if raw.startswith(b'PK'):
        try:
            with ZipFile(BytesIO(raw)) as z:
                if len(z.infolist())>2000 or sum(i.file_size for i in z.infolist())>60*1024*1024:raise ValueError()
                if 'word/document.xml' in z.namelist() and not any('vbaProject' in n or n.endswith('.exe') for n in z.namelist()):actual='.docx'
        except Exception:raise SourceDocumentError('Пошкоджений або надто великий документ Word.') from None
    if ext=='.txt' and not actual:
        try:raw.decode('utf-8-sig');actual='.txt'
        except UnicodeError:pass
    allowed=(actual,'.jpeg') if actual=='.jpg' else (actual,)
    if not actual or (ext and ext not in allowed):
        raise SourceDocumentError('Підтримуються PDF, JPG, PNG, DOCX і TXT. Перевірте тип файла та доступ до нього.')
    if not ext:name+=actual
    return name,raw,actual


def source_sheet_links(source_id,include_identity=False):
    """Public single-tab export preserves hyperlinks hidden behind cell labels."""
    raw,_=google_read(f'https://docs.google.com/spreadsheets/d/{source_id}/export?format=xlsx&gid=0&range=A1:T1500',5*1024*1024)
    with ZipFile(BytesIO(raw)) as z:
        if sum(i.file_size for i in z.infolist())>40*1024*1024:raise SourceDocumentError('Онлайн-таблиця надто велика.')
        parser=E.XMLParser(resolve_entities=False,no_network=True)
        workbook=E.fromstring(z.read('xl/workbook.xml'),parser)
        sheets=workbook.findall('.//s:sheet',NS)
        if len(sheets)!=1 or sheets[0].get('name')!='Графік':raise SourceDocumentError('Не вдалося визначити вкладку «Графік».')
        rels=E.fromstring(z.read('xl/worksheets/_rels/sheet1.xml.rels'),parser)
        targets={x.get('Id'):x.get('Target') for x in rels if x.get('TargetMode')=='External'}
        sheet=E.fromstring(z.read('xl/worksheets/sheet1.xml'),parser);links={}
        strings=[]
        if include_identity and 'xl/sharedStrings.xml' in z.namelist():strings=[''.join(v.itertext()) for v in E.fromstring(z.read('xl/sharedStrings.xml'),parser)]
        cells={c.get('r'):c for c in sheet.findall('.//s:c',NS)} if include_identity else {}
        def value(ref):
            c=cells.get(ref)
            if c is None:return ''
            v=c.findtext('s:v',namespaces=NS) or ''
            return strings[int(v)] if c.get('t')=='s' and v else ''.join(c.xpath('.//s:t/text()',namespaces=NS)) if c.get('t')=='inlineStr' else v
        for node in sheet.findall('.//s:hyperlink',NS):
            m=re.fullmatch(r'T([1-9]\d{0,3})',node.get('ref',''))
            target=targets.get(node.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'))
            if m and int(m[1])<=1500 and target:
                try:
                    link=drive_target(target)['url']
                    links[int(m[1])]={'url':link,'identity':[value(col+m[1]) for col in ('C','H','I','J')]} if include_identity else link
                except SourceDocumentError:pass
        return links
