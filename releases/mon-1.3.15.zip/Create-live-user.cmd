@echo off
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
set MON_DEMO=0
set MON_DATA=%~dp0.local\live
"%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" manage.py add-user
pause
