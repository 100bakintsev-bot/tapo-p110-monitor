@echo off
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
set MON_DEMO=0
set MON_PORT=18743
set MON_DATA=%~dp0.local\live
set MON_PUBLIC_URL=http://localhost:18743
set MON_INTERNAL_URL=http://host.docker.internal:18743
set MON_PYTHON=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe
if not exist "%MON_PYTHON%" (
  echo Python runtime not found. See README.md.
  pause
  exit /b 1
)
docker start mon-sales-office
"%MON_PYTHON%" launch.py
pause
