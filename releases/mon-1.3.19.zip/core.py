"""Domain rules. No customer values are written to logs."""
import calendar, hashlib, json, re
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from zoneinfo import ZoneInfo

KYIV = ZoneInfo('Europe/Kyiv')
SOURCE_ID = '1M64fduE78G5oHybqDLtmhkmeyj_ErDMPo4cYfcZjZJs'
BUILDINGS = {'65-Е', '65-И', '65-Ж', '1-Ж'}
REQUIRED = ['name','birth_date','citizenship','tax_id','registration','phone','address','seller_confirmed','party_confirmed']

class RuleError(Exception):
    pass

def money(v):
    if isinstance(v, bool) or v is None or str(v).strip() == '':
        raise RuleError('Сума відсутня')
    s = re.sub(r'[\s\u00a0\u202f]', '', str(v)).replace(',', '.')
    if not re.fullmatch(r'\d+(?:\.\d{1,2})?', s):
        raise RuleError('Некоректна сума')
    try:
        d = Decimal(s)
    except InvalidOperation:
        raise RuleError('Некоректна сума')
    if not d.is_finite() or d <= 0:
        raise RuleError('Сума має бути додатною')
    return d.quantize(Decimal('.01'))

def cash(d):
    return Decimal(d).quantize(Decimal('.01'), rounding=ROUND_HALF_UP)

def parse_date(v):
    s = str(v or '').strip()
    for fmt in ('%d.%m.%Y','%Y-%m-%d'):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    return None

def building(v):
    s = re.sub(r'[\s–—-]', '', str(v or '').upper())
    return {'65Е':'65-Е','65E':'65-Е','65И':'65-И','65Ж':'65-Ж','1Ж':'1-Ж'}.get(s)

def kind(v):
    s = str(v or '').strip().lower()
    if s in ('квартира','кв','кв.') or re.fullmatch(r'\d+[а-яіїєґa-z]',s):
        return 'квартира'
    return {'комора':'комора','п/м':'паркомісце','паркомісце':'паркомісце'}.get(s)

def terms(v):
    s = str(v or '').lower()
    m = re.search(r'до\s*(0?[1-9]|1[0-2])[./](\d{4}|\d{2})(?!\d)',s)
    end = f'{2000+int(m[2]) if len(m[2])==2 else int(m[2]):04d}-{int(m[1]):02d}' if m else None
    individual = bool(re.search(r'індивіду|\bіу\b', s))
    mode = 'individual_monthly' if individual and re.search(r'місяч|щоміс',s) else 'individual' if individual else 'quarterly' if re.search(r'кварт',s) else 'monthly' if end else None
    count = re.search(r'на\s+(\d+)\s+плат',s)
    return {'mode':mode, 'end_month':end, 'count':int(count[1]) if count else None}

def next_business(d):
    d += timedelta(days=1)
    while d.weekday()>4:
        d += timedelta(days=1)
    return d

def add_months(d,n):
    x=d.year*12+d.month-1+n
    y,m=divmod(x,12); m+=1
    return date(y,m,min(d.day,calendar.monthrange(y,m)[1]))

def digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def parse_rows(rows, today, window=True):
    """Only explicit source columns; date headers never become buyer records."""
    result=[]; block=None
    for i,row in enumerate(rows,1):
        r=list(row)+['']*20
        c=str(r[2] or '').strip()
        # The sheet appends the operation tag to some names; it is not a
        # person's name and must not enter the payer or break identity matching.
        c=source_party_name(c)
        b=building(r[7])
        header=parse_date(c)
        if header and not b:
            block=header; continue
        if not b or not c or header:
            continue
        # Service totals and non-sale operations are held out explicitly.
        operation=' '.join(str(x or '') for x in (r[1],r[8],r[18])).lower()
        if re.search(r'переуступ|розірван|повернен|заміна сторони|перенесення коштів|оренда|підсум|всього|разом',operation+' '+c.lower()):
            continue
        issues=[]; d=parse_date(r[3]) if r[3] else None
        if not block:
            issues.append('Не знайдено дату блоку C')
        if r[3] and not d:
            issues.append('Неоднозначна дата D')
        if d and block and d!=block:
            issues.append('Дата D відрізняється від дати блоку C')
        deal_date=block or d
        if window and deal_date and deal_date not in (today,next_business(today)):
            continue
        total=first=None
        try:total=money(r[11])
        except RuleError:issues.append('Заповніть або уточніть повну вартість, USD.')
        try:first=money(r[12])
        except RuleError:issues.append('Заповніть або уточніть перший внесок, USD.')
        if total is not None and first is not None:
            if first==total:continue
            if first>total:issues.append('Перший внесок має бути меншим за повну вартість.')
        total_uah=None
        if r[13]:
            try: total_uah=str(money(r[13]))
            except RuleError: issues.append('Некоректна сума N')
        k=kind(r[8]); t=terms(r[18])
        if not k: issues.append('Невідомий тип приміщення')
        if not str(r[9] or '').strip(): issues.append('Номер приміщення відсутній')
        item={'name':c,'deal_date':deal_date.isoformat() if deal_date else None,'building':b,'kind':k,'kind_code':str(r[8] or ''),'unit':str(r[9] or ''),'total_usd':str(total) if total else None,'first_usd':str(first) if first else None,'source_total_uah':total_uah,'phone':str(r[17] or ''),'terms_text':str(r[18] or ''),'documents_link':str(r[19] or ''),'terms':t,'source_row':i,'source_issues':issues}
        # Stable natural identity excludes row, date and financial mutable fields.
        item['source_buyer_name']=c
        item['source_key']=digest([SOURCE_ID,b,k or item['kind_code'],item['unit'],c.casefold()])
        item['object_key']=digest([b,k or item['kind_code'],item['unit']])
        result.append(item)
    return result

AMOUNT_SOURCE_ISSUES={'Заповніть або уточніть повну вартість, USD.','Заповніть або уточніть перший внесок, USD.','Перший внесок має бути меншим за повну вартість.','Сума відсутня у L/M','Некоректна сума у L/M','Сума має бути додатною у L/M','Перший внесок M перевищує L'}

def resolve_source_amounts(deal):
    confirmed=deal.get('confirmed',{})
    if confirmed.get('total_usd') and confirmed.get('first_usd'):
        try:valid=money(deal.get('first_usd'))<money(deal.get('total_usd'))
        except RuleError:valid=False
        if valid:deal['source_issues']=[s for s in deal.get('source_issues',[]) if s not in AMOUNT_SOURCE_ISSUES]


def schedule(deal, rate):
    total=money(deal.get('total_usd')); first=money(deal.get('first_usd'))
    if first>=total: raise RuleError('Потрібно M < L')
    start=parse_date(deal.get('deal_date'))
    t=deal.get('terms',{}); end=t.get('end_month'); mode=t.get('mode')
    if not start or not end or not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])',end): raise RuleError('Уточніть дату й кінцевий місяць')
    last=date.fromisoformat(end+'-01'); last=last.replace(day=calendar.monthrange(last.year,last.month)[1])
    if last<=start: raise RuleError('Кінцевий строк має бути після угоди')
    rate=Decimal(rate); total_uah=cash(total*rate); first_uah=cash(first*rate)
    rows=[{'date':start.isoformat(),'usd':str(first),'uah':str(first_uah)}]
    dates=[]; pending=[]
    if mode in ('monthly','quarterly','individual_monthly'):
        step=3 if mode=='quarterly' else 1
        n=step
        while add_months(start,n)<=last:
            dates.append(add_months(start,n)); n+=step
            if len(dates)>600: raise RuleError('Завеликий строк')
        if mode=='quarterly' and (not dates or dates[-1].strftime('%Y-%m')!=end):
            final=date(last.year,last.month,min(start.day,last.day))
            if final>start: dates.append(final)
            if not t.get('final_date_confirmed'): pending.append('Підтвердіть фінальну дату квартального графіка')
        if mode=='individual_monthly' and not deal.get('schedule_confirmed'): pending.append('Підтвердіть індивідуальний графік')
    elif mode!='individual':
        raise RuleError('Оберіть режим розтермінування')
    custom=deal.get('custom_schedule')
    if mode.startswith('individual') and custom:
        if not deal.get('schedule_confirmed'): pending.append('Підтвердіть індивідуальний графік')
        if t.get('count') and len(custom)!=int(t['count']): raise RuleError('Кількість платежів не відповідає умовам')
        prev=start
        for r in custom:
            d=parse_date(r.get('date'))
            if not d or not prev<d<=last: raise RuleError('Дати графіка мають зростати після угоди та бути в межах строку')
            rows.append({'date':d.isoformat(),'usd':str(money(r.get('usd'))),'uah':str(money(r.get('uah')))})
            prev=d
    else:
        if mode=='individual': raise RuleError('Внесіть індивідуальні дати та суми')
        if not dates: raise RuleError('Немає наступних платежів у межах строку')
        usd_part=cash((total-first)/len(dates))
        # USD part × MON; final UAH absorbs independent total rounding.
        uah_part=cash(usd_part*rate)
        for i,d in enumerate(dates):
            usd=usd_part if i<len(dates)-1 else total-sum(Decimal(x['usd']) for x in rows)
            uah=uah_part if i<len(dates)-1 else total_uah-sum(Decimal(x['uah']) for x in rows)
            if usd<=0 or uah<=0: raise RuleError('Кожний платіж має бути додатним')
            rows.append({'date':d.isoformat(),'usd':str(usd),'uah':str(uah)})
    if sum(Decimal(x['usd']) for x in rows)!=total or sum(Decimal(x['uah']) for x in rows)!=total_uah:
        raise RuleError('Підсумки індивідуального графіка не сходяться в USD / UAH')
    return {'rows':rows,'total_usd':str(total),'total_uah':str(total_uah),'first_uah':str(first_uah),'remaining_uah':str(total_uah-first_uah),'rate':str(rate),'pending':pending}

def readiness(deal, rate, now):
    issues=list(deal.get('source_issues',[]))+list(deal.get('document_issues',[]))
    if not buyer_name_matches(deal):issues.append('ПІБ Сторони 2 має відповідати колонці C. Описку в по батькові потрібно звірити з паспортом і підтвердити.')
    confirmed=deal.get('confirmed',{})
    for field in REQUIRED:
        if not deal.get(field) or not confirmed.get(field): issues.append('Підтвердьте поле: '+field)
    if deal.get('tax_id') and not re.fullmatch(r'\d{10}',deal['tax_id']): issues.append('РНОКПП має містити 10 цифр')
    if deal.get('birth_date') and not parse_date(deal['birth_date']): issues.append('Некоректна дата народження')
    if deal.get('kind') not in ('квартира','комора','паркомісце','інше'): issues.append('Уточніть тип приміщення')
    if not rate: return 'Очікує курс',issues,None
    if rate.get('conflict'): issues.append('Конфлікт курсу МОН на дату угоди')
    calc=None
    try:
        calc=schedule(deal,rate['mon_rate']); issues+=calc['pending']
        if deal.get('source_total_uah') and money(deal['source_total_uah'])!=Decimal(calc['total_uah']): issues.append('N не збігається з L × МОН')
        pct=deal.get('agreed_percent')
        if pct and abs(Decimal(pct)-money(deal['first_usd'])/money(deal['total_usd'])*100)>Decimal('.1'): issues.append('Погоджений відсоток не відповідає M / L')
    except (RuleError,InvalidOperation,ValueError) as e:
        issues.append(str(e))
    start=parse_date(deal.get('deal_date'))
    if start and (start>now.date() or (start==now.date() and (now.hour,now.minute)<(10,2))):
        return 'Заплановано',issues,calc
    return ('Потрібна перевірка' if issues else 'Готова до генерації'),issues,calc


PARTY_LABELS={'name':'ПІБ Сторони 2','birth_date':'Дата народження','citizenship':'Громадянство','tax_id':'РНОКПП','registration':'Адреса реєстрації','phone':'Телефон','address':'Адреса об’єкта','seller_confirmed':'Реквізити продавця'}

def person_key(value):
    return ' '.join(re.findall(r"[а-яіїєґa-z]+",str(value).casefold().replace('ё','е').replace('’','').replace("'",'').replace('ʼ','')))


def source_party_name(value):
    return re.sub(r'\s*\(\s*МОН\s*\)\s*$','',str(value).strip(),flags=re.I).strip()


def name_spelling_review(source,current):
    a=person_key(source).split();b=person_key(current).split()
    if len(a)!=3 or len(b)!=3 or a[:2]!=b[:2]:return None
    x,y=a[2],b[2]
    if len(x)>len(y):x,y=y,x
    one=(sum(i!=j for i,j in zip(x,y))==1) if len(x)==len(y) else (len(y)==len(x)+1 and any(y[:i]+y[i+1:]==x for i in range(len(y))))
    return {'source':digest(source),'corrected':digest(current)} if one else None


def buyer_name_matches(deal):
    source=deal.get('source_buyer_name')
    if not source or person_key(source)==person_key(deal.get('name','')):return True
    expected=name_spelling_review(source,deal.get('name',''))
    return bool(expected and deal.get('confirmed',{}).get('name') and deal.get('name_spelling_review')==expected)


def phone_value(value):
    value=re.sub(r'^\s*(?:телефон|тел\.?|т\.)\s*[:—-]?\s*','',str(value),flags=re.I)
    value=re.sub(r'[ ()-]','',value.strip())
    if re.fullmatch(r'380\d{9}',value):value='+'+value
    return value if re.fullmatch(r'(?:\+380\d{9}|0\d{9})',value) else None


def source_document_identity(parts):
    # Google CSV displays an integer as 24; the XLSX value can be 24.0.
    # Keep significant leading zeroes and every letter/prefix/suffix intact.
    unit=re.sub(r'^(\d+)\.0+$',r'\1',str(parts[3]).strip())
    return (person_key(source_party_name(parts[0])),building(parts[1]),str(parts[2]).strip().casefold(),unit)


def birth_value(value):
    value=value.strip()
    m=re.fullmatch(r'(\d{1,2})[ \t./-]+(\d{1,2})[ \t./-]+(\d{4})',value)
    months={'січня':1,'января':1,'лютого':2,'февраля':2,'березня':3,'марта':3,'квітня':4,'апреля':4,'травня':5,'мая':5,'червня':6,'июня':6,'липня':7,'июля':7,'серпня':8,'августа':8,'вересня':9,'сентября':9,'жовтня':10,'октября':10,'листопада':11,'ноября':11,'грудня':12,'декабря':12}
    if m:day,month,year=map(int,m.groups())
    else:
        m=re.fullmatch(r'(\d{1,2})\s+([а-яіїєґ]+)\s+(\d{4})',value,re.I)
        if not m or m[2].casefold() not in months:return None
        day,month,year=int(m[1]),months[m[2].casefold()],int(m[3])
    try:return date(year,month,day)
    except ValueError:return None


def owner_section(text,key):
    """Bound fields to C's identity block, excluding other parties/signatures."""
    parts=key.split();spans=[]
    for m in re.finditer(r"[А-ЯІЇЄҐа-яіїєґa-zA-Z’ʼ'-]+",text):
        spans.extend((v,m.start(),m.end()) for v in person_key(m[0]).split())
    anchor=None
    for i in range(len(spans)-len(parts)+1):
        if [v[0] for v in spans[i:i+len(parts)]]==parts:
            anchor=(spans[i][1],spans[i+len(parts)-1][2]);break
    if anchor is None and len(parts)==3:
        values=[];locations=[]
        for label in (r'прізвище(?:\s*/\s*surname)?',r"ім[’ʼ']?я(?:\s*/\s*(?:name|given names?))?",r"по\s+батькові(?:\s*/\s*patronymic)?"):
            m=re.search(label+r"\s*[:—-]?\s*([А-ЯІЇЄҐа-яіїєґ’ʼ'-]+)",text,re.I)
            values.append(person_key(m[1]) if m else '')
            if m:locations.append((m.start(),m.end()))
        if values==parts:anchor=(min(v[0] for v in locations),max(v[1] for v in locations))
    if anchor is None:return None
    institutional={'державна','державний','державного','державної','служба','служби','міграційна','міграційної','україна','україни','міністерство','паспорт','реєстрації','місця','місце','проживання','платника','податків','картка','реєстр','облікової','управління','головне','територіальної','громади','прізвище','батькові','дата','народження','комітет','ради','виконавчий','дані','особу','особи','фізичної','фізичних','населення','центр','надання','адміністративних','район','область','місто','відділ'}
    other=[]
    for m in re.finditer(r"\b[А-ЯІЇЄҐ][А-ЯІЇЄҐа-яіїєґ’ʼ'-]{2,}[ \t]+[А-ЯІЇЄҐ][А-ЯІЇЄҐа-яіїєґ’ʼ'-]{2,}[ \t]+[А-ЯІЇЄҐ][А-ЯІЇЄҐа-яіїєґ’ʼ'-]{2,}\b",text):
        value=person_key(m[0])
        if m.start()<anchor[1] and m.end()>anchor[0]:continue
        line=text[text.rfind('\n',0,m.start())+1:m.start()]
        if re.search(r'народження|адреса|проживання|реєстрації|громадянство',line,re.I):continue
        if value==key or value in key or set(value.split())&institutional:continue
        other.append(m)
    before=[m for m in other if m.end()<=anchor[0]];after=[m for m in other if m.start()>=anchor[1]]
    start=text.rfind('\n',0,anchor[0])+1 if before else 0
    end=text.rfind('\n',0,after[0].start())+1 if after else len(text)
    roles=list(re.finditer(r'(?:ПОКУПЕЦЬ|СТОРОНА\s*[-—–]?\s*2)\s*[:—-]\s*',text[:anchor[0]],re.I))
    if roles and anchor[0]-roles[-1].end()<120:
        start=roles[-1].start()
        boundary=re.search(r'(?im)^\s*[IІVХX\d]+[.)]\s*(?:ПРЕДМЕТ|ЗАГАЛЬНІ|ЦІНА|ВАРТІСТЬ|ПОРЯДОК)',text[anchor[1]:])
        if boundary:end=min(end,anchor[1]+boundary.start())
    signature=re.search(r'(?im)^[^\n]*(?:підпис|начальник|керівник|посадова\s+особа|відповідальна\s+особа)[^\n]*',text[anchor[1]:])
    if signature:end=min(end,anchor[1]+signature.start())
    return text[start:end] if end>=anchor[1] else None


def party_candidates(buyer,attachments):
    """Column C is authoritative. Never join identity fields across people.

    Each field retains its file/page evidence. Conflicting values are proposals,
    not confirmed data. Low-quality OCR is deliberately left for human review.
    """
    key=person_key(source_party_name(buyer));found={};matched=[];issues=[];mixed=0
    if len(key.split())<3:
        return {'fields':{},'matched':[],'issues':['У колонці C потрібне повне ПІБ Сторони 2.'],'conflicts':[]}
    def add(field,value,aid,page):
        found.setdefault(field,{}).setdefault(value,[]).append({'attachment_id':aid,'page':page})
    for a in attachments:
        ex=a['extraction']
        if isinstance(ex,str):ex=json.loads(ex)
        for n,page in enumerate(ex.get('pages') or str(ex.get('text','')).split('\f'),1):
            text=page.get('text','') if isinstance(page,dict) else page
            section=owner_section(text,key)
            if section is None:continue
            text=section
            matched.append({'attachment_id':a['id'],'page':n})
            for m in re.finditer(r'(?:РНОКПП|ІПН|ідентифікаційн(?:ий|ого)\s+(?:номер|код)|номер\s+облікової\s+картки(?:\s+платника\s+податків)?)\s*[:№—-]?\s*(\d(?:[ \t]?\d){9})(?!\d)',text,re.I):
                add('tax_id',re.sub(r'\s','',m[1]),a['id'],n)
            if re.search(r'картка\s+платника\s+податків|реєстраційний\s+номер\s+облікової\s+картки',text,re.I):
                for m in re.finditer(r'(?<!\d)(\d(?:[ \t]?\d){9})(?!\d)',text):add('tax_id',re.sub(r'\s','',m[1]),a['id'],n)
            date_pattern=r'(\d{1,2}(?:[ \t./-]+\d{1,2}[ \t./-]+|\s+[а-яіїєґ]+\s+)\d{4})'
            def add_birth(raw):
                value=birth_value(raw)
                if value and date(1900,1,1)<=value<date.today():add('birth_date',value.isoformat(),a['id'],n)
            for m in re.finditer(date_pattern+r'\s*(?:року\s+народження|р\.\s*н\.)',text,re.I):add_birth(m[1])
            birth_label=r'(?:дата(?:\s+(?:і|та)\s+місце)?\s+народження(?:\s*/\s*date\s+of\s+birth)?|date\s+of\s+birth|число[,]?\s*місяць\s+і\s+рік\s+народження)\s*[:—-]?'
            page_lines=text.splitlines()
            for index,line in enumerate(page_lines):
                label=re.search(birth_label,line,re.I)
                if not label:continue
                inline=list(re.finditer(date_pattern,line[label.end():],re.I))
                if inline:
                    for m in inline:add_birth(m[1])
                    continue
                # Forms often print the value above its caption. Accept only
                # a date-only neighbour; never a nearby registration/issue date.
                for step in (-1,1):
                    pos=index+step
                    while 0<=pos<len(page_lines) and not page_lines[pos].strip():pos+=step
                    if 0<=pos<len(page_lines):
                        value=page_lines[pos].strip(' |\t,;()[]')
                        if re.fullmatch(date_pattern,value,re.I):add_birth(value)
            country_label=r'громадянство(?:[ \t]*/[ \t]*(?:nationality|citizenship|підданство|подданство))?[ \t]*[:—-]?'
            for index,line in enumerate(page_lines):
                label=re.search(country_label,line,re.I)
                if not label:continue
                value=re.split(r'[/;,)]+',line[label.end():],maxsplit=1)[0].strip()
                if re.fullmatch(r"[А-ЯІЇЄҐа-яіїєґ’ʼ' -]{2,60}",value) and not re.search(r'громадян|підпис|прізвище|ім[’ʼ\']?я|народження|адреса|паспорт|документ|свідоцтв',value,re.I):add('citizenship',value.capitalize(),a['id'],n)
                elif value.upper()=='UKR':add('citizenship','Україна',a['id'],n)
                else:
                    # Some official forms print the country above its caption.
                    # A neighbour is accepted only as an explicit country token,
                    # never as the next surname or section title on that form.
                    for step in (-1,1):
                        pos=index+step
                        while 0<=pos<len(page_lines) and not page_lines[pos].strip():pos+=step
                        if 0<=pos<len(page_lines) and page_lines[pos].split('/')[0].strip(' |:;,.').casefold() in ('україна','украина','ukr','ukraine'):add('citizenship','Україна',a['id'],n)
            if re.search(r'\b(?:паспорт\s+громадянина|громадянин|громадянка)\s+україни\b',text,re.I):add('citizenship','Україна',a['id'],n)
            def is_address(value):return 8<=len(value)<=400 and re.search(r'\d',value) and re.search(r'\b(?:вул[.]?|вулиц\w*|пров[.]?|провул\w*|просп\w*|бульв\w*|площа|буд[.]?|будинок|кв[.]?|квартира|село)\b',value,re.I)
            # Notarial contracts put the buyer's registered address inline in
            # the C-matched identity paragraph rather than a separate form row.
            for m in re.finditer(r'(?:місце\s+проживання\s+(?:(?:якого|якої)\s+)?зареєстрован[ео]|зареєстрован(?:ий|а|о)\s+за\s+місцем\s+проживання)\s+за\s+адресою\s*[:.]\s*',text,re.I):
                value=re.split(r'\s*,?\s*\b(?:далі|надалі|який|яка|які|з\s+(?:іншої|однієї)\s+сторони)\b',text[m.end():],maxsplit=1,flags=re.I)[0]
                value=' '.join(value.split()).strip(' ,;')
                if is_address(value):add('registration',value,a['id'],n)
            for m in re.finditer(r'(?im)^[ \t(]*(?:адреса\s+(?:реєстрації|зареєстрованого\s+місця\s+проживання)|зареєстрован(?:е|о)\s+місце\s+проживання|місце\s+(?:реєстрації|проживання))\s*[):—-]?\s*',text):
                lines=[]
                for line in text[m.end():].splitlines()[:6]:
                    line=line.strip()
                    if not line or person_key(line)==key or re.match(r'(?:дата|телефон|тел\.|т\.|підпис|паспорт|РНОКПП|ІПН|громадянство|документ|орган|прізвище|ім[’ʼ\']?я|дані|відомості)\b',line,re.I):break
                    lines.append(line)
                value=' '.join(lines).strip(' ;')
                if is_address(value):add('registration',value,a['id'],n)
                elif m.start()>0:
                    previous=' '.join(text[:m.start()].splitlines()[-3:]).strip()
                    if is_address(previous):add('registration',previous,a['id'],n)
            for m in re.finditer(r'(?:телефон|тел\.|т\.)\s*[:—-]?\s*(\+?\d[\d ()-]{8,20}\d)',text,re.I):
                value=re.sub(r'[^\d+]','',m[1])
                if re.fullmatch(r'(?:\+380\d{9}|0\d{9})',value):add('phone',value,a['id'],n)
    fields={k:{'value':next(iter(v)),'sources':next(iter(v.values()))} for k,v in found.items() if len(v)==1}
    conflicts=[k for k,v in found.items() if len(v)>1]
    if not matched:issues.append('Не знайдено однозначного комплекту Сторони 2 за ПІБ із колонки C. Звірте документи.')
    issues.extend('Розпізнано різні значення поля «'+PARTY_LABELS[k]+'». Перевірте документ.' for k in conflicts)
    return {'fields':fields,'matched':matched,'issues':issues,'conflicts':conflicts,'skipped_mixed_pages':mixed}


def supplement_party_candidates(primary,secondary):
    """T owns available fields; other C-matched sources fill only gaps."""
    fields=dict(primary['fields']);conflicts=list(primary.get('conflicts',[]))
    for field,candidate in secondary['fields'].items():
        if field not in fields and field not in conflicts:fields[field]=candidate
        elif field in primary['fields'] and primary['fields'][field]['value']!=candidate['value'] and field not in conflicts:conflicts.append(field)
    for field in secondary.get('conflicts',[]):
        if field not in primary['fields'] and field not in conflicts:conflicts.append(field)
    matched=primary['matched']+secondary['matched']
    issues=['Розпізнано різні значення поля «'+PARTY_LABELS[k]+'». Перевірте документ.' for k in conflicts]
    if not matched:issues=primary['issues'] or secondary['issues']
    return {'fields':fields,'matched':matched,'issues':issues,'conflicts':conflicts,'skipped_mixed_pages':primary.get('skipped_mixed_pages',0)+secondary.get('skipped_mixed_pages',0)}
