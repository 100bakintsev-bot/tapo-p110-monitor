"""Local MON registry; SQLite transactions, versioned files, ONLYOFFICE integration."""
import base64, csv, hashlib, hmac, http.cookies, io, json, os, secrets, shutil, sqlite3, subprocess, tempfile, threading, time, urllib.request, urllib.parse, zipfile
from contextlib import contextmanager
from datetime import datetime, timedelta
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from decimal import Decimal
from core import *
import documents
import updater
import mon_source

ROOT=Path(__file__).resolve().parent
DATA=Path(os.environ.get('MON_DATA',str(ROOT/'.local/demo'))).resolve()
DATA.mkdir(parents=True,exist_ok=True)
DEMO=os.environ.get('MON_DEMO','1')=='1'
PORT=int(os.environ.get('MON_PORT','18741'))
PUBLIC=os.environ.get('MON_PUBLIC_URL',f'http://localhost:{PORT}').rstrip('/')
INTERNAL=os.environ.get('MON_INTERNAL_URL',f'http://host.docker.internal:{PORT}').rstrip('/')
OFFICE=os.environ.get('MON_OFFICE_URL','http://localhost:18742').rstrip('/')
OFFICE_INTERNAL=os.environ.get('MON_OFFICE_INTERNAL_URL','http://localhost:18742').rstrip('/')
DB=DATA/'registry.sqlite3'
LOCK=threading.RLock()
SERVER=None
def secret(name):
    p=ROOT/'.local'/name;p.parent.mkdir(exist_ok=True)
    if not p.exists():p.write_text(secrets.token_urlsafe(48),encoding='utf-8')
    return p.read_text(encoding='utf-8').strip()
APP_SECRET=secret('app-secret')
OFFICE_SECRET=secret('office-secret')
# Receiver deliberately has no default external credential: 503 until configured.
RATE_TOKEN=os.environ.get('MON_RATE_TOKEN','')
def now():return datetime(2026,11,19,11,0,tzinfo=KYIV) if DEMO else datetime.now(KYIV)
def utc():return datetime.now().astimezone().isoformat()
def encode(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'))
def uid():return secrets.token_hex(16)

@contextmanager
def db():
    with LOCK:
        c=sqlite3.connect(DB,timeout=30);c.row_factory=sqlite3.Row
        c.execute('PRAGMA foreign_keys=ON');c.execute('PRAGMA journal_mode=WAL')
        try:
            c.execute('BEGIN IMMEDIATE');yield c;c.commit()
        except Exception:c.rollback();raise
        finally:c.close()

def init():
    with db() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,username TEXT UNIQUE NOT NULL,name TEXT NOT NULL,password TEXT NOT NULL,enabled INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS logins(token TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires REAL NOT NULL,csrf TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS deals(id TEXT PRIMARY KEY,source_key TEXT,object_key TEXT,data TEXT NOT NULL,rev INTEGER NOT NULL DEFAULT 1,invoice_number TEXT,invoice_date TEXT,sequence INTEGER,UNIQUE(invoice_date,sequence));
        CREATE INDEX IF NOT EXISTS source_index ON deals(source_key);
        CREATE INDEX IF NOT EXISTS object_index ON deals(object_key);
        CREATE TABLE IF NOT EXISTS rates(source_id TEXT PRIMARY KEY,rate_date TEXT NOT NULL,mon_rate TEXT NOT NULL,published_at TEXT NOT NULL,received_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS numbering(day TEXT PRIMARY KEY,next_number INTEGER NOT NULL,confirmed_by TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS generations(id TEXT PRIMARY KEY,deal_id TEXT NOT NULL,fingerprint TEXT NOT NULL,snapshot TEXT NOT NULL,calculation TEXT NOT NULL,created_at TEXT NOT NULL,UNIQUE(deal_id,fingerprint));
        CREATE TABLE IF NOT EXISTS versions(id TEXT PRIMARY KEY,deal_id TEXT NOT NULL,kind TEXT NOT NULL,generation_id TEXT NOT NULL,parent TEXT,author TEXT NOT NULL,created_at TEXT NOT NULL,path TEXT NOT NULL,sha TEXT NOT NULL,origin TEXT NOT NULL,valid INTEGER NOT NULL,errors TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS heads(deal_id TEXT,kind TEXT,version_id TEXT,PRIMARY KEY(deal_id,kind));
        CREATE TABLE IF NOT EXISTS editor_sessions(id TEXT PRIMARY KEY,deal_id TEXT NOT NULL,kind TEXT NOT NULL,user_id TEXT NOT NULL,base_version TEXT NOT NULL,saved_head TEXT NOT NULL,doc_key TEXT NOT NULL,expires REAL NOT NULL,closed INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS attachments(id TEXT PRIMARY KEY,deal_id TEXT NOT NULL,name TEXT NOT NULL,path TEXT NOT NULL,sha TEXT NOT NULL,author TEXT NOT NULL,created_at TEXT NOT NULL,extraction TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,deal_id TEXT,action TEXT NOT NULL,author TEXT NOT NULL,created_at TEXT NOT NULL,detail TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS import_issues(id TEXT PRIMARY KEY,payload TEXT NOT NULL,reason TEXT NOT NULL,resolved INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS calculated_rates(id TEXT PRIMARY KEY,rate_date TEXT NOT NULL,mon_rate TEXT NOT NULL,source_at TEXT NOT NULL,checked_at TEXT NOT NULL,data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS calculated_checks(rate_date TEXT PRIMARY KEY,checked_at TEXT NOT NULL,state TEXT NOT NULL);
        ''')

def hash_password(password):
    if len(password)<12:raise RuleError('Пароль має містити щонайменше 12 символів')
    salt=secrets.token_hex(16)
    return salt+':'+hashlib.scrypt(password.encode(),salt=salt.encode(),n=16384,r=8,p=1).hex()
def check_password(password,stored):
    salt,expected=stored.split(':')
    actual=hashlib.scrypt(password.encode(),salt=salt.encode(),n=16384,r=8,p=1).hex()
    return hmac.compare_digest(actual,expected)
def add_user(username,name,password):
    if not username or len(username)>80 or not name:raise RuleError('Заповніть логін та ім’я')
    with db() as c:
        c.execute('INSERT INTO users VALUES(?,?,?,?,1)',(uid(),username,name,hash_password(password)))

def audit(c,deal_id,action,author,detail=''):
    # Field names / opaque IDs only, never field values or document URLs.
    c.execute('INSERT INTO audit(deal_id,action,author,created_at,detail) VALUES(?,?,?,?,?)',(deal_id,action,author,utc(),detail))

def sign(payload,secret_value=APP_SECRET):
    def b64(x):return base64.urlsafe_b64encode(x).rstrip(b'=').decode()
    head=b64(b'{"alg":"HS256","typ":"JWT"}');body=b64(encode(payload).encode());s=head+'.'+body
    return s+'.'+b64(hmac.new(secret_value.encode(),s.encode(),hashlib.sha256).digest())
def verify(token,secret_value=APP_SECRET):
    try:
        a,b,s=token.split('.')
        expected=sign(json.loads(base64.urlsafe_b64decode(b+'='*(-len(b)%4))),secret_value)
        if not hmac.compare_digest(token,expected):raise ValueError()
        p=json.loads(base64.urlsafe_b64decode(b+'='*(-len(b)%4)))
        if p.get('exp',time.time()+1)<time.time():raise ValueError()
        return p
    except Exception:raise APIError(403,'Неприпустимий або прострочений токен')

class APIError(Exception):
    def __init__(self,status,message):self.status=status;self.message=message

def get_deal(c,deal_id):
    r=c.execute('SELECT * FROM deals WHERE id=?',(deal_id,)).fetchone()
    if not r:raise APIError(404,'Угоду не знайдено')
    d=json.loads(r['data']);d.update(id=r['id'],rev=r['rev'],invoice_number=r['invoice_number'])
    return d
def get_rate(c,day):
    rs=c.execute('SELECT * FROM rates WHERE rate_date=? ORDER BY received_at',(day,)).fetchall()
    if not rs:return None
    return {**dict(rs[0]),'conflict':len({r['mon_rate'] for r in rs})>1,'events':len(rs)}
def view(c,d):
    rate=get_rate(c,d.get('deal_date'));status,issues,calc=readiness(d,rate,now())
    calculated=get_calculated(c,d.get('deal_date'))
    heads={r['kind']:dict(r) for r in c.execute('SELECT v.* FROM heads h JOIN versions v ON v.id=h.version_id WHERE h.deal_id=?',(d['id'],))}
    if heads:
        if all(k in heads for k in ('docx','xlsx')):
            if all(h['valid'] for h in heads.values()):status='Комплект збережено'
            else:status='Розбіжності в документах'
        if issues:status='Потрібна перевірка'
        # Changed card never presents an old document set as current.
        for h in heads.values():
            g=c.execute('SELECT fingerprint FROM generations WHERE id=?',(h['generation_id'],)).fetchone()
            if g and g['fingerprint']!=fingerprint(d,rate):status='Дані змінено — перевірте версії'
    return {**d,'status':status,'issues':issues,'calculation':calc,'rate':rate,'rate_comparison':mon_source.compare(rate,calculated),'documents':{k:{**{a:b for a,b in v.items() if a!='path'},'errors':json.loads(v['errors'])} for k,v in heads.items()}}

def get_calculated(c,day):
    row=c.execute('SELECT data FROM calculated_rates WHERE rate_date=? ORDER BY checked_at DESC,rowid DESC LIMIT 1',(day,)).fetchone()
    if not row:return None
    value=json.loads(row[0]);check=c.execute('SELECT checked_at,state FROM calculated_checks WHERE rate_date=?',(day,)).fetchone()
    if check:value.update(last_check_at=check[0],last_check_state=check[1])
    return value

def refresh_calculated(day):
    date=parse_date(day)
    if not date or day!=date.isoformat():raise RuleError('Потрібна дата YYYY-MM-DD')
    actual=datetime.now(KYIV)
    if date>actual.date() or (date==actual.date() and (actual.hour,actual.minute)<(10,1)):
        raise APIError(422,'Розрахунковий МОН перевіряється з 10:01 за Києвом після появи точки 09:00')
    try:point=mon_source.fetch(date)
    except Exception:
        with db() as c:c.execute('INSERT OR REPLACE INTO calculated_checks VALUES(?,?,?)',(day,utc(),'unavailable'))
        raise APIError(503,'Розрахунковий курс на цю дату недоступний у джерелі. Інший день не підставлено.')
    point['checked_at']=utc();point['test_space']=DEMO
    event_id=digest([point['rate_date'],point['mon_rate'],point['raw_value'],point['source_at'],point['policy']])
    with db() as c:
        c.execute('INSERT OR REPLACE INTO calculated_rates VALUES(?,?,?,?,?,?)',(event_id,day,point['mon_rate'],point['source_at'],point['checked_at'],encode(point)))
        c.execute('INSERT OR REPLACE INTO calculated_checks VALUES(?,?,?)',(day,point['checked_at'],'ok'))
    # Does not touch rates, invoices, generation fingerprints or file heads.
    return point
def fingerprint(d,rate):
    ignore={'id','rev','invoice_number','source_row','source_key','object_key','documents_link'}
    return digest({'deal':{k:v for k,v in d.items() if k not in ignore},'rate':rate['mon_rate'] if rate else None})

def import_rows(rows,actor,window=True):
    if not isinstance(rows,list) or len(rows)>5000:raise RuleError('Некоректний імпорт')
    items=parse_rows(rows,now().date(),window);keys={};counts={'created':0,'updated':0,'review':0,'selected':len(items)}
    for d in items:keys[d['source_key']]=keys.get(d['source_key'],0)+1
    with db() as c:
        for d in items:
            matches=c.execute('SELECT * FROM deals WHERE source_key=?',(d['source_key'],)).fetchall()
            object_matches=c.execute('SELECT id FROM deals WHERE object_key=?',(d['object_key'],)).fetchall()
            if keys[d['source_key']]>1 or len(matches)>1 or (not matches and object_matches):
                issue_id=digest([d['source_key'],d['source_row']])
                c.execute('INSERT OR REPLACE INTO import_issues VALUES(?,?,?,0)',(issue_id,encode(d),'Неоднозначне зіставлення: виберіть окрему угоду або наявну картку'))
                counts['review']+=1;continue
            if matches:
                r=matches[0];old=json.loads(r['data']);confirmed=old.get('confirmed',{})
                for k,v in d.items():
                    if not confirmed.get(k):old[k]=v
                # Keep manual data and all file heads intact.
                if json.loads(r['data'])!=old:
                    c.execute('UPDATE deals SET data=?,rev=rev+1 WHERE id=?',(encode(old),r['id']))
                    audit(c,r['id'],'Імпорт оновлено',actor)
                counts['updated']+=1
            else:
                deal_id=uid();d['confirmed']={};d['demo']=DEMO
                c.execute('INSERT INTO deals(id,source_key,object_key,data) VALUES(?,?,?,?)',(deal_id,d['source_key'],d['object_key'],encode(d)))
                audit(c,deal_id,'Угоду імпортовано',actor);counts['created']+=1
        c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',('last_import',utc()))
    return counts

def receive_rate(payload):
    if set(payload)!={'rate_date','mon_rate','published_at','source_id'}:raise RuleError('Потрібні рівно 4 поля контракту')
    day=payload['rate_date'];v=payload['mon_rate'];source=payload['source_id']
    if not isinstance(v,str) or not re.fullmatch(r'\d{1,4}\.\d{2,6}',v):raise RuleError('mon_rate: десятковий рядок із крапкою')
    if not parse_date(day) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',day):raise RuleError('rate_date: YYYY-MM-DD')
    if not isinstance(source,str) or not re.fullmatch(r'[a-zA-Z0-9:_.-]{1,160}',source):raise RuleError('Некоректний source_id')
    try:
        published=datetime.fromisoformat(payload['published_at'].replace('Z','+00:00'))
        if published.tzinfo is None:raise ValueError()
        if Decimal(v)<=0:raise ValueError()
    except Exception:raise RuleError('Некоректний курс або published_at без часового поясу')
    v=format(Decimal(v).normalize(),'f')
    if '.' not in v or len(v.split('.')[1])<2:v=format(Decimal(v),'.2f')
    with db() as c:
        old=c.execute('SELECT * FROM rates WHERE source_id=?',(source,)).fetchone()
        if old:
            if (old['rate_date'],old['mon_rate'],old['published_at'])!=(day,v,payload['published_at']):raise APIError(409,'source_id вже належить іншій події')
            return {'accepted':True,'duplicate':True,'conflict':get_rate(c,day)['conflict']}
        c.execute('INSERT INTO rates VALUES(?,?,?,?,?)',(source,day,v,payload['published_at'],utc()))
        audit(c,None,'Отримано курс','integration',digest(source))
        conflict=get_rate(c,day)['conflict']
    process_ready()
    return {'accepted':True,'duplicate':False,'conflict':conflict}

def put_version(c,deal_id,kind,generation,parent,author,data,origin,d,calc,number):
    errors=documents.validate(data,kind,d,calc,number);vid=uid()
    folder=DATA/'files'/deal_id;folder.mkdir(parents=True,exist_ok=True)
    path=folder/(vid+'.'+kind);path.write_bytes(data)
    sha=hashlib.sha256(data).hexdigest()
    c.execute('INSERT INTO versions VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(vid,deal_id,kind,generation,parent,author,utc(),str(path),sha,origin,int(not errors),encode(errors)))
    c.execute('INSERT OR REPLACE INTO heads VALUES(?,?,?)',(deal_id,kind,vid))
    audit(c,deal_id,'Документ збережено',author,kind+':'+origin)
    return vid,errors

def generate(deal_id,actor,expected_rev=None):
    with db() as c:
        d=get_deal(c,deal_id);rate=get_rate(c,d.get('deal_date'));status,issues,calc=readiness(d,rate,now())
        if expected_rev is not None and d['rev']!=expected_rev:raise APIError(409,'Картку вже змінено іншим менеджером. Оновіть сторінку.')
        if status!='Готова до генерації':raise APIError(422,'Генерацію заблоковано: '+(' · '.join(issues) or status))
        if c.execute('SELECT 1 FROM editor_sessions WHERE deal_id=? AND closed=0 AND expires>?',(deal_id,time.time())).fetchone():raise APIError(409,'Закрийте редактор перед генерацією')
        fp=fingerprint(d,rate)
        old=c.execute('SELECT id FROM generations WHERE deal_id=? AND fingerprint=?',(deal_id,fp)).fetchone()
        if old:return {'generation_id':old['id'],'unchanged':True}
        issued=c.execute('SELECT * FROM deals WHERE id=?',(deal_id,)).fetchone()
        if issued['invoice_number']:
            if issued['invoice_date']!=d['deal_date']:raise APIError(409,'Угода має виданий номер на іншу дату. Потрібна ручна перевірка; номер не змінено.')
            number=issued['invoice_number']
        else:
            seq=c.execute('SELECT * FROM numbering WHERE day=?',(d['deal_date'],)).fetchone()
            if not seq:raise APIError(422,'Спершу підтвердьте стартову нумерацію цього дня')
            n=seq['next_number'];number=parse_date(d['deal_date']).strftime('%d-%m')+'/'+str(n)
            c.execute('UPDATE numbering SET next_number=? WHERE day=?',(n+1,d['deal_date']))
            c.execute('UPDATE deals SET invoice_number=?,invoice_date=?,sequence=? WHERE id=?',(number,d['deal_date'],n,deal_id))
        # Both files are built and validated before either becomes a head.
        word=documents.docx(d,calc,number);excel=documents.xlsx(d,calc,number)
        if documents.validate(word,'docx',d,calc,number) or documents.validate(excel,'xlsx',d,calc,number):raise APIError(500,'Перевірка створених документів не пройдена')
        generation=uid();c.execute('INSERT INTO generations VALUES(?,?,?,?,?,?)',(generation,deal_id,fp,encode(d),encode(calc),utc()))
        for kind,data in [('docx',word),('xlsx',excel)]:
            prev=c.execute('SELECT version_id FROM heads WHERE deal_id=? AND kind=?',(deal_id,kind)).fetchone()
            # Manual heads are preserved: regeneration creates a candidate, never an overwrite.
            manual=c.execute('SELECT origin FROM versions WHERE id=?',(prev['version_id'],)).fetchone() if prev else None
            vid,_=put_version(c,deal_id,kind,generation,prev['version_id'] if prev else None,actor,data,'automatic',d,calc,number)
            if manual and manual['origin']=='manual':c.execute('UPDATE heads SET version_id=? WHERE deal_id=? AND kind=?',(prev['version_id'],deal_id,kind))
        return {'generation_id':generation,'invoice_number':number,'unchanged':False}

def process_ready():
    if now().weekday()>4:return
    with db() as c:ids=[r[0] for r in c.execute('SELECT id FROM deals')]
    for deal_id in ids:
        try:
            with db() as c:d=get_deal(c,deal_id)
            if d.get('deal_date')==now().date().isoformat():generate(deal_id,'scheduler')
        except (APIError,RuleError):pass
        except Exception:
            with db() as c:audit(c,deal_id,'Помилка генерації','scheduler','Потрібен повторний запуск')

def refresh_source(actor='scheduler'):
    if DEMO:raise APIError(409,'Робоче джерело недоступне у тестовому просторі')
    token=os.environ.get('MON_GOOGLE_ACCESS_TOKEN','')
    try:
        if token:
            url=f'https://sheets.googleapis.com/v4/spreadsheets/{SOURCE_ID}/values/'+urllib.parse.quote("'Графік'!A1:T1500",safe='')+'?valueRenderOption=FORMATTED_VALUE'
            req=urllib.request.Request(url,headers={'Authorization':'Bearer '+token})
            with urllib.request.urlopen(req,timeout=30) as r:values=json.load(r).get('values',[])
        else:
            url=f'https://docs.google.com/spreadsheets/d/{SOURCE_ID}/gviz/tq?tqx=out:csv&gid=0&range=A1:T1500'
            with urllib.request.urlopen(url,timeout=30) as r:
                if not r.headers.get('Content-Type','').startswith('text/csv'):raise ValueError('not_csv')
                raw=r.read(2*1024*1024+1)
            if len(raw)>2*1024*1024:raise ValueError('source_too_large')
            values=list(csv.reader(io.StringIO(raw.decode('utf-8-sig'))))
    except Exception:raise APIError(503,'Не вдалося прочитати вкладку «Графік». Перевірте доступ Google.')
    out=import_rows(values,actor);process_ready();return out

def sync_finance(rate_date=None):
    if DEMO:raise APIError(409,'Робочий курс не імпортується у тестовий простір')
    path=ROOT/'.local/finance-client.json'
    if not path.exists():raise APIError(503,'API підтверджених публікацій ще не підключений')
    config=json.loads(path.read_text())
    if config.get('mode')=='push':
        day=rate_date or now().date().isoformat()
        if not parse_date(day) or parse_date(day).isoformat()!=day:raise RuleError('Потрібна дата YYYY-MM-DD')
        with db() as c:rate=get_rate(c,day)
        return {'ok':True,'events':rate['events'] if rate else 0,'rate_date':day,'mode':'push','waiting':rate is None}
    base=config['api_url'].rstrip('/')
    if not base.startswith('https://') or not config.get('api_token'):raise APIError(503,'Потрібні HTTPS-адреса API й авторизація')
    day=rate_date or now().date().isoformat()
    if not parse_date(day) or parse_date(day).isoformat()!=day:raise RuleError('Потрібна дата YYYY-MM-DD')
    url=base+'/v1/mon-publications?rate_date='+day
    request=urllib.request.Request(url,headers={'Authorization':'Bearer '+config['api_token']})
    try:
        with urllib.request.urlopen(request,timeout=20) as response:body=json.load(response)
    except Exception:raise APIError(503,'API фінансів тимчасово недоступний')
    if not isinstance(body.get('events'),list) or len(body['events'])>100:raise APIError(502,'Некоректна відповідь API фінансів')
    accepted=0
    for event in body['events']:
        if event.get('rate_date')!=day or not str(event.get('source_id','')).startswith('finance:'):raise APIError(502,'Публікація належить іншій даті або джерелу')
        receive_rate(event);accepted+=1
    return {'ok':True,'events':accepted,'rate_date':day}

def scheduler():
    while True:
        if not DEMO and now().weekday()<5:
            local=now()
            if (local.hour,local.minute)>=(10,1):
                with db() as c:check=c.execute('SELECT checked_at FROM calculated_checks WHERE rate_date=?',(local.date().isoformat(),)).fetchone()
                if not check or (datetime.now().astimezone()-datetime.fromisoformat(check[0])).total_seconds()>=300:
                    try:refresh_calculated(local.date().isoformat())
                    except Exception:pass
            try:sync_finance()
            except Exception:pass
            try:
                with db() as c:r=c.execute('SELECT value FROM settings WHERE key=?',('last_poll',)).fetchone()
                if not r or time.time()-float(r[0])>=300:
                    refresh_source()
                    with db() as c:c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',('last_poll',str(time.time())))
            except Exception:pass
            process_ready()
        time.sleep(30)

def office_command(payload):
    payload={**payload,'token':sign(payload,OFFICE_SECRET)}
    request=urllib.request.Request(OFFICE_INTERNAL+'/coauthoring/CommandService.ashx',data=encode(payload).encode(),headers={'Content-Type':'application/json'})
    try:
        with urllib.request.urlopen(request,timeout=30) as r:return json.load(r)
    except Exception:raise APIError(503,'Редактор тимчасово недоступний')

def extraction(path):
    result='';method='text';error=None
    try:
        if path.suffix.lower()=='.pdf':
            from pypdf import PdfReader
            result='\n'.join(p.extract_text() or '' for p in PdfReader(path).pages)
        elif path.suffix.lower()=='.docx':
            with zipfile.ZipFile(path) as z:
                from lxml import etree
                result=' '.join(etree.fromstring(z.read('word/document.xml')).xpath('//w:t/text()',namespaces=documents.NS))
        elif path.suffix.lower()=='.txt':result=path.read_text(encoding='utf-8')
        if not result.strip() and path.suffix.lower() in ('.pdf','.png','.jpg','.jpeg'):
            method='ocr'
            if shutil.which('tesseract'):
                with tempfile.TemporaryDirectory(prefix='mon-ocr-') as folder:
                    images=[path];deadline=time.monotonic()+180
                    if path.suffix.lower()=='.pdf':
                        subprocess.run(['pdftoppm','-r','180','-png','-f','1','-l','30',str(path),str(Path(folder)/'page')],capture_output=True,check=True,timeout=45)
                        images=sorted(Path(folder).glob('*.png'))
                    chunks=[]
                    for image in images:
                        remaining=deadline-time.monotonic()
                        if remaining<=0:raise TimeoutError()
                        out=subprocess.run(['tesseract',str(image),'stdout','-l','ukr+eng'],capture_output=True,check=True,timeout=min(30,remaining))
                        chunks.append(out.stdout.decode('utf-8'))
                    result='\n'.join(chunks)
            else:
                cmd=['docker','run','--rm','--network','none','--memory','512m','--cpus','1','-v',str(path.parent)+':/work:ro','mon-sales-ocr:local','/usr/local/bin/ocr-file','/work/'+path.name]
                out=subprocess.run(cmd,capture_output=True,timeout=180,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                if out.returncode:raise RuntimeError()
                result=out.stdout.decode('utf-8')
    except Exception:error='Не вдалося розпізнати документ. Підтвердьте реквізити вручну.'
    # Never silently merge persons: extraction is only a candidate for human review.
    return {'method':method,'text':result[:100000],'needs_party_confirmation':True,'error':error}

class Handler(BaseHTTPRequestHandler):
    server_version='MON'
    def log_message(self,*args):pass
    def send(self,status,data,content_type='application/json; charset=utf-8',headers=None):
        raw=encode(data).encode() if content_type.startswith('application/json') else data.encode() if isinstance(data,str) else data
        self.send_response(status)
        self.send_header('Content-Type',content_type);self.send_header('Content-Length',str(len(raw)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer');self.send_header('X-Frame-Options','SAMEORIGIN')
        for k,v in (headers or {}).items():self.send_header(k,v)
        self.end_headers();self.wfile.write(raw)
    def body(self):
        n=int(self.headers.get('Content-Length','0'))
        if n>30*1024*1024:raise APIError(413,'Файл завеликий')
        try:return json.loads(self.rfile.read(n)) if n else {}
        except Exception:raise APIError(400,'Некоректний JSON')
    def auth(self,write=False):
        cookie=http.cookies.SimpleCookie(self.headers.get('Cookie',''));sid=cookie.get('mon_session')
        with db() as c:
            r=c.execute('SELECT u.*,l.csrf,l.expires FROM logins l JOIN users u ON u.id=l.user_id WHERE l.token=? AND u.enabled=1',(sid.value if sid else '',)).fetchone()
        if not r or r['expires']<time.time():raise APIError(401,'Увійдіть до реєстру')
        if write and not hmac.compare_digest(self.headers.get('X-CSRF-Token',''),r['csrf']):raise APIError(403,'Оновіть сторінку та повторіть дію')
        return dict(r)
    def do_GET(self):self.dispatch('GET')
    def do_POST(self):self.dispatch('POST')
    def do_PUT(self):self.dispatch('PUT')
    def dispatch(self,method):
        try:self.route(method)
        except APIError as e:self.send(e.status,{'error':e.message})
        except RuleError as e:self.send(422,{'error':str(e)})
        except sqlite3.IntegrityError:self.send(409,{'error':'Запис уже існує. Оновіть сторінку.'})
        except (ValueError,KeyError,TypeError):self.send(400,{'error':'Перевірте формат і обов’язкові поля запиту'})
        except (BrokenPipeError,ConnectionResetError):pass
        except Exception:self.send(500,{'error':'Внутрішня помилка. Дані не змінено; спробуйте повторно.'})
    def route(self,method):
        url=urllib.parse.urlparse(self.path);path=url.path;q=urllib.parse.parse_qs(url.query)
        if method=='GET' and path in ('/','/app.js','/style.css','/editor.html'):
            name={'/':'index.html'}.get(path,path[1:]);mime='text/html; charset=utf-8' if name.endswith('html') else 'text/javascript; charset=utf-8' if name.endswith('js') else 'text/css; charset=utf-8'
            return self.send(200,(ROOT/'web'/name).read_bytes(),mime)
        if method=='GET' and path=='/health':return self.send(200,{'ok':True,'demo':DEMO})
        if method=='GET' and path=='/api/version':return self.send(200,{'version':updater.current(ROOT)})
        if method=='POST' and path=='/api/login':
            b=self.body();user=b.get('username','');password=b.get('password','')
            with db() as c:
                # Persistent bounded attempt counter; no usernames / IPs in logs.
                attempts=c.execute('SELECT value FROM settings WHERE key=?',('login_attempts',)).fetchone();a=json.loads(attempts[0]) if attempts else {'time':time.time(),'count':0}
                if time.time()-a['time']>60:a={'time':time.time(),'count':0}
                if a['count']>=20:raise APIError(429,'Забагато спроб входу. Зачекайте хвилину.')
                r=c.execute('SELECT * FROM users WHERE username=? AND enabled=1',(user,)).fetchone()
                valid=r and check_password(password,r['password'])
                if not valid:
                    a['count']+=1;c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',('login_attempts',encode(a)))
            if not valid:raise APIError(401,'Неправильний логін або пароль')
            token=secrets.token_urlsafe(40);csrf=secrets.token_urlsafe(30)
            with db() as c:c.execute('INSERT INTO logins VALUES(?,?,?,?)',(token,r['id'],time.time()+28800,csrf))
            return self.send(200,{'name':r['name'],'csrf':csrf},headers={'Set-Cookie':'mon_session='+token+'; HttpOnly; SameSite=Strict; Path=/'+('; Secure' if PUBLIC.startswith('https') else '')})
        if method=='POST' and path=='/integrations/mon-rate':
            if not RATE_TOKEN:raise APIError(503,'Приймач курсу не налаштований')
            if not hmac.compare_digest(self.headers.get('Authorization',''),'Bearer '+RATE_TOKEN):raise APIError(401,'Неавторизований запит')
            if DEMO:raise APIError(409,'Робочі події не приймаються у демо')
            return self.send(200,receive_rate(self.body()))
        if path.startswith('/office/'):
            return self.office_route(method,path,q)
        user=self.auth(method!='GET');actor=user['id']
        if path=='/api/session':return self.send(200,{'id':actor,'name':user['name'],'csrf':user['csrf'],'demo':DEMO,'now':now().isoformat(),'storage':'local','full_rights':True})
        if path=='/api/updates':
            if method=='GET':return self.send(200,updater.status(ROOT))
            if method=='POST':return self.send(200,updater.check(ROOT))
        if path=='/api/updates/apply' and method=='POST':
            state=updater.status(ROOT)
            if state.get('state')!='staged':raise APIError(422,'Немає перевіреної нової версії для встановлення')
            if os.environ.get('MON_SUPERVISED')!='1':raise APIError(409,'Закрийте програму та запустіть через штатний ярлик для встановлення оновлення')
            with db() as c:
                if c.execute('SELECT 1 FROM editor_sessions WHERE closed=0 AND expires>?',(time.time(),)).fetchone():raise APIError(409,'Спершу збережіть і закрийте відкриті редактори документів')
                audit(c,None,'Запитано встановлення оновлення',actor)
            (ROOT/'.local/updates/restart-request').write_text('verified-update',encoding='ascii')
            self.send(200,{'restarting':True})
            def restart():
                time.sleep(.5)
                if SERVER:SERVER.shutdown()
            threading.Thread(target=restart,daemon=True).start();return
        if path=='/api/finance-sync' and method=='POST':return self.send(200,sync_finance(self.body().get('rate_date')))
        if path=='/api/calculated-rate' and method=='POST':return self.send(200,refresh_calculated(self.body()['rate_date']))
        if path=='/api/rate-comparison' and method=='GET':
            day=q.get('rate_date',[now().date().isoformat()])[0]
            with db() as c:value=mon_source.compare(get_rate(c,day),get_calculated(c,day))
            return self.send(200,{'rate_date':day,**value})
        if path=='/api/logout' and method=='POST':
            with db() as c:c.execute('DELETE FROM logins WHERE user_id=?',(actor,))
            return self.send(200,{'ok':True},headers={'Set-Cookie':'mon_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'})
        if path=='/api/users':
            if method=='GET':
                with db() as c:out=[dict(r) for r in c.execute('SELECT id,username,name,enabled FROM users')]
                return self.send(200,out)
            b=self.body();add_user(b['username'],b['name'],b['password']);return self.send(201,{'ok':True})
        if path=='/api/deals' and method=='GET':
            with db() as c:out=[view(c,get_deal(c,r[0])) for r in c.execute('SELECT id FROM deals')]
            out.sort(key=lambda d:(d.get('deal_date') or '',d['id']))
            return self.send(200,out)
        if path=='/api/refresh' and method=='POST':return self.send(200,refresh_source(actor))
        if path=='/api/import' and method=='POST':
            b=self.body()
            if b.get('sheet')!='Графік':raise APIError(422,'Дозволено лише вкладку «Графік»')
            return self.send(200,import_rows(b['rows'],actor))
        if path=='/api/numbering' and method=='POST':
            b=self.body();day=b['day'];n=int(b['start'])
            if not parse_date(day) or n<1 or n>100000:raise RuleError('Перевірте дату й стартовий номер')
            with db() as c:
                old=c.execute('SELECT next_number FROM numbering WHERE day=?',(day,)).fetchone()
                max_used=c.execute('SELECT COALESCE(MAX(sequence),0) FROM deals WHERE invoice_date=?',(day,)).fetchone()[0]
                if n<=max_used or (old and n<old[0]):raise APIError(409,'Номер уже використаний або нижчий за підтверджений старт')
                c.execute('INSERT OR REPLACE INTO numbering VALUES(?,?,?)',(day,n,actor));audit(c,None,'Нумерацію підтверджено',actor,day)
            process_ready();return self.send(200,{'ok':True})
        if path=='/api/rates' and method=='GET':
            with db() as c:out=[dict(r) for r in c.execute('SELECT * FROM rates ORDER BY rate_date DESC')]
            return self.send(200,out)
        if path=='/api/demo/rate' and method=='POST':
            if not DEMO:raise APIError(404,'Недоступно')
            return self.send(200,receive_rate(self.body()))
        if path=='/api/import-issues' and method=='GET':
            with db() as c:out=[{**dict(r),'payload':json.loads(r['payload'])} for r in c.execute('SELECT * FROM import_issues WHERE resolved=0')]
            return self.send(200,out)
        if path.startswith('/api/import-issues/') and method=='POST':
            issue_id=path.split('/')[-1];b=self.body()
            with db() as c:
                r=c.execute('SELECT * FROM import_issues WHERE id=? AND resolved=0',(issue_id,)).fetchone()
                if not r:raise APIError(404,'Запис не знайдено')
                d=json.loads(r['payload']);target=b.get('deal_id')
                if target:
                    old=get_deal(c,target);confirmed=old.get('confirmed',{})
                    for k,v in d.items():
                        if not confirmed.get(k):old[k]=v
                    c.execute('UPDATE deals SET source_key=?,object_key=?,data=?,rev=rev+1 WHERE id=?',(d['source_key'],d['object_key'],encode(old),target))
                else:
                    target=uid();d['confirmed']={};d['demo']=DEMO
                    # Manager gives a distinct identity when same natural key is ambiguous.
                    d['source_key']+=':manual:'+target
                    c.execute('INSERT INTO deals(id,source_key,object_key,data) VALUES(?,?,?,?)',(target,d['source_key'],d['object_key'],encode(d)))
                c.execute('UPDATE import_issues SET resolved=1 WHERE id=?',(issue_id,));audit(c,target,'Зіставлення підтверджено',actor)
            return self.send(200,{'deal_id':target})
        parts=path.strip('/').split('/')
        if len(parts)>=3 and parts[:2]==['api','deals']:
            deal_id=parts[2]
            if len(parts)==3:
                with db() as c:
                    d=get_deal(c,deal_id)
                    if method=='PUT':
                        b=self.body()
                        if b.get('rev')!=d['rev']:raise APIError(409,'Картку змінив інший менеджер. Оновіть сторінку.')
                        allowed={'name','birth_date','citizenship','tax_id','registration','phone','address','seller_confirmed','party_confirmed','terms','custom_schedule','schedule_confirmed','contract_number','agreed_percent','kind','deal_date','total_usd','first_usd','unit','source_issues'}
                        changed=[]
                        for k,v in b.get('fields',{}).items():
                            if k not in allowed:raise RuleError('Поле не можна змінювати: '+k)
                            if d.get(k)!=v:changed.append(k)
                            d[k]=v
                        confirmed=d.setdefault('confirmed',{})
                        for k,v in b.get('confirmed',{}).items():
                            if k in allowed:confirmed[k]=bool(v)
                        stored={k:v for k,v in d.items() if k not in ('id','rev','invoice_number')}
                        c.execute('UPDATE deals SET data=?,rev=rev+1 WHERE id=?',(encode(stored),deal_id));audit(c,deal_id,'Поля підтверджено',actor,','.join(changed))
                        d=get_deal(c,deal_id)
                    return self.send(200,view(c,d))
            action=parts[3]
            if action=='revalidate' and method=='POST':
                with db() as c:
                    d=get_deal(c,deal_id);rate=get_rate(c,d.get('deal_date'))
                    if not rate or rate['conflict']:raise APIError(422,'Потрібен підтверджений курс на дату угоди')
                    calc=schedule(d,rate['mon_rate'])
                    heads=c.execute('SELECT v.* FROM heads h JOIN versions v ON h.version_id=v.id WHERE h.deal_id=?',(deal_id,)).fetchall()
                    for v in heads:
                        errors=documents.validate(Path(v['path']).read_bytes(),v['kind'],d,calc,d['invoice_number'])
                        c.execute('UPDATE versions SET valid=?,errors=? WHERE id=?',(int(not errors),encode(errors),v['id']))
                    audit(c,deal_id,'Контроль файлів повторено',actor)
                return self.send(200,{'ok':True})
            if action=='generate' and method=='POST':return self.send(200,generate(deal_id,actor,self.body().get('rev')))
            if action=='history' and method=='GET':
                with db() as c:
                    get_deal(c,deal_id)
                    versions=[{k:v for k,v in dict(r).items() if k!='path'} for r in c.execute('SELECT v.*,u.name AS author_name FROM versions v LEFT JOIN users u ON u.id=v.author WHERE deal_id=? ORDER BY v.rowid DESC',(deal_id,))]
                    events=[dict(r) for r in c.execute('SELECT a.*,u.name AS author_name FROM audit a LEFT JOIN users u ON u.id=a.author WHERE deal_id=? ORDER BY a.id DESC',(deal_id,))]
                return self.send(200,{'versions':versions,'events':events})
            if action=='versions' and method=='POST':
                b=self.body()
                with db() as c:
                    d=get_deal(c,deal_id);v=c.execute('SELECT * FROM versions WHERE id=? AND deal_id=?',(b['version_id'],deal_id)).fetchone()
                    if not v:raise APIError(404,'Версію не знайдено')
                    h=c.execute('SELECT version_id FROM heads WHERE deal_id=? AND kind=?',(deal_id,v['kind'])).fetchone()
                    if h[0]!=b.get('expected_head'):raise APIError(409,'Поточну версію вже змінено')
                    if c.execute('SELECT 1 FROM editor_sessions WHERE deal_id=? AND closed=0 AND expires>?',(deal_id,time.time())).fetchone():raise APIError(409,'Спершу закрийте редактор')
                    g=c.execute('SELECT * FROM generations WHERE id=?',(v['generation_id'],)).fetchone();rate=get_rate(c,d['deal_date'])
                    if g['fingerprint']!=fingerprint(d,rate):raise APIError(409,'Версія не відповідає поточній картці')
                    c.execute('UPDATE heads SET version_id=? WHERE deal_id=? AND kind=?',(v['id'],deal_id,v['kind']));audit(c,deal_id,'Версію вибрано',actor,v['kind'])
                return self.send(200,{'ok':True})
            if action=='download' and method=='GET':return self.download(deal_id,q,actor)
            if action=='editor' and method=='POST':return self.open_editor(deal_id,self.body(),actor,user['name'])
            if action=='attachments':
                with db() as c:get_deal(c,deal_id)
                if method=='GET':
                    with db() as c:out=[{k:v for k,v in dict(r).items() if k!='path'} for r in c.execute('SELECT * FROM attachments WHERE deal_id=?',(deal_id,))]
                    return self.send(200,out)
                b=self.body();name=Path(b['name']).name;ext=Path(name).suffix.lower()
                if ext not in ('.pdf','.png','.jpg','.jpeg','.docx','.txt'):raise RuleError('Підтримуються PDF, зображення, DOCX і TXT')
                raw=base64.b64decode(b['data'],validate=True)
                if len(raw)>20*1024*1024:raise APIError(413,'Максимум 20 МБ')
                aid=uid();folder=DATA/'attachments'/deal_id;folder.mkdir(parents=True,exist_ok=True);file=folder/(aid+ext);file.write_bytes(raw)
                extracted=extraction(file)
                with db() as c:
                    c.execute('INSERT INTO attachments VALUES(?,?,?,?,?,?,?,?)',(aid,deal_id,name,str(file),hashlib.sha256(raw).hexdigest(),actor,utc(),encode(extracted)))
                    audit(c,deal_id,'Оригінал прикріплено',actor)
                return self.send(201,{'id':aid,'extraction':extracted})
        if path.startswith('/api/attachments/') and method=='GET':
            with db() as c:r=c.execute('SELECT * FROM attachments WHERE id=?',(parts[-1],)).fetchone()
            if not r:raise APIError(404,'Файл не знайдено')
            return self.send(200,Path(r['path']).read_bytes(),'application/octet-stream',{'Content-Disposition':"attachment; filename*=UTF-8''"+urllib.parse.quote(r['name'])})
        if path.startswith('/api/editor/') and method=='POST':
            sid=parts[2];action=parts[3];b=self.body()
            with db() as c:
                s=c.execute('SELECT * FROM editor_sessions WHERE id=? AND user_id=?',(sid,actor)).fetchone()
                if not s or s['closed'] or s['expires']<time.time():raise APIError(409,'Сеанс закритий або прострочений')
                if action=='heartbeat':c.execute('UPDATE editor_sessions SET expires=? WHERE id=?',(time.time()+1800,sid))
            if action=='save':
                result=office_command({'c':'forcesave','key':s['doc_key']})
                if result.get('error') not in (0,4):raise APIError(503,'Редактор ще не готовий до збереження')
                return self.send(200,{'ok':True,'pending':result.get('error')==0})
            if action=='close':
                with db() as c:c.execute('UPDATE editor_sessions SET closed=1 WHERE id=?',(sid,))
                return self.send(200,{'ok':True})
            return self.send(200,{'ok':True})
        raise APIError(404,'Не знайдено')

    def download(self,deal_id,q,actor):
        with db() as c:
            d=get_deal(c,deal_id);rate=get_rate(c,d.get('deal_date'));kind=q.get('kind',['bundle'])[0];version=q.get('version',[None])[0]
            if version:
                v=c.execute('SELECT * FROM versions WHERE id=? AND deal_id=?',(version,deal_id)).fetchone()
                if not v:raise APIError(404,'Версію не знайдено')
                out=[v]
            else:
                out=[]
                for k in (('docx','xlsx') if kind=='bundle' else (kind,)):
                    head=c.execute('SELECT v.* FROM heads h JOIN versions v ON h.version_id=v.id WHERE h.deal_id=? AND h.kind=?',(deal_id,k)).fetchone()
                    if not head:raise APIError(422,'Комплект ще не створено')
                    # Default download never silently bypasses a bad latest head.
                    if not head['valid']:raise APIError(422,'Виправте розбіжності документа перед завантаженням')
                    g=c.execute('SELECT fingerprint FROM generations WHERE id=?',(head['generation_id'],)).fetchone()
                    if g['fingerprint']!=fingerprint(d,rate):raise APIError(409,'Документ не відповідає поточним даним картки')
                    out.append(head)
                if len({v['generation_id'] for v in out})>1:raise APIError(409,'Документи належать різним розрахункам')
            audit(c,deal_id,'Файл завантажено',actor,'history' if version else kind)
        if len(out)==1:
            raw=Path(out[0]['path']).read_bytes();ext=out[0]['kind'];mime='application/vnd.openxmlformats-officedocument.wordprocessingml.document' if ext=='docx' else 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        else:
            stream=io.BytesIO()
            with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as z:
                for v in out:z.writestr(('Додаток_2' if v['kind']=='docx' else 'Рахунок (перший внесок)')+'.'+v['kind'],Path(v['path']).read_bytes())
            raw=stream.getvalue();ext='zip';mime='application/zip'
        name=('TEST_' if DEMO else '')+('Рахунок (перший внесок)_' if ext=='xlsx' else '')+(d.get('invoice_number') or deal_id).replace('/','_')+'.'+ext
        return self.send(200,raw,mime,{'Content-Disposition':"attachment; filename*=UTF-8''"+urllib.parse.quote(name)})

    def open_editor(self,deal_id,b,actor,name):
        kind=b['kind']
        if kind not in ('docx','xlsx'):raise RuleError('Непідтримуваний формат')
        with db() as c:
            d=get_deal(c,deal_id)
            h=c.execute('SELECT v.* FROM heads h JOIN versions v ON h.version_id=v.id WHERE h.deal_id=? AND h.kind=?',(deal_id,kind)).fetchone()
            if not h:raise APIError(422,'Документ ще не створено')
            if b.get('expected_head')!=h['id']:raise APIError(409,'Документ уже змінено. Оновіть картку.')
            if c.execute('SELECT 1 FROM editor_sessions WHERE deal_id=? AND kind=? AND closed=0 AND expires>?',(deal_id,kind,time.time())).fetchone():raise APIError(409,'Документ уже редагує менеджер. Збережіть і закрийте попередній сеанс.')
            sid=uid();key=uid();exp=time.time()+1800
            c.execute('INSERT INTO editor_sessions VALUES(?,?,?,?,?,?,?,?,0)',(sid,deal_id,kind,actor,h['id'],h['id'],key,exp))
            tok=sign({'purpose':'office','sid':sid,'exp':time.time()+28800})
            config={'documentType':'word' if kind=='docx' else 'cell','type':'desktop','height':'100%','width':'100%','document':{'fileType':kind,'key':key,'title':('ТЕСТОВИЙ ' if DEMO else '')+('Додаток №2' if kind=='docx' else 'Рахунок (перший внесок)')+' '+d['invoice_number'],'url':INTERNAL+'/office/file?token='+tok,'permissions':{'edit':True,'download':False,'print':True}},'editorConfig':{'mode':'edit','lang':'uk','callbackUrl':INTERNAL+'/office/callback?token='+tok,'user':{'id':actor,'name':name},'customization':{'forcesave':True,'autosave':True,'compactHeader':True,'goback':{'url':PUBLIC,'text':'До реєстру'}}}}
            config['token']=sign(config,OFFICE_SECRET);audit(c,deal_id,'Редактор відкрито',actor,kind)
        return self.send(200,{'session_id':sid,'config':config,'office_url':OFFICE,'base_version':h['id']})

    def office_route(self,method,path,q):
        payload=verify(q.get('token',[''])[0])
        if payload.get('purpose')!='office':raise APIError(403,'Недостатньо прав')
        with db() as c:
            s=c.execute('SELECT s.*,u.enabled FROM editor_sessions s JOIN users u ON s.user_id=u.id WHERE s.id=?',(payload['sid'],)).fetchone()
            if not s or not s['enabled'] or s['closed'] or s['expires']<time.time():raise APIError(403,'Сеанс недійсний')
            if path=='/office/file' and method=='GET':
                v=c.execute('SELECT * FROM versions WHERE id=?',(s['base_version'],)).fetchone()
                return self.send(200,Path(v['path']).read_bytes(),'application/octet-stream')
        if path=='/office/callback' and method=='POST':
            b=self.body();bearer=self.headers.get('Authorization','').removeprefix('Bearer ')
            checked=verify(bearer or b.get('token',''),OFFICE_SECRET)
            signed=checked.get('payload',checked)
            for k in ('key','status','url'):
                if k in b and signed.get(k)!=b[k]:raise APIError(403,'Підпис callback не збігається')
            if b.get('key')!=s['doc_key']:raise APIError(403,'Невірний ключ документа')
            if b.get('status') not in (2,6):return self.send(200,{'error':0})
            u=urllib.parse.urlparse(b.get('url',''));allowed=urllib.parse.urlparse(OFFICE_INTERNAL)
            # Callback content URL is fetched exclusively from the configured office server.
            public=urllib.parse.urlparse(OFFICE)
            actual_port=u.port or (443 if u.scheme=='https' else 80)
            origins={(allowed.hostname,allowed.port or (443 if allowed.scheme=='https' else 80)),(public.hostname,public.port or (443 if public.scheme=='https' else 80))}
            if u.scheme not in ('http','https') or (u.hostname,actual_port) not in origins:raise APIError(403,'Неприпустима адреса файлу редактора')
            local=allowed.scheme+'://'+allowed.netloc+u.path+('?' + u.query if u.query else '')
            try:
                with urllib.request.urlopen(local,timeout=60) as r:data=r.read(30*1024*1024+1)
                if len(data)>30*1024*1024:raise ValueError()
            except Exception:raise APIError(503,'Не вдалося зберегти файл редактора')
            with db() as c:
                latest=c.execute('SELECT * FROM editor_sessions WHERE id=?',(s['id'],)).fetchone()
                h=c.execute('SELECT version_id FROM heads WHERE deal_id=? AND kind=?',(s['deal_id'],s['kind'])).fetchone()
                if latest['closed'] or latest['expires']<time.time() or h[0]!=latest['saved_head']:raise APIError(409,'Конфлікт версій. Файл не перезаписано.')
                prev=c.execute('SELECT * FROM versions WHERE id=?',(h[0],)).fetchone()
                if hashlib.sha256(data).hexdigest()!=prev['sha']:
                    g=c.execute('SELECT * FROM generations WHERE id=?',(prev['generation_id'],)).fetchone();d=get_deal(c,s['deal_id']);rate=get_rate(c,d['deal_date'])
                    calc=schedule(d,rate['mon_rate'])
                    vid,errors=put_version(c,s['deal_id'],s['kind'],g['id'],h[0],s['user_id'],data,'manual',d,calc,d['invoice_number'])
                    c.execute('UPDATE editor_sessions SET saved_head=?,expires=? WHERE id=?',(vid,time.time()+1800,s['id']))
                if b['status']==2:c.execute('UPDATE editor_sessions SET closed=1 WHERE id=?',(s['id'],))
            return self.send(200,{'error':0})
        raise APIError(404,'Не знайдено')

def run():
    global SERVER
    init();threading.Thread(target=scheduler,daemon=True).start()
    threading.Thread(target=updater.background,daemon=True).start()
    host=os.environ.get('MON_BIND','127.0.0.1')
    if host not in ('127.0.0.1','localhost') and not PUBLIC.startswith('https://') and os.environ.get('MON_ALLOW_LAN_HTTP')!='1':
        raise SystemExit('Для віддаленого доступу налаштуйте HTTPS або явно дозвольте HTTP у довіреній локальній мережі.')
    print('MON registry: '+PUBLIC+' · '+('TEST' if DEMO else 'LIVE'),flush=True)
    SERVER=ThreadingHTTPServer((host,PORT),Handler)
    try:SERVER.serve_forever()
    finally:SERVER.server_close()

if __name__=='__main__':run()
