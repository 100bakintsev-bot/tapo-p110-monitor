"""Independent calculation matching the existing bot's Kyiv 09:00 USD SELL selector."""
import json,math
from datetime import datetime
from decimal import Decimal,ROUND_HALF_UP
from urllib.request import Request,urlopen
from zoneinfo import ZoneInfo

TZ=ZoneInfo('Europe/Kyiv')
URL='https://va-rates.treeumapp.net/api/v1/rates?currency=usd&city=1&group=hour'
POLICY='kyiv_0900_chart_median_sell_v1'

def select(payload,day):
    if payload.get('_scope')!='Kyiv' or payload.get('group')!='hour':raise ValueError('Непідтверджене місто або група графіка')
    points=[]
    for item in payload.get('items',{}).get('usd',[]):
        if item.get('currency')!='usd' or item.get('ccy_subtype') is not None:continue
        stamp=datetime.fromisoformat(item['date'])
        if stamp.tzinfo is None:raise ValueError('Час джерела без часового поясу')
        local=stamp.astimezone(TZ)
        if local.date()!=day or (local.hour,local.minute,local.second)!=(9,0,0):continue
        value=item.get('sell')
        if not isinstance(value,(int,float)) or isinstance(value,bool) or not math.isfinite(value) or value<=0:raise ValueError('Некоректний median SELL')
        points.append({'rate_date':day.isoformat(),'mon_rate':str(Decimal(str(value)).quantize(Decimal('.01'),rounding=ROUND_HALF_UP)),'raw_value':str(value),'source_at':stamp.isoformat(),'policy':POLICY,'source_url':URL})
    if len(points)!=1:raise ValueError('Точка Київ / USD / SELL о 09:00 на цю дату відсутня або неоднозначна')
    return points[0]

def fetch(day):
    req=Request(URL,headers={'User-Agent':'Mozilla/5.0','Referer':'https://minfin.com.ua/ua/currency/auction/'})
    with urlopen(req,timeout=15) as response:
        raw=response.read(2*1024*1024+1)
    if len(raw)>2*1024*1024:raise ValueError('Завелика відповідь джерела')
    payload=json.loads(raw);payload['_scope']='Kyiv'
    return select(payload,day)

def compare(published,calculated):
    result={'published':published,'calculated':calculated,'difference':None,'state':'no_published'}
    if published and published.get('conflict'):result['state']='published_conflict'
    elif published and calculated:
        diff=Decimal(calculated['mon_rate'])-Decimal(published['mon_rate']);result['difference']=format(diff,'.2f');result['state']='match' if diff==0 else 'different'
    elif published:result['state']='no_calculated'
    return result
