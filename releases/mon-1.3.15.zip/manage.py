"""Provision LOCAL accounts explicitly; external credentials are never synthesized."""
import argparse, getpass, json, os, secrets, sys
from pathlib import Path
import app
from core import digest

def seed():
    if not app.DEMO:raise SystemExit('Seed is allowed only with MON_DEMO=1')
    app.init()
    with app.db() as c:
        if c.execute('SELECT COUNT(*) FROM deals').fetchone()[0]:return
    password=secrets.token_urlsafe(24)
    app.add_user('demo','Тестовий менеджер',password)
    (app.ROOT/'.local/demo-login.json').write_text(json.dumps({'username':'demo','password':password}),encoding='utf-8')
    base={'name':'Тестовий Покупець Один','birth_date':'1985-01-15','citizenship':'Україна','tax_id':'0000000000','registration':'Тестова адреса реєстрації, буд. 1','phone':'+380000000000','address':'ТЕСТОВА АДРЕСА, будинок 1-Ж, м. Тестове','seller_confirmed':True,'party_confirmed':True,'deal_date':'2026-11-19','building':'1-Ж','kind':'квартира','kind_code':'1Г','unit':'ТЕСТ-24','total_usd':'71084.00','first_usd':'21325.00','source_total_uah':'3248538.80','terms_text':'ІУ на 4 платежі до 11.28','terms':{'mode':'individual','end_month':'2028-11','count':4},'custom_schedule':[{'date':'2027-05-19','usd':'12439.75','uah':'568496.58'},{'date':'2027-11-19','usd':'12439.75','uah':'568496.58'},{'date':'2028-05-19','usd':'12439.75','uah':'568496.58'},{'date':'2028-11-19','usd':'12439.75','uah':'568496.56'}],'schedule_confirmed':True,'source_issues':[],'confirmed':{k:True for k in app.REQUIRED},'contract_number':'ТЕСТ-001','demo':True,'source_row':1,'documents_link':''}
    records=[base,{**base,'name':'Тестова Покупчиня Два','kind':'паркомісце','kind_code':'П/М','building':'65-Е','unit':'ТЕСТ-П24','address':'ТЕСТОВА АДРЕСА, вул. Яновського, 65-Е, м. Тестове','total_usd':'10000.00','first_usd':'2500.00','source_total_uah':None,'terms_text':'до 11.27','terms':{'mode':'monthly','end_month':'2027-11'},'custom_schedule':[],'contract_number':''},{**base,'name':'Тестовий Покупець Три','unit':'ТЕСТ-25','tax_id':'','registration':'','confirmed':{k:True for k in app.REQUIRED if k not in ('tax_id','registration')}},{**base,'name':'Тестовий Покупець Чотири','unit':'ТЕСТ-26','deal_date':'2026-11-20','source_total_uah':None}]
    with app.db() as c:
        actor=c.execute('SELECT id FROM users WHERE username=?',('demo',)).fetchone()[0]
        for d in records:
            source_key=digest(['demo',d['name'],d['unit']]);object_key=digest([d['building'],d['kind'],d['unit']]);d.update(source_key=source_key,object_key=object_key)
            deal_id=app.uid();c.execute('INSERT INTO deals(id,source_key,object_key,data) VALUES(?,?,?,?)',(deal_id,source_key,object_key,app.encode(d)));app.audit(c,deal_id,'Тестову угоду створено',actor)
        c.execute('INSERT INTO numbering VALUES(?,?,?)',('2026-11-19',1,actor))
    app.receive_rate({'rate_date':'2026-11-19','mon_rate':'45.70','published_at':'2026-11-19T10:02:00+02:00','source_id':'demo:mon:2026-11-19'})
    print('Тестові угоди створено. Локальний доступ записано в .local/demo-login.json; не публікуйте цей файл.')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('command',choices=['seed-demo','add-user','office-env','backup']);parser.add_argument('--username');parser.add_argument('--name');args=parser.parse_args()
    app.init()
    if args.command=='seed-demo':seed()
    elif args.command=='add-user':
        app.add_user(args.username or input('Логін: '),args.name or input('Ім’я: '),getpass.getpass('Новий пароль (від 12 символів): '));print('Обліковий запис із повними правами створено.')
    elif args.command=='office-env':
        p=app.ROOT/'.local/office.env';p.write_text('JWT_ENABLED=true\nJWT_SECRET='+app.OFFICE_SECRET+'\nJWT_HEADER=Authorization\nALLOW_PRIVATE_IP_ADDRESS=true\nALLOW_META_IP_ADDRESS=false\n',encoding='utf-8');print('Локальну конфігурацію ONLYOFFICE підготовлено.')
    elif args.command=='backup':
        import sqlite3, zipfile
        folder=app.ROOT/'backups';folder.mkdir(exist_ok=True);target=folder/('MON-'+app.datetime.now().strftime('%Y%m%d-%H%M%S')+'.zip')
        # One database/file snapshot while writers are excluded.
        with app.LOCK:
            temp=folder/'snapshot.sqlite3'
            with sqlite3.connect(app.DB) as source,sqlite3.connect(temp) as dest:source.backup(dest)
            with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
                z.write(temp,'registry.sqlite3')
                for sub in ('files','attachments'):
                    for p in (app.DATA/sub).rglob('*'):
                        if p.is_file():z.write(p,p.relative_to(app.DATA))
            temp.unlink()
        print(str(target))
