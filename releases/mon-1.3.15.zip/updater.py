"""Signed internet releases; installation only while the application is stopped."""
import base64, hashlib, io, json, os, re, shutil, threading, urllib.request, urllib.parse, zipfile
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

ROOT=Path(__file__).resolve().parent
FILES={'app.py','core.py','documents.py','manage.py','updater.py','launch.py','mon_source.py','VERSION','requirements.txt','README.md','Start-demo.cmd','Start-live.cmd','Create-live-user.cmd','Start.ps1','web/index.html','web/app.js','web/style.css','web/editor.html'}
MAX_BYTES=20*1024*1024
class UpdateError(Exception):pass
def version(s):
    if not isinstance(s,str) or not re.fullmatch(r'\d+\.\d+\.\d+',s):raise UpdateError('Некоректна версія')
    return tuple(map(int,s.split('.')))
def current(root=ROOT):return (root/'VERSION').read_text().strip()
def digest(raw):return hashlib.sha256(raw).hexdigest()
def atomic(path,raw):
    path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_name(path.name+'.tmp');temp.write_bytes(raw);os.replace(temp,path)
def save(path,value):atomic(path,json.dumps(value,ensure_ascii=False).encode())
def timestamp():return datetime.now(timezone.utc).isoformat()
@contextmanager
def lock(root):
    path=root/'.local/updates/lock';path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a+b') as f:
        f.seek(0);f.write(b'0');f.flush();f.seek(0)
        if os.name=='nt':
            import msvcrt
            msvcrt.locking(f.fileno(),msvcrt.LK_LOCK,1)
        else:
            import fcntl
            fcntl.flock(f,fcntl.LOCK_EX)
        try:yield
        finally:
            f.seek(0)
            if os.name=='nt':msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
            else:fcntl.flock(f,fcntl.LOCK_UN)
def secure_url(url):
    u=urllib.parse.urlparse(url)
    if u.scheme!='https' or not u.hostname or u.username or u.password:raise UpdateError('Потрібна HTTPS-адреса публікації')
    return url
class HTTPSOnly(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        secure_url(newurl);return super().redirect_request(req,fp,code,msg,headers,newurl)
def fetch(url,limit=MAX_BYTES):
    secure_url(url)
    with urllib.request.build_opener(HTTPSOnly()).open(urllib.request.Request(url,headers={'User-Agent':'MON-Updater/1','Accept':'application/json,application/zip'}),timeout=30) as r:
        raw=r.read(limit+1)
    if len(raw)>limit:raise UpdateError('Пакет оновлення завеликий')
    return raw
def verified(envelope,config):
    try:
        raw=base64.b64decode(envelope['payload'],validate=True);signature=base64.b64decode(envelope['signature'],validate=True)
        Ed25519PublicKey.from_public_bytes(base64.b64decode(config['public_key'],validate=True)).verify(signature,raw)
        m=json.loads(raw)
        if set(m)!={'version','schema','url','sha256','requirements_sha256'} or m['schema']!=1:raise ValueError()
        version(m['version']);secure_url(m['url'])
        if not re.fullmatch('[0-9a-f]{64}',m['sha256']) or not re.fullmatch('[0-9a-f]{64}',m['requirements_sha256']):raise ValueError()
        return m
    except Exception as e:raise UpdateError('Підпис або формат публікації не підтверджено') from e
def package(raw,m):
    if len(raw)>MAX_BYTES or digest(raw)!=m['sha256']:raise UpdateError('Контрольна сума пакета не збігається')
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            names=z.namelist()
            if len(names)!=len(set(names)) or not names or not set(names)<=FILES or 'VERSION' not in names:raise UpdateError('Недозволений склад пакета')
            if sum(i.file_size for i in z.infolist())>MAX_BYTES:raise UpdateError('Розпакований пакет завеликий')
            for i in z.infolist():
                if i.is_dir() or (i.external_attr>>16)&0o170000==0o120000:raise UpdateError('Недозволений тип файлу')
            out={n:z.read(n) for n in names}
            if out['VERSION'].decode().strip()!=m['version']:raise UpdateError('Версія всередині пакета не збігається')
            for n,b in out.items():
                if n.endswith('.py'):compile(b,n,'exec')
            return out
    except UpdateError:raise
    except Exception as e:raise UpdateError('Пошкоджений пакет') from e
def status(root=ROOT):
    p=root/'.local/updates/status.json'
    return json.loads(p.read_text()) if p.exists() else {'state':'not_configured','current_version':current(root)}
def configured(root=ROOT):
    p=root/'.local/update.json'
    if not p.exists():return None
    c=json.loads(p.read_text());secure_url(c['manifest_url'])
    if len(base64.b64decode(c['public_key'],validate=True))!=32:raise UpdateError('Некоректний публічний ключ видавця')
    return c
def check(root=ROOT):
    with lock(root):
        c=configured(root)
        if not c:return status(root)
        try:
            e=json.loads(fetch(c['manifest_url'],65536));m=verified(e,c)
            if version(m['version'])<=version(current(root)):
                result={'state':'current','current_version':current(root),'checked_at':timestamp()}
            else:
                if digest((root/'requirements.txt').read_bytes())!=m['requirements_sha256']:raise UpdateError('Версія потребує оновлення залежностей розробником')
                raw=fetch(m['url']);package(raw,m)
                atomic(root/'.local/updates/release.zip',raw);save(root/'.local/updates/pending.json',e)
                result={'state':'staged','current_version':current(root),'available_version':m['version'],'checked_at':timestamp(),'message':'Завантажено. Встановиться автоматично під час наступного запуску.'}
            save(root/'.local/updates/status.json',result);return result
        except Exception:
            result={'state':'check_failed','current_version':current(root),'checked_at':timestamp(),'message':'Джерело недоступне або пакет не пройшов перевірку. Поточна програма продовжує працювати.'}
            save(root/'.local/updates/status.json',result);return result
def recover(root):
    journal=root/'.local/updates/install.json'
    if not journal.exists():return
    j=json.loads(journal.read_text());backup=root/'.local/updates/rollback'
    for name,existed in j['files'].items():
        if name not in FILES:raise UpdateError('Недозволений шлях у журналі')
        target=(root/name)
        if not target.resolve().is_relative_to(root.resolve()):raise UpdateError('Недозволений шлях')
        if existed:atomic(target,(backup/name).read_bytes())
        elif target.exists():target.unlink()
    journal.unlink()
def apply_pending(root=ROOT):
    """Caller must hold the application process lock and own a free app port."""
    with lock(root):
        recover(root)
        pending=root/'.local/updates/pending.json';config=configured(root)
        if not pending.exists() or not config:return False
        m=verified(json.loads(pending.read_text()),config)
        if version(m['version'])<=version(current(root)):pending.unlink();return False
        if digest((root/'requirements.txt').read_bytes())!=m['requirements_sha256']:raise UpdateError('Несумісні залежності')
        files=package((root/'.local/updates/release.zip').read_bytes(),m)
        if 'requirements.txt' in files and digest(files['requirements.txt'])!=m['requirements_sha256']:raise UpdateError('Несумісні залежності пакета')
        backup=root/'.local/updates/rollback';existed={}
        for name in files:
            target=root/name
            if not target.resolve().is_relative_to(root.resolve()) or target.is_symlink():raise UpdateError('Недозволений шлях')
            existed[name]=target.exists()
            if target.exists():atomic(backup/name,target.read_bytes())
        save(root/'.local/updates/install.json',{'files':existed})
        try:
            for name,data in files.items():atomic(root/name,data)
            (root/'.local/updates/install.json').unlink()
        except Exception:
            recover(root);raise
        pending.unlink();save(root/'.local/updates/status.json',{'state':'installed','current_version':m['version'],'installed_at':timestamp()})
        return True
def background(root=ROOT):
    while True:
        try:check(root)
        except Exception:pass
        threading.Event().wait(3600)
