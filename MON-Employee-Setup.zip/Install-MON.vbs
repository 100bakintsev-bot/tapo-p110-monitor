Option Explicit
Dim shell, fs, chrome, edge, target, link
Set shell = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
chrome = shell.ExpandEnvironmentStrings("%ProgramFiles%") & "\Google\Chrome\Application\chrome.exe"
edge = shell.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\Microsoft\Edge\Application\msedge.exe"
If fs.FileExists(chrome) Then
 target = chrome
ElseIf fs.FileExists(edge) Then
 target = edge
Else
 target = ""
End If
If target <> "" Then
 Set link = shell.CreateShortcut(shell.SpecialFolders("Desktop") & "\MON Registry.lnk")
 link.TargetPath = target
 link.Arguments = "--app=https://mon.92.5.122.213.sslip.io"
 link.Description = "MON Sales Registry"
 link.Save
 shell.Run Chr(34) & target & Chr(34) & " --app=https://mon.92.5.122.213.sslip.io", 1, False
Else
 shell.Run "https://mon.92.5.122.213.sslip.io", 1, False
End If
