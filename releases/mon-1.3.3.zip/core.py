"""Domain rules. No customer values are written to logs."""
import calendar, hashlib, json, re
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from zoneinfo import ZoneInfo

KYIV = ZoneInfo('Europe/Kyiv')
SOURCE_ID = '1M64fduE78G5oHybqDLtmhkmeyj_ErDMPo4cYfcZjZJs'
BUILDINGS = {'65-Е', '65-И', '65-Ж', '1-Ж'}
REQUIRED = ['name','birth_date','citizenship','tax_id','registration','phone','address','seller_confirmed','party_confirmed']

class RuleError(Exception):
    pass

def money(v):
    if isinstance(v, bool) or v is None or str(v).strip() == '':
        raise RuleError('Сума відсутня')
    s = re.sub(r'[\s\u00a0\u202f]', '', str(v)).replace(',', '.')
    if not re.fullmatch(r'\d+(?:\.\d{1,2})?', s):
        raise RuleError('Некоректна сума')
    try:
        d = Decimal(s)
    except InvalidOperation:
        raise RuleError('Некоректна сума')
    if not d.is_finite() or d <= 0:
        raise RuleError('Сума має бути додатною')
    return d.quantize(Decimal('.01'))

def cash(d):
    return Decimal(d).quantize(Decimal('.01'), rounding=ROUND_HALF_UP)

def parse_date(v):
    s = str(v or '').strip()
    for fmt in ('%d.%m.%Y','%Y-%m-%d'):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    return None

def building(v):
    s = re.sub(r'[\s–—-]', '', str(v or '').upper())
    return {'65Е':'65-Е','65E':'65-Е','65И':'65-И','65Ж':'65-Ж','1Ж':'1-Ж'}.get(s)

def kind(v):
    s = str(v or '').strip().lower()
    if s in ('квартира','кв','кв.') or re.fullmatch(r'\d+[а-яіїєґa-z]',s):
        return 'квартира'
    return {'комора':'комора','п/м':'паркомісце','паркомісце':'паркомісце'}.get(s)

def terms(v):
    s = str(v or '').lower()
    m = re.search(r'до\s*(0?[1-9]|1[0-2])[./](\d{4}|\d{2})(?!\d)',s)
    end = f'{2000+int(m[2]) if len(m[2])==2 else int(m[2]):04d}-{int(m[1]):02d}' if m else None
    individual = bool(re.search(r'індивіду|\bіу\b', s))
    mode = 'individual_monthly' if individual and re.search(r'місяч|щоміс',s) else 'individual' if individual else 'quarterly' if re.search(r'кварт',s) else 'monthly' if end else None
    count = re.search(r'на\s+(\d+)\s+плат',s)
    return {'mode':mode, 'end_month':end, 'count':int(count[1]) if count else None}

def next_business(d):
    d += timedelta(days=1)
    while d.weekday()>4:
        d += timedelta(days=1)
    return d

def add_months(d,n):
    x=d.year*12+d.month-1+n
    y,m=divmod(x,12); m+=1
    return date(y,m,min(d.day,calendar.monthrange(y,m)[1]))

def digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def parse_rows(rows, today, window=True):
    """Only explicit source columns; date headers never become buyer records."""
    result=[]; block=None
    for i,row in enumerate(rows,1):
        r=list(row)+['']*20
        c=str(r[2] or '').strip()
        b=building(r[7])
        header=parse_date(c)
        if header and not b:
            block=header; continue
        if not b or not c or header:
            continue
        # Service totals and non-sale operations are held out explicitly.
        operation=' '.join(str(x or '') for x in (r[1],r[8],r[18])).lower()
        if re.search(r'переуступ|розірван|повернен|заміна сторони|перенесення коштів|оренда|підсум|всього|разом',operation+' '+c.lower()):
            continue
        issues=[]; d=parse_date(r[3]) if r[3] else None
        if not block:
            issues.append('Не знайдено дату блоку C')
        if r[3] and not d:
            issues.append('Неоднозначна дата D')
        if d and block and d!=block:
            issues.append('Дата D відрізняється від дати блоку C')
        deal_date=block or d
        if window and deal_date and deal_date not in (today,next_business(today)):
            continue
        total=first=None
        try:
            total=money(r[11]); first=money(r[12])
            if first==total: continue
            if first>total: issues.append('Перший внесок M перевищує L')
        except RuleError as e:
            issues.append(str(e)+' у L/M')
        total_uah=None
        if r[13]:
            try: total_uah=str(money(r[13]))
            except RuleError: issues.append('Некоректна сума N')
        k=kind(r[8]); t=terms(r[18])
        if not k: issues.append('Невідомий тип приміщення')
        if not str(r[9] or '').strip(): issues.append('Номер приміщення відсутній')
        item={'name':c,'deal_date':deal_date.isoformat() if deal_date else None,'building':b,'kind':k,'kind_code':str(r[8] or ''),'unit':str(r[9] or ''),'total_usd':str(total) if total else None,'first_usd':str(first) if first else None,'source_total_uah':total_uah,'phone':str(r[17] or ''),'terms_text':str(r[18] or ''),'documents_link':str(r[19] or ''),'terms':t,'source_row':i,'source_issues':issues}
        # Stable natural identity excludes row, date and financial mutable fields.
        item['source_key']=digest([SOURCE_ID,b,k or item['kind_code'],item['unit'],c.casefold()])
        item['object_key']=digest([b,k or item['kind_code'],item['unit']])
        result.append(item)
    return result

def schedule(deal, rate):
    total=money(deal.get('total_usd')); first=money(deal.get('first_usd'))
    if first>=total: raise RuleError('Потрібно M < L')
    start=parse_date(deal.get('deal_date'))
    t=deal.get('terms',{}); end=t.get('end_month'); mode=t.get('mode')
    if not start or not end or not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])',end): raise RuleError('Уточніть дату й кінцевий місяць')
    last=date.fromisoformat(end+'-01'); last=last.replace(day=calendar.monthrange(last.year,last.month)[1])
    if last<=start: raise RuleError('Кінцевий строк має бути після угоди')
    rate=Decimal(rate); total_uah=cash(total*rate); first_uah=cash(first*rate)
    rows=[{'date':start.isoformat(),'usd':str(first),'uah':str(first_uah)}]
    dates=[]; pending=[]
    if mode in ('monthly','quarterly','individual_monthly'):
        step=3 if mode=='quarterly' else 1
        n=step
        while add_months(start,n)<=last:
            dates.append(add_months(start,n)); n+=step
            if len(dates)>600: raise RuleError('Завеликий строк')
        if mode=='quarterly' and (not dates or dates[-1].strftime('%Y-%m')!=end):
            final=date(last.year,last.month,min(start.day,last.day))
            if final>start: dates.append(final)
            if not t.get('final_date_confirmed'): pending.append('Підтвердіть фінальну дату квартального графіка')
        if mode=='individual_monthly' and not deal.get('schedule_confirmed'): pending.append('Підтвердіть індивідуальний графік')
    elif mode!='individual':
        raise RuleError('Оберіть режим розтермінування')
    custom=deal.get('custom_schedule')
    if mode.startswith('individual') and custom:
        if not deal.get('schedule_confirmed'): pending.append('Підтвердіть індивідуальний графік')
        if t.get('count') and len(custom)!=int(t['count']): raise RuleError('Кількість платежів не відповідає умовам')
        prev=start
        for r in custom:
            d=parse_date(r.get('date'))
            if not d or not prev<d<=last: raise RuleError('Дати графіка мають зростати після угоди та бути в межах строку')
            rows.append({'date':d.isoformat(),'usd':str(money(r.get('usd'))),'uah':str(money(r.get('uah')))})
            prev=d
    else:
        if mode=='individual': raise RuleError('Внесіть індивідуальні дати та суми')
        if not dates: raise RuleError('Немає наступних платежів у межах строку')
        usd_part=cash((total-first)/len(dates))
        # USD part × MON; final UAH absorbs independent total rounding.
        uah_part=cash(usd_part*rate)
        for i,d in enumerate(dates):
            usd=usd_part if i<len(dates)-1 else total-sum(Decimal(x['usd']) for x in rows)
            uah=uah_part if i<len(dates)-1 else total_uah-sum(Decimal(x['uah']) for x in rows)
            if usd<=0 or uah<=0: raise RuleError('Кожний платіж має бути додатним')
            rows.append({'date':d.isoformat(),'usd':str(usd),'uah':str(uah)})
    if sum(Decimal(x['usd']) for x in rows)!=total or sum(Decimal(x['uah']) for x in rows)!=total_uah:
        raise RuleError('Підсумки індивідуального графіка не сходяться в USD / UAH')
    return {'rows':rows,'total_usd':str(total),'total_uah':str(total_uah),'first_uah':str(first_uah),'remaining_uah':str(total_uah-first_uah),'rate':str(rate),'pending':pending}

def readiness(deal, rate, now):
    issues=list(deal.get('source_issues',[]))
    confirmed=deal.get('confirmed',{})
    for field in REQUIRED:
        if not deal.get(field) or not confirmed.get(field): issues.append('Підтвердьте поле: '+field)
    if deal.get('tax_id') and not re.fullmatch(r'\d{10}',deal['tax_id']): issues.append('РНОКПП має містити 10 цифр')
    if deal.get('birth_date') and not parse_date(deal['birth_date']): issues.append('Некоректна дата народження')
    if deal.get('kind') not in ('квартира','комора','паркомісце','інше'): issues.append('Уточніть тип приміщення')
    if not rate: return 'Очікує курс',issues,None
    if rate.get('conflict'): issues.append('Конфлікт курсу МОН на дату угоди')
    calc=None
    try:
        calc=schedule(deal,rate['mon_rate']); issues+=calc['pending']
        if deal.get('source_total_uah') and money(deal['source_total_uah'])!=Decimal(calc['total_uah']): issues.append('N не збігається з L × МОН')
        pct=deal.get('agreed_percent')
        if pct and abs(Decimal(pct)-money(deal['first_usd'])/money(deal['total_usd'])*100)>Decimal('.1'): issues.append('Погоджений відсоток не відповідає M / L')
    except (RuleError,InvalidOperation,ValueError) as e:
        issues.append(str(e))
    start=parse_date(deal.get('deal_date'))
    if start and (start>now.date() or (start==now.date() and (now.hour,now.minute)<(10,2))):
        return 'Заплановано',issues,calc
    return ('Потрібна перевірка' if issues else 'Готова до генерації'),issues,calc
